<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class is used to render form elements to html.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_CheckoutFormRenderer extends PayItEasyCw_Components_FormRenderer
{	
	protected function renderValidatorCallbacks(array $elements)
	{
		$js = "
		if(typeof window.Customweb == 'undefined'){
			window.Customweb = {};
		}
	
		if(typeof Customweb.PayItEasyCw == 'undefined'){
			Customweb.PayItEasyCw = {};
		}
	
		Customweb.PayItEasyCw.Validation = {
			validators: [],
	
			getFormElement: function(obj) {
				var obj_parent = obj.parentNode;
				if (!obj_parent) return false;
				if (obj_parent.tagName.toLowerCase() == 'form') { return obj_parent; }
				else { return getFormElement(obj_parent); }
			},
	
			addValidator: function(id, fn) {
				var me = this;
				var formId = $('#'+id).parents('form').attr('id');
				if (id == 'sAGB') formId = 'payiteasycw-payment-form';
				if (typeof this.validators[formId] == 'undefined') {
					this.validators[formId] = [];
				}
				this.validators[formId].push(fn);
			},
	
			validate: function(formId) {
				$('#payiteasycw-payment-form').find('div.alert').addClass('is--hidden');
				$('#payiteasycw-payment-form').find('div.alert ul.alert--list').html('');
				var validators = this.validators[formId];
				var isValid = true;
				if (validators != undefined) {
					for (var i=0; i<validators.length; i++) {
						if (!validators[i]()) {
							isValid = false;
						}
					}
				}
				if (!isValid) {
					$('#payiteasycw-payment-form').find('div.alert').removeClass('is--hidden');
					$(window).scrollTop($('#payiteasycw-payment-form').offset().top);
				}
				
				if (!this.validateAGB()) {
					isValid = false;
				}
				
				return isValid;
			},
				
			validateAGB: function() {
				var element = document.getElementById('sAGB');
				if (element) {
					$(element).removeClass('has--error');
					$('#payiteasycw-agb-errors').find('div.alert').addClass('is--hidden');
					if (!(element.checked)){
						$(element).addClass('has--error');
						$('#payiteasycw-agb-errors').find('div.alert').removeClass('is--hidden');
						$(window).scrollTop($('#payiteasycw-agb-errors').offset().top);
						return false;
					}
				}
				return true;
			}
		};
		\n";
	
		$prefix = '';
		if ($this->getNamespacePrefix() !== NULL) {
			$prefix = $this->getNamespacePrefix();
		}
		$js .= 'var ' . $prefix . 'registerValidatorCallbacks = function () { ';
		foreach($elements as $element) {
			foreach ($element->getValidators() as $validator) {
				$id = $validator->getControl()->getControlId();
				$js .= 'Customweb.PayItEasyCw.Validation.addValidator("' . $id . '", function (e) {';
				// Create Callback function:
				$js .= ' var el = document.getElementById("' . $id . '"); var callback = ' . $this->getValidationCallbackJs($validator) . ';';
				// Invoke callback
				$js .= ' return callback(e, el);';
				$js .= '}); ';
			}
		}
	
		$js .= '}; ';
		return $js;
	}
	
	protected function getValidationJs($jsCondition, $message) {
		$js = 'function (e, element) { ' .
			'if (element) {' .
			'$(element).removeClass("has--error"); $(element).parents(".js--fancy-select").removeClass("has--error"); ' .
			'if (!(' .
			$jsCondition.
			')) {' .
			'$(element).addClass("has--error"); $(element).parents(".js--fancy-select").addClass("has--error"); ' .
			'$("#payiteasycw-payment-form").find("div.alert ul.alert--list").append("<li class=\"list--entry\">' . str_replace('"', '\"', $message) . '</li>"); ' .
			'return false;' .
			'};}; return true; }';
		return $js;
	}
}