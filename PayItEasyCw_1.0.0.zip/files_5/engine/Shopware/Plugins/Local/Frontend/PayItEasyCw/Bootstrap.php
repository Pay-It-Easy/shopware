<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

use Shopware\Models\Config\Form;
use Doctrine\DBAL\Types\Type;

/**
 * This bootstrap class installs, uninstalls, updates and configures the
 * plugin and registers its events.
 *
 * @author Simon Schurter
 */
class Shopware_Plugins_Frontend_PayItEasyCw_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{
	/**
	 * Return this plugin's capabilities.
	 *
	 * @return array
	 */
	public function getCapabilities()
	{
		return array(
			'install' => true,
			'update' => true,
			'enable' => true
		);
	}

	/**
	 * Return this plugin's label.
	 *
	 * @return string
	 */
	public function getLabel()
	{
		return 'Customweb Pay-It-Easy';
	}

	/**
	 * Return this plugin's version number.
	 *
	 * @return string
	 */
	public function getVersion()
	{
		return '1.0.0';
	}

	/**
	 * Return some information about this plugin.
	 *
	 * @return array
	 */
	public function getInfo()
	{
		return array(
			'label' => $this->getLabel(),
			'description' => $this->getLabel(),
			'source' => 'Local',
			'support' => 'info@customweb.ch',
			'link' => 'http://www.customweb.com/',
			'autor' => 'customweb GmbH',
			'license' => 'commercial',
			'copyright' => 'Copyright ' . date('Y') . ', customweb GmbH',
			'version' => $this->getVersion()
		);
	}

	/**
	 * Initialise and register custom models.
	 */
	public function afterInit()
	{
		$this->registerCustomModels();
	}

	/**
	 * Activate payment methods when enabling plugin.
	 *
	 * @return bool
	 */
	public function enable()
	{
		return parent::enable();
	}

	/**
	 * Deactivate payment methods when disabling plugin.
	 *
	 * @return bool
	 */
	public function disable()
	{
// 		$payments = $this->getPayments();
// 		if ($payments) {
// 			foreach ($payments as $payment) {
// 				$payment->active = 0;
// 				$payment->save();
// 			}
// 		}

		return parent::disable();
	}

	/**
	 * Install and register the plugin.
	 *
	 * @return bool
	 */
	public function install()
	{
		$this->registerComponents();

		try {
			$this->createDatabase();
			$this->createPayments();
			$this->createForm();
			$this->createCronjobs();
			$this->createEvents();
			$this->createMenuItems();

			return array(
				'success' => true,
				'invalidateCache' => array('backend')
			);
		} catch (Exception $e) {
			return array(
				'success' => false,
				'message' => $e->getMessage()
			);
		}
	}

	/**
	 * Uninstall the plugin.
	 *
	 * @return bool
	 */
	public function uninstall()
	{
		try {
// 			$this->removeDatabase();
// 			$this->removePayments();
		} catch (\Exception $e) {}

		return parent::uninstall();
	}

	public function update($oldVersion)
	{
		// If the dummy is used, reinstall the module.
		if ($oldVersion == '1.0.0') {
			$this->uninstall();
			$result = $this->install();
			return $result['success'];
		}

		$this->registerComponents();

		try {
			$this->createPayments();
			$this->createForm();
			$this->createEvents();
			$this->updateDatabase();
		} catch (Exception $e) {
			return false;
		}

		return true;
	}

	/**
	 * Create the plugin's database tables.
	 */
	protected function createDatabase()
	{
		$em = $this->Application()
			->Models();
		$tool = new \Doctrine\ORM\Tools\SchemaTool($em);

		$classes = array();

		if (!$this->tableExist('payiteasycw_payment_config') == true) {
			$classes[] = $em->getClassMetadata('Shopware\CustomModels\PayItEasyCw\Payment\Config');
		}

		$tool->createSchema($classes);

		$this->migrateDatabase();
	}

	/**
	 * Remove the plugin's database tables.
	 */
	protected function removeDatabase()
	{
		$em = $this->Application()->Models();
		$tool = new \Doctrine\ORM\Tools\SchemaTool($em);

		$classes = array(
			$em->getClassMetadata('Shopware\CustomModels\PayItEasyCw\Payment\Config'),
		);

		$tool->dropSchema($classes);

		Shopware()->Db()->exec("DROP TABLE `payiteasycw_transaction`");
		Shopware()->Db()->exec("DROP TABLE `payiteasycw_customer_context`");
		Shopware()->Db()->exec("DROP TABLE `payiteasycw_storage`");
		Shopware()->Db()->exec("DROP TABLE `payiteasycw_external_checkout_context`");
	}

	/**
	 * Update the plugin's database tables.
	 */
	protected function updateDatabase()
	{
		$paymentIdField = Shopware()->Db()->fetchRow("SHOW FIELDS FROM `payiteasycw_transaction` WHERE Field ='payment_id'");
		if ($paymentIdField['Type'] == 'int(11)') {
			Shopware()->Db()->exec("ALTER TABLE `payiteasycw_transaction` CHANGE `payment_id` `payment_id` VARCHAR(255) NOT NULL");

			$transactions = Shopware()->Db()->fetchAll("SELECT id, payment_method, payment_id, transaction_object FROM `payiteasycw_transaction`");
			foreach ($transactions as $transaction) {
				if (is_numeric($transaction['payment_method'])) {
					continue;
				}
				$transactionObject = unserialize(base64_decode($transaction['transaction_object']));
				Shopware()->Db()->exec("UPDATE `payiteasycw_transaction` SET payment_method = '" . $transaction['payment_id'] . "', payment_id = '" . $transactionObject->getPaymentId() . "' WHERE id = " . $transaction['id']);
			}
		}

		$sessionDataField = Shopware()->Db()->fetchRow("SHOW FIELDS FROM `payiteasycw_transaction` WHERE Field = 'session_data'");
		$newSessionDataField = Shopware()->Db()->fetchRow("SHOW FIELDS FROM `payiteasycw_transaction` WHERE Field = 'sessionData'");
		if ($sessionDataField == null && $newSessionDataField == null) {
			Shopware()->Db()->exec("ALTER TABLE `payiteasycw_transaction` ADD `session_data` LONGTEXT NOT NULL");
		}

		$this->migrateDatabase();
	}

	protected function migrateDatabase()
	{
		$manager = new Customweb_Database_Migration_Manager(PayItEasyCw_Helpers_Util::getDriver(), $this->Path() . 'Scripts/', 'payiteasycw_schema_version');
		$manager->migrate();
	}

	/**
	 * Create the payment methods.
	 */
	protected function createPayments()
	{
		$payments = $this->getPayments();
		$paymentNames = array();
		foreach ($payments as $payment) {
			$paymentNames[] = $payment->getName();
		}

		

		if (!in_array('payiteasycw_creditcard', $paymentNames)) {
			$paymentRow = $this->createPayment(array(
				'pluginID' => $this->getId(),
 				'scope' => Shopware_Components_Form::SCOPE_SHOP,
 				'description' => 'Credit Card',
 				'name' => 'payiteasycw_creditcard',
 				'action' => 'payment_payiteasycw',
 				'active' => 0,
 				'additionalDescription' => '<img src="data:image/png;base64,'.base64_encode(file_get_contents(dirname(__FILE__).'/Resources/creditcard.png')).'" />',
 			));
		}

		if (!in_array('payiteasycw_directdebitssepa', $paymentNames)) {
			$paymentRow = $this->createPayment(array(
				'pluginID' => $this->getId(),
 				'scope' => Shopware_Components_Form::SCOPE_SHOP,
 				'description' => 'Sepa Direct Debits',
 				'name' => 'payiteasycw_directdebitssepa',
 				'action' => 'payment_payiteasycw',
 				'active' => 0,
 				'additionalDescription' => '<img src="data:image/png;base64,'.base64_encode(file_get_contents(dirname(__FILE__).'/Resources/directdebitssepa.png')).'" />',
 			));
		}

		if (!in_array('payiteasycw_giropay', $paymentNames)) {
			$paymentRow = $this->createPayment(array(
				'pluginID' => $this->getId(),
 				'scope' => Shopware_Components_Form::SCOPE_SHOP,
 				'description' => 'giropay',
 				'name' => 'payiteasycw_giropay',
 				'action' => 'payment_payiteasycw',
 				'active' => 0,
 				'additionalDescription' => '<img src="data:image/png;base64,'.base64_encode(file_get_contents(dirname(__FILE__).'/Resources/giropay.png')).'" />',
 			));
		}

		if (!in_array('payiteasycw_paypal', $paymentNames)) {
			$paymentRow = $this->createPayment(array(
				'pluginID' => $this->getId(),
 				'scope' => Shopware_Components_Form::SCOPE_SHOP,
 				'description' => 'PayPal',
 				'name' => 'payiteasycw_paypal',
 				'action' => 'payment_payiteasycw',
 				'active' => 0,
 				'additionalDescription' => '<img src="data:image/png;base64,'.base64_encode(file_get_contents(dirname(__FILE__).'/Resources/paypal.png')).'" />',
 			));
		}
	}

	/**
	 * Remove the payment methods.
	 */
	protected function removePayments()
	{
		$sql = 'delete from s_core_paymentmeans where pluginId=' . $this->getId();
		Shopware()->Db()
			->exec($sql);
	}

	/**
	 * Create the plugin's configuration form.
	 */
	protected function createForm()
	{
		$this->registerComponents();

		$form = $this->Form();
		

		$form->setElement('select', 'operation_mode', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'store' => array(
				0 => array('test', Customweb_I18n_Translation::__('Test Mode')->toString()),
 				1 => array('live', Customweb_I18n_Translation::__('Live Mode')->toString()),
 			),
 			'description' => Customweb_I18n_Translation::__('If the test mode is selected the test account
				credentials are used. Make sure to switch to the live mode after
				compelting your tests.')->toString(),
 			'value' => 'test',
 			'label' => Customweb_I18n_Translation::__('Operation Mode')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'ssl_merchant_test', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('The Form Service Username (TEST) provided by
				Pay-It-Easy.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('SSL-Username (TEST)')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'ssl_password_test', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('The Form Service Password (TEST) in order to encrypt the transaction
				request.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('SSL-Password (TEST)')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'username_test', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Payment API Username (TEST) is provided by
				Pay-It-Easy in the initial set up.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('Payment API Username (TEST)
			')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'shop_password_test', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Payment API Password (TEST) is provided by
				Pay-It-Easy in the initial setup.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('Payment API Password (TEST)
			')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'ssl_merchant_live', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('The Form Service Username (LIVE) provided by
				Pay-It-Easy.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('SSL-Username (LIVE)')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'ssl_password_live', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('The Form Service Password (LIVE) used to encrypt the transaction
				request.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('SSL-Password (LIVE)')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'username_live', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Payment API Username (LIVE) is provided by
				Pay-It-Easy in the initial set up.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('Payment API Username (LIVE)
			')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'shop_password_live', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Payment API Password (LIVE) is provided by
				Pay-It-Easy in the initial setup.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('Payment API Password (LIVE)
			')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'order_id_schema', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Here you can insert an order prefix. The prefix allows
				you to change the order number that is transmitted to
				Pay-It-Easy.
				The prefix must contain the tag
				{id}. It will then be replaced by
				the order number (e.g. name_{id}).')->toString(),
 			'value' => '{id}',
 			'label' => Customweb_I18n_Translation::__('Order Prefix')->toString(),
 			'required' => 'false',
 		));

		$form->setElement('text', 'shop_id', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Here you can define a Shop ID. This is only necessary if
				you wish to operate several shops Pay-It-Easy
				Account when using Giropay as a payment method. In order to use
				this
				please contact sellxed.com. An additional module is
				required.')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('Shop ID')->toString(),
 			'required' => 'false',
 		));

		$form->setElement('text', 'update_interval', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('Payments may be updated periodically (interval in minutes). To use this feature you have to setup shopware cron.')->toString(),
 			'value' => '0',
 			'label' => Customweb_I18n_Translation::__('Update interval for payments')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('text', 'last_update', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'description' => Customweb_I18n_Translation::__('')->toString(),
 			'value' => '',
 			'label' => Customweb_I18n_Translation::__('Date of last update')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('select', 'order_creation', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'store' => array(
				0 => array('before', Customweb_I18n_Translation::__('Before Payment')->toString()),
 				1 => array('after', Customweb_I18n_Translation::__('After Payment')->toString()),
 			),
 			'description' => Customweb_I18n_Translation::__('Chose when the order should be created. If set to \'Before Payment\', orders are created in any case. If set to \'After Payment\', an order is created only if the payment is successful.')->toString(),
 			'value' => 'after',
 			'label' => Customweb_I18n_Translation::__('Order Creation')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('select', 'order_identifier', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'store' => array(
				0 => array('order_id', Customweb_I18n_Translation::__('Id')->toString()),
 				1 => array('order_number', Customweb_I18n_Translation::__('Number')->toString()),
 			),
 			'description' => Customweb_I18n_Translation::__('Set which identifier should be sent to the payment service provider.')->toString(),
 			'value' => 'order_id',
 			'label' => Customweb_I18n_Translation::__('Order Identifier')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('select', 'delete_failed_orders', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'store' => array(
				0 => array('yes', Customweb_I18n_Translation::__('Yes')->toString()),
 				1 => array('no', Customweb_I18n_Translation::__('No')->toString()),
 			),
 			'description' => Customweb_I18n_Translation::__('Set to yes to delete the order when the authorization fails. Otherwise the internal order status is set to \'PAYMENT_FAILED\'.')->toString(),
 			'value' => 'no',
 			'label' => Customweb_I18n_Translation::__('Delete Orders on Failure')->toString(),
 			'required' => 'true',
 		));

		$form->setElement('select', 'external_checkout_account_creation', array(
			'scope' => Shopware_Components_Form::SCOPE_SHOP,
 			'store' => array(
				0 => array('force_selection', Customweb_I18n_Translation::__('Show Account Selection')->toString()),
 				1 => array('skip_selection', Customweb_I18n_Translation::__('Always Checkout as Guest')->toString()),
 			),
 			'description' => Customweb_I18n_Translation::__('When using an external checkout, the customer can either be asked to chose an option to authenticate (as guest, register or login) or he can always be checked out as guest.')->toString(),
 			'value' => 'skip_selection',
 			'label' => Customweb_I18n_Translation::__('External Checkout: Guest Checkout')->toString(),
 			'required' => 'true',
 		));
	}

	protected function createCronjobs() {
		try {
			$this->createCronJob(
				'PayItEasyCwCron',
				'PayItEasyCwCron',
				300,
				true
			);

			$this->subscribeEvent('Shopware_CronJob_PayItEasyCwCron', 'runCronJob');
		} catch (Exception $e) {}
	}

	/**
	 * Register events and hooks.
	 */
	protected function createEvents()
	{
		$this->subscribeEvent('Enlight_Controller_Front_RouteStartup', 'onRouteStartUp');

		$this->subscribeEvent('Enlight_Controller_Action_PreDispatch', 'onPreDispatch');

		$this->subscribeEvent('Enlight_Controller_Front_StartDispatch', 'onStartDispatch');

		$this->subscribeEvent('Enlight_Controller_Action_PostDispatch_Backend_Payment', 'onPostDispatchBackendPayment');

		$this->subscribeEvent('Enlight_Controller_Action_PostDispatch_Backend_Order', 'onPostDispatchBackendOrder');

		$this->subscribeEvent('Enlight_Controller_Action_PostDispatch_Backend_Config', 'onPostDispatchBackendConfig');

		$this->subscribeEvent('Enlight_Controller_Action_PostDispatch_Backend_Index', 'onPostDispatchBackendIndex');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Backend_PayiteasycwForm', 'onGetBackendFormController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Backend_PayiteasycwTransactions', 'onGetBackendTransactionsController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Backend_PayiteasycwBase', 'onGetBackendBaseController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Backend_PayiteasycwBaseTransaction', 'onGetBackendBaseTransactionController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Frontend_PayItEasyCwRedirection', 'onGetFrontendRedirectionController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Frontend_PayItEasyCwProcess', 'onGetFrontendProcessController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Frontend_PayItEasyCwCheckout', 'onGetFrontendCheckoutController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Frontend_PayItEasyCwExternalCheckout', 'onGetFrontendExternalCheckoutController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Frontend_PayItEasyCwEndpoint', 'onGetFrontendEndpointController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Frontend_PaymentPayiteasycw', 'onGetFrontendPaymentController');

		$this->subscribeEvent('Enlight_Controller_Dispatcher_ControllerPath_Api_PayiteasycwTransactions', 'onGetTransactionsApiController');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::confirmAction::after', 'onConfirmAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::finishAction::before', 'onFinishAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::finishAction::after', 'onAfterFinishAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::ajaxCartAction::after', 'onAjaxCartAction');

		$this->subscribeEvent('Shopware_Modules_Order_SendMail_Create', 'onOrderSendMailCreate');

		$this->subscribeEvent('Shopware_Modules_Order_SendMail_Send', 'onOrderSendMailSend');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::cartAction::before', 'onBeforeCartAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::cartAction::after', 'onAfterCartAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::getMinimumCharge::after', 'onGetMinimumCharge');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Checkout::getDispatchNoOrder::after', 'onGetDispatchNoOrder');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Account::ordersAction::after', 'onOrdersAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Account::loginAction::after', 'onLoginAction');

		$this->subscribeEvent('Shopware_Controllers_Frontend_Register::indexAction::before', 'onRegisterAction');

		$this->subscribeEvent('sAdmin::sManageRisks::replace', 'onManageRisk');

		$this->subscribeEvent('sAdmin::sManageRisks::after', 'onAfterManageRisk');

		$this->subscribeEvent('sAdmin::sValidateStep3::after', 'onValidatePayment');

		$this->subscribeEvent('sOrder::sSaveOrder::before', 'onSaveOrder');

		$this->subscribeEvent('Shopware_Modules_Order_SaveOrder_ProcessDetails', 'onOrderSave');

		$this->subscribeEvent('Shopware_Modules_Admin_SaveRegister_FilterNeededFields', 'onSaveRegisterFilterNeededFields');

		$this->subscribeEvent('Customweb_ExternalCheckout_Widget_Collect', 'onExternalCheckoutWidgetCollect');

		$this->subscribeEvent('Shopware_Components_Document::assignValues::after', 'onDocumentOrderToArray');
	}

	protected function createMenuItems()
	{
		$item = $this->createMenuItem(array(
			'label'      => 'Pay-It-Easy',
			'class'      => 'sprite-credit-cards',
			'active'     => 1,
			'action'     => 'index',
			'controller' => 'PayiteasycwForm',
			'parent'     => $this->Menu()->findOneBy('label', 'Einstellungen')
		));
		$this->Menu()->addItem($item);

		$item = $this->createMenuItem(array(
			'label'      => 'Pay-It-Easy',
			'class'      => 'sprite-credit-cards',
			'active'     => 1,
			'action'     => 'index',
			'controller' => 'PayiteasycwTransactions',
			'parent'     => $this->Menu()->findOneBy('label', 'Zahlungen')
		));
		$this->Menu()->addItem($item);

		$this->Menu()->save();
	}

	/**
	 * Register required Namespaces to being able to use the corresponding classes.
	 */
	public function registerComponents()
	{
		Shopware()->Loader()
			->registerNamespace('Customweb', 'Customweb/');
		Shopware()->Loader()
			->registerNamespace('PayItEasyCw_Helpers', dirname(__FILE__) . '/Helpers/');
		Shopware()->Loader()
			->registerNamespace('PayItEasyCw_Entities', dirname(__FILE__) . '/Entities/');
		Shopware()->Loader()
			->registerNamespace('PayItEasyCw_Components', dirname(__FILE__) . '/Components/');
		Shopware()->Loader()
			->registerNamespace('Shopware\Components\Api', dirname(__FILE__) . '/Components/Api/');

		$this->Application()->Snippets()->addConfigDir(
				$this->Path() . 'Snippets/'
		);

		Customweb_I18n_Translation::getInstance()->addResolver(new PayItEasyCw_Components_TranslationResolver($this->Path()));

		Customweb_Core_Util_Class::registerClassLoader(function($className){
			return Shopware()->Loader()->loadClass($className);
		});
	}

	/**
	 * This function bypasses the input filter.
	 *
	 * @param \Enlight_Event_EventArgs $args
	 */
	public function onRouteStartUp(Enlight_Event_EventArgs $args)
	{
		PayItEasyCw_Components_Request::storeData();
		PayItEasyCw_Helpers_Util::setPluginPath($this->Path());
	}

	public function onStartDispatch(Enlight_Event_EventArgs $args)
	{
		$this->registerComponents();
	}

	/**
	 * This pre-dispatch event-hook registers helpers and components.
	 *
	 * @param \Enlight_Event_EventArgs $args
	 */
	public function onPreDispatch(Enlight_Event_EventArgs $args)
	{
		$this->registerComponents();

		$args->getSubject()
			->View()
			->addTemplateDir($this->getTemplateDirectory());
	}

	/**
	 * This post-dispatch event-hook extends the backend payment controller.
	 *
	 * @param \Enlight_Event_EventArgs $args
	 */
	public function onPostDispatchBackendPayment(Enlight_Event_EventArgs $args)
	{
		PayItEasyCw_Components_ActionHandlers_Payment::call($args->getRequest()
			->getActionName(), $args, $this->getId());
	}

	/**
	 * This post-dispatch event-hook extends the backend order controller.
	 *
	 * @param \Enlight_Event_EventArgs $args
	 */
	public function onPostDispatchBackendOrder(Enlight_Event_EventArgs $args)
	{
		PayItEasyCw_Components_ActionHandlers_Order::call($args->getRequest()
			->getActionName(), $args, $this->getId());
	}

	/**
	 * This post-dispatch event-hook extends the backend config controller.
	 *
	 * @param \Enlight_Event_EventArgs $args
	 */
	public function onPostDispatchBackendConfig(Enlight_Event_EventArgs $args)
	{
		PayItEasyCw_Components_ActionHandlers_Config::call($args->getRequest()
		->getActionName(), $args, $this->getId());
	}

	/**
	 * This post-dispatch event-hook extends the backend index controller.
	 *
	 * @param \Enlight_Event_EventArgs $args
	 */
	public function onPostDispatchBackendIndex(Enlight_Event_EventArgs $args)
	{
		
		$arguments = array(
			'args' => $args,
 		);
		return Customweb_Licensing_PayItEasyCw_License::run('6u4fnp21p9g1hnvi', $this, $arguments);
	}

	public function call_lslotuhm7u0v1tsg() {
		$arguments = func_get_args();
		$method = $arguments[0];
		$call = $arguments[1];
		$parameters = array_slice($arguments, 2);
		if ($call == 's') {
			return call_user_func_array(array(get_class($this), $method), $parameters);
		}
		else {
			return call_user_func_array(array($this, $method), $parameters);
		}
		
		
	}

	/**
	 * This event-hook registers the backend form controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetBackendFormController()
	{
		return $this->Path() . 'Controllers/Backend/Payiteasycw/Form.php';
	}

	/**
	 * This event-hook registers the backend transactions controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetBackendTransactionsController()
	{
		return $this->Path() . 'Controllers/Backend/Payiteasycw/Transactions.php';
	}

	/**
	 * This event-hook registers the backend base controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetBackendBaseController()
	{
		return $this->Path() . 'Controllers/Backend/Payiteasycw/Base.php';
	}

	/**
	 * This event-hook registers the backend base transaction controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetBackendBaseTransactionController()
	{
		return $this->Path() . 'Controllers/Backend/Payiteasycw/Base/Transaction.php';
	}

	/**
	 * This event-hook registers the frontend redirection controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetFrontendRedirectionController()
	{
		return $this->Path() . 'Controllers/Frontend/PayItEasyCw/Redirection.php';
	}

	/**
	 * This event-hook registers the frontend process controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetFrontendProcessController()
	{
		return $this->Path() . 'Controllers/Frontend/PayItEasyCw/Process.php';
	}

	/**
	 * This event-hook registers the frontend checkout controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetFrontendCheckoutController()
	{
		return $this->Path() . 'Controllers/Frontend/PayItEasyCw/Checkout.php';
	}

	/**
	 * This event-hook registers the frontend external checkout controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetFrontendExternalCheckoutController()
	{
		return $this->Path() . 'Controllers/Frontend/PayItEasyCw/ExternalCheckout.php';
	}

	/**
	 * This event-hook registers the frontend endpoint controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetFrontendEndpointController()
	{
		return $this->Path() . 'Controllers/Frontend/PayItEasyCw/Endpoint.php';
	}

	/**
	 * This event-hook registers the frontend payment controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetFrontendPaymentController()
	{
		return $this->Path() . 'Controllers/Frontend/PaymentPayiteasycw.php';
	}

	/**
	 * This event-hook registers the transaction api controller.
	 *
	 * @return string Path to the file with the controller class
	 */
	public function onGetTransactionsApiController()
	{
		return $this->Path() . 'Controllers/Api/PayiteasycwTransactions.php';
	}

	public function onBeforeCartAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$session = Shopware()->Session();
		if (isset($session['PayItEasyCwCheckoutError']) && !empty($session['PayItEasyCwCheckoutError'])) {
			$view->assign('payiteasycwerrorMessage', $session['PayItEasyCwCheckoutError']);
			$session['PayItEasyCwCheckoutError'] = '';
		}

		$context = PayItEasyCw_Helpers_Util::loadExternalCheckoutContext();
		if ($context !== null && $context->getState() == Customweb_Payment_ExternalCheckout_IContext::STATE_FAILED) {
			$view->assign('payiteasycwexternalCheckoutErrorMessage', $context->getFailedErrorMessage());
		}

		return $args->getReturn();
	}

	public function onAfterCartAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$view->extendsTemplate('frontend/checkout/payiteasycw/cartErrorMessage.tpl');

		$widgets = PayItEasyCw_Components_ExternalCheckoutWidgets::getAllWidgets();
		if (!empty($widgets)) {
			$view->extendsTemplate('frontend/checkout/payiteasycw/externalCheckoutList.tpl');
			$view->assign('widgets', $widgets);
		}

		return $args->getReturn();
	}

	/**
	 * This event-hook includes the payment form into the checkout process.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return bool
	 */
	public function onConfirmAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();

		$session = Shopware()->Session();

		$session['payiteasycwTransactionId'] = null;

		$paymentData = $caller->getSelectedPayment();
		if (!empty($paymentData['id'])) {
			$payment = Shopware()->Models()->find('Shopware\Models\Payment\Payment', $paymentData['id']);

			if ($payment instanceof Shopware\Models\Payment\Payment &&  $payment->getPluginId() == $this->getId() && $order instanceof Shopware\Models\Order\Order) {
				$wrapper = new PayItEasyCw_Components_PaymentMethodWrapper($payment);

				if ($order->getInvoiceAmount() > 0 || $wrapper->getPaymentMethodConfigurationValue('zero_checkout') != 'skip') {
					$orderContext = $wrapper->getOrderContext($order->getId());
					$paymentCustomerContext = PayItEasyCw_Helpers_Util::loadPaymentCustomerContextByCustomer($order->getCustomer()->getId());

					if ($wrapper->getPaymentMethodConfigurationValue('form_position') == 'checkout') {
						$view->extendsTemplate('frontend/checkout/payiteasycw/Confirm.tpl');

						$view->assign('alias', $wrapper->generateAliasSelect($orderContext));
						$view->assign('visibleFieldsUrl', PayItEasyCw_Helpers_Util::getUrl(array('controller' => 'PayItEasyCwCheckout', 'action' => 'getAliasData', 'forceSecure' => true)));
						$view->assign('orderUrl', PayItEasyCw_Helpers_Util::getUrl(array('controller' => 'PayItEasyCwCheckout', 'action' => 'saveForm', 'forceSecure' => true)));
						$view->assign('paymentMethodId', $payment->getId());
						$view->assign('visibleFormFields', $wrapper->generateVisibleFormFields($orderContext, $paymentCustomerContext));
						$view->assign('formHeading', Customweb_I18n_Translation::__('Payment Form'));
						$view->assign('processingLabel', Customweb_I18n_Translation::__('Processing'));
						$view->assign('javascriptRequiredMessage', Customweb_I18n_Translation::__('Javascript is required to checkout.'));
						$view->assign('authorizationMethod', $wrapper->getAuthorizationMethodName($orderContext));
						$view->assign('agbErrorMessage', Customweb_I18n_Translation::__('Please confirm the general terms and conditions'));
					} else {
						$view->assign('processingLabel', Customweb_I18n_Translation::__('Processing'));
						$view->extendsTemplate('frontend/checkout/payiteasycw/Checkout.tpl');
					}

					if (isset($session['PayItEasyCwCheckoutError']) && !empty($session['PayItEasyCwCheckoutError'])) {
						$view->assign('errorMessage', $session['PayItEasyCwCheckoutError']);
						$session['PayItEasyCwCheckoutError'] = '';
					}
				}
			} else {
				$view->assign('processingLabel', Customweb_I18n_Translation::__('Processing'));
				$view->extendsTemplate('frontend/checkout/payiteasycw/Checkout.tpl');
			}
		}

		return true;
	}

	public function onFinishAction(Enlight_Event_EventArgs $args)
	{
		$session = Shopware()->Session();
		$session['payiteasycwTransactionId'] = null;

		$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $session['sOrderVariables']['sOrderNumber']));
		if ($order != null && $order->getPayment()->getPluginId() == $this->getId()) {
			$transactionId = Shopware()->Front()->Request()->getParam('cstrxid');
			if (!empty($transactionId)) {
				Shopware()->System()->_POST['sBooking'] = 'payiteasycw-' . $transactionId;
			}
		}
		return $args->getReturn();
	}

	public function onAfterFinishAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$session = Shopware()->Session();
		$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $session['sOrderVariables']['sOrderNumber']));
		if ($order != null && $order->getPayment()->getPluginId() == $this->getId()) {
			$transactionId = Shopware()->Front()->Request()->getParam('cstrxid');
			if (!empty($transactionId)) {
				$transaction = PayItEasyCw_Helpers_Util::loadTransaction($transactionId);

				$view->assign('paymentInformation', $transaction->getTransactionObject()->getPaymentInformation());
				$view->assign('paymentInformationLabel', Customweb_I18n_Translation::__('Payment Information'));
				$view->extendsTemplate('frontend/checkout/payiteasycw/Finish.tpl');
			}
		}
	}

	public function onAjaxCartAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$widgets = PayItEasyCw_Components_ExternalCheckoutWidgets::getAllWidgets();
		if (!empty($widgets)) {
			$view->extendsTemplate('frontend/checkout/payiteasycw/externalCheckoutAjaxCartList.tpl');
			$view->assign('widgets', $widgets);
		}
	}

	public function onOrderSendMailCreate(Enlight_Event_EventArgs $args)
	{
		$context = $args->getContext();
		$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $context['sOrderNumber']));
		if ($order != null && $order->getPayment()->getPluginId() == $this->getId()) {
			if (!PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
				$transactionId = substr($context['sBookingID'], strlen('payiteasycw-'));
				$transaction = PayItEasyCw_Helpers_Util::loadTransaction($transactionId);

				$context['paymentInformationHtml'] = $transaction->getTransactionObject()->getPaymentInformation();
				$context['paymentInformationPlain'] = Customweb_Core_Util_Html::toText($transaction->getTransactionObject()->getPaymentInformation());
				$mail = Shopware()->TemplateMail()->createMail('sORDER', $context);
				$args->setReturn($mail);
			} elseif (PayItEasyCw_Helpers_Util::isCreateOrderBefore() && PayItEasyCw_Components_Order::isForceSendEmail()) {
				$transaction = PayItEasyCw_Components_Order::getCurrentTransaction();

				$context['paymentInformationHtml'] = $transaction->getTransactionObject()->getPaymentInformation();
				$context['paymentInformationPlain'] = Customweb_Core_Util_Html::toText($transaction->getTransactionObject()->getPaymentInformation());
				$mail = Shopware()->TemplateMail()->createMail('sORDER', $context);
				$args->setReturn($mail);
			} else {
				PayItEasyCw_Components_Order::setEmailVariables(array(
					'variables' => $args->getVariables(),
					'sUserData' => $args->getSubject()->sUserData
				));
			}
		}
		return $args->getReturn();
	}

	public function onOrderSendMailSend(Enlight_Event_EventArgs $args)
	{
		$context = $args->getContext();
		$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $context['sOrderNumber']));
		if ($order != null && $order->getPayment()->getPluginId() == $this->getId()) {
			if (PayItEasyCw_Helpers_Util::isCreateOrderBefore() && !PayItEasyCw_Components_Order::isForceSendEmail()) {
				$args->setReturn(true);
			}
		}
		return $args->getReturn();
	}

	public function onGetMinimumCharge(Enlight_Event_EventArgs $args)
	{
		$transactionId = Shopware()->Front()->Request()->getParam('cstrxid');
		if (!empty($transactionId)) {
			$args->setReturn(false);
		}
		return $args->getReturn();
	}

	public function onGetDispatchNoOrder(Enlight_Event_EventArgs $args)
	{
		$transactionId = Shopware()->Front()->Request()->getParam('cstrxid');
		if (!empty($transactionId)) {
			$args->setReturn(false);
		}
		return $args->getReturn();
	}

	public function onOrdersAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$orderData = $view->getAssign('sOpenOrders');
		foreach ($orderData as $orderKey => $order) {
			$transactions = PayItEasyCw_Helpers_Util::loadTransactionsByOrder($order['id']);
			if (!empty($transactions)) {
				$transactionObject = current($transactions)->getTransactionObject();
				if ($transactionObject != null && $transactionObject instanceof Customweb_Payment_Authorization_ITransaction) {
					$orderData[$orderKey]['payiteasycwPaymentInformation'] = $transactionObject->getPaymentInformation();
				}
			}
		}

		$view->assign('paymentInformationLabel', Customweb_I18n_Translation::__('Payment Information'));
		$view->assign('sOpenOrders', $orderData);
		$view->extendsTemplate('frontend/account/payiteasycw/OrderItem.tpl');
		return $args->getReturn();
	}

	public function onLoginAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$sTarget = $caller->Request()->getParam('sTarget');
		if ($sTarget == 'PayItEasyCwExternalCheckout') {
			$context = PayItEasyCw_Helpers_Util::loadExternalCheckoutContext();
			if (empty($view->sFormData)) {
				$view->sFormData = array(
					'email' => $context->getAuthenticationEmailAddress()
				);
			}
			$view->assign('contextId', $context->getContextId());
			$view->extendsTemplate('frontend/account/payiteasycw/Login.tpl');
		}
		return $args->getReturn();
	}

	public function onRegisterAction(Enlight_Event_EventArgs $args)
	{
		$caller = $args->getSubject();
		$view = $caller->View();

		$sTarget = $caller->Request()->getParam('sTarget');
		if ($sTarget == 'PayItEasyCwExternalCheckout') {
			$context = PayItEasyCw_Helpers_Util::loadExternalCheckoutContext();
			$session = Shopware()->Session();
			if (!empty($session['sUserId'])) {
				$context->update();
				PayItEasyCw_Helpers_Util::getEntityManager()->persist($context);
				return $caller->redirect($context->getAuthenticationSuccessUrl());
			}

			$register = Shopware()->Session()->sRegister;
			$billingAddress = $context->getBillingAddress();
			$shippingAddress = $context->getShippingAddress();
			$country = PayItEasyCw_Helpers_Util::getCountryByAddress($billingAddress);
			$contextRegister = array(
				'auth' => array(
					'email' => $context->getAuthenticationEmailAddress(),
				),
				'billing' => array(
					'firstname' => $billingAddress->getFirstName(),
					'lastname' => $billingAddress->getLastName(),
					'phone' => $billingAddress->getPhoneNumber(),
					'birthyear' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('Y') : null,
					'birthmonth' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('n') : null,
					'birthday' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('j') : null,
					'company' => $billingAddress->getCompanyName(),
					'street' => $billingAddress->getStreet(),
					'zipcode' => $billingAddress->getPostCode(),
					'city' => $billingAddress->getCity(),
					'country' => $country != null ? $country->getId() : null,
					'shippingAddress' => 1
				),
				'shipping' => array(
					'firstname' => $shippingAddress->getFirstName(),
					'lastname' => $shippingAddress->getLastName(),
					'company' => $shippingAddress->getCompanyName(),
					'street' => $shippingAddress->getStreet(),
					'zipcode' => $shippingAddress->getPostCode(),
					'city' => $shippingAddress->getCity(),
					'country' => $country != null ? $country->getId() : null,
				)
			);
			if ($billingAddress->getGender() == 'male') {
				$contextRegister['billing']['salutation'] = 'mr';
			} elseif ($billingAddress->getGender() == 'female') {
				$contextRegister['billing']['salutation'] = 'ms';
			}
			if ($shippingAddress->getGender() == 'male') {
				$contextRegister['shipping']['salutation'] = 'mr';
			} elseif ($shippingAddress->getGender() == 'female') {
				$contextRegister['shipping']['salutation'] = 'ms';
			}
			$register = array_replace_recursive($register, $contextRegister);
			Shopware()->Session()->sRegister = $register;

			$view->assign('externalCheckoutContextId', $context->getContextId());
			$view->extendsTemplate('frontend/register/payiteasycw/Register.tpl');
		}
		return $args->getReturn();
	}

	public static $paymentValidationDisabled = false;

	protected static $paymentValidationBeforeCache = array();

	/**
	 * Prevent the risk management if in prevalidation.
	 *
	 * @param Enlight_Hook_HookArgs $args
	 */
	public function onManageRisk(Enlight_Hook_HookArgs $args)
	{
		if (self::$paymentValidationDisabled) {
			$args->setReturn(false);
		} else {
			$args->setReturn(
				$args->getSubject()->executeParent(
						$args->getMethod(),
						$args->getArgs()
				)
			);
		}
	}

	/**
	 * Validate the payment methods before showing them.
	 *
	 * @param Enlight_Hook_HookArgs $args
	 */
	public function onAfterManageRisk(Enlight_Hook_HookArgs $args)
	{
		$returnValue = $args->getReturn();

		if ($returnValue || self::$paymentValidationDisabled) {
			$args->setReturn($returnValue);
			return $args->getReturn();
		}

		$parameters = $args->getArgs();

		$paymentId = $parameters[0];
		if ($paymentId != null) {
			if (!isset(self::$paymentValidationBeforeCache[$paymentId])) {
				$payment = Shopware()->Models()
					->find('Shopware\Models\Payment\Payment', $paymentId);

				if ($payment instanceof Shopware\Models\Payment\Payment && $payment->getPluginId() == $this->getId()) {
					$wrapper = new PayItEasyCw_Components_PaymentMethodWrapper($payment);

					$basket = $parameters[1];
					if(empty($basket)) {
						$session = Shopware()->Session();
						$basket = array(
							'content' => $session->sBasketQuantity,
							'AmountNumeric' => $session->sBasketAmount
						);
					}
					$amount = $basket['AmountNumeric'];

					self::$paymentValidationBeforeCache[$paymentId] = !$wrapper->validateBefore($amount);
				}
			}

			if (!isset(self::$paymentValidationBeforeCache[$paymentId])) {
				$args->setReturn($returnValue);
				return $args->getReturn();
			}
			$args->setReturn(self::$paymentValidationBeforeCache[$paymentId]);
		}
		return $args->getReturn();
	}

	protected static $paymentValidationAfterCache = array();

	/**
	 * Validate the payment methods after selecting them.
	 *
	 * @param Enlight_Hook_HookArgs $args
	 */
	public function onValidatePayment(Enlight_Hook_HookArgs $args)
	{
		$returnValue = $args->getReturn();

		if (!is_array($returnValue) || self::$paymentValidationDisabled) {
			$args->setReturn($returnValue);
			return $args->getReturn();
		}

		$paymentId = $returnValue['paymentData']['id'];
		if ($paymentId != null) {
			if (!isset(self::$paymentValidationAfterCache[$paymentId])) {
				$payment = Shopware()->Models()
					->find('Shopware\Models\Payment\Payment', $paymentId);

				if ($payment instanceof Shopware\Models\Payment\Payment && $payment->getPluginId() == $this->getId()) {
					$wrapper = new PayItEasyCw_Components_PaymentMethodWrapper($payment);

					try {
						$wrapper->validateAfter();
					} catch(Exception $e) {
						$returnValue['checkPayment'] = array(
							'sErrorFlag' => true,
							'sErrorMessages' => array($e->getMessage())
						);
					}

					self::$paymentValidationAfterCache[$paymentId] = $returnValue;
				}
			}

			if (!isset(self::$paymentValidationAfterCache[$paymentId])) {
				$args->setReturn($returnValue);
				return $args->getReturn();
			}
			$args->setReturn(self::$paymentValidationAfterCache[$paymentId]);
		}
		return $args->getReturn();
	}

	/**
	 * Set the booking id on the sOrder instance to prevent duplicate orders.
	 *
	 * @param Enlight_Hook_HookArgs $args
	 */
	public function onSaveOrder(Enlight_Hook_HookArgs $args)
	{
		$sOrder = $args->getSubject();
		$bookingId = Shopware()->System()->_POST['sBooking'];
		if (!empty($bookingId) && strpos($bookingId, 'payiteasycw-') === 0) {
			$sOrder->bookingId = $bookingId;
		}
		return $args->getReturn();
	}

	/**
	 * Update the transaction object after completing the order.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return boolean
	 */
	public function onOrderSave(Enlight_Event_EventArgs $args)
	{
		$order = $args->getSubject();
		$orderNumber = $order->sOrderNumber;

		$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $orderNumber));

		$wrapper = new PayItEasyCw_Components_PaymentMethodWrapper($order->getPayment());
		if ($order->getInvoiceAmount() == 0 && $wrapper->getPaymentMethodConfigurationValue('zero_checkout') == 'skip') {
			return true;
		}

		if (!PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			$transactionId = Shopware()->Front()->Request()->getParam('cstrxid');
			if ($order != null && $order->getPayment()->getPluginId() == $this->getId()) {
				$transaction = PayItEasyCw_Helpers_Util::loadTransaction($transactionId);
				$transaction->setOrderId($order->getId());
				$transaction->setShopId($order->getLanguageSubShop()->getId());
				$transaction->setTemporaryOrderId(null);
				$transaction->setLastSetOrderStatusSettingKey(null);
				if ($transaction->getTransactionObject()->getTransactionContext() instanceof PayItEasyCw_Components_RecurringTransactionContext) {
					$wrapper->finishRecurring($transaction, $order);
				}
				PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);
			}
		}

		return true;
	}

	public function onSaveRegisterFilterNeededFields(Enlight_Event_EventArgs $args)
	{
		if (PayItEasyCw_Components_ExternalCheckoutService::isActive()) {
			$fields = $args->getReturn();
			unset($fields['billing'][array_search('salutation', $fields['billing'])]);
			unset($fields['billing'][array_search('streetnumber', $fields['billing'])]);
			return $fields;
		} else {
			return $args->getReturn();
		}
	}

	public function onExternalCheckoutWidgetCollect(Enlight_Event_EventArgs $args)
	{
		$fields = $args->getReturn();
		$fields = array_merge($fields, PayItEasyCw_Components_ExternalCheckoutWidgets::getWidgets());
		return $fields;
	}

	public function onDocumentOrderToArray(Enlight_Event_EventArgs $args)
	{
		$subject = $args->getSubject();
		if ($subject->_order->payment['pluginID'] == $this->getId()) {
			$transactions = PayItEasyCw_Helpers_Util::loadTransactionsByOrder($subject->_order->id);
			if (!empty($transactions)) {
				$transactionObject = current($transactions)->getTransactionObject();
				if ($transactionObject != null && $transactionObject instanceof Customweb_Payment_Authorization_ITransaction) {
					$subject->_view->assign('PaymentInformation', $transactionObject->getPaymentInformation());
				}
			}
		}
	}

	public function runCronJob(Shopware_Components_Cron_CronJob $job)
	{
		try {
			$packages = array(
			0 => 'Customweb_PayItEasy',
 			1 => 'Customweb_Payment_Authorization',
 		);
			$packages[] = 'PayItEasyCw_Components_';
			$packages[] = 'Customweb_Payment_Update_ScheduledProcessor';
			$cronProcessor = new Customweb_Cron_Processor(PayItEasyCw_Helpers_Util::createContainer(), $packages);
			$cronProcessor->run();
		} catch (Exception $e) {}

		return true;
	}

	/**
	 * Return all payment methods of this plugin.
	 *
	 * @return Zend_Db_Table_Rowset
	 */
	protected function getPayments()
	{
		return Shopware()->Models()->getRepository('Shopware\Models\Payment\Payment')->findBy(array('pluginId' => $this->getId()));
	}

	/**
	 * Helper function to check if the table is realy exist.
	 * @param $tableName
	 *
	 * @return bool
	 */
	protected function tableExist($tableName)
	{
		$sql = "SHOW TABLES LIKE '" . $tableName . "'";
		$result = Shopware()->Db()->fetchRow($sql);
		return !empty($result);
	}

	protected function getTemplateDirectory()
	{
		$templateDirectory = '/Templates/';
		try {
			if (Shopware()->Shop()->getTemplate()->getVersion() == 2) {
				$templateDirectory = '/Views/';
			}
		} catch (Exception $e) {
			$templateDirectory = '/Views/';
		}
		return $this->Path() . $templateDirectory;
	}
}
