if(typeof window.Customweb == 'undefined'){
	window.Customweb = {};
}

if(typeof Customweb.PayItEasyCw == 'undefined'){
	Customweb.PayItEasyCw = {};
}

Customweb.PayItEasyCw.Checkout = {
	init: function(processingLabel, orderUrl, visibleFieldsUrl, paymentMethod, authorizationMethod) {
		this.processingLabel = processingLabel;
		this.orderUrl = orderUrl;
		this.visibleFieldsUrl = visibleFieldsUrl;
		this.paymentMethod = paymentMethod;
		this.authorizationMethod = authorizationMethod;
		
		this.attachListeners();
		
		this.getPaymentFormElement().show();
		$('.table--actions.actions--bottom').show();
		$('#payiteasycw-javascript-required').hide();
		
		return this;
	},
	
	/**
	 * The method name of the currently selected method.
	 * 
	 * @return boolean|string
	 */
	paymentMethod: false,
	
	/**
	 * The current authorization method name.
	 * 
	 * @return boolean|string
	 */
	authorizationMethod: false,
	
	/**
	 * Enforce skipping the form validation.
	 * 
	 * @return boolean
	 */
	skipValidation: false,

	/**
	 * Removes on the payment list selection page all form field names to prevent the sending of the directly to the server.
	 * 
	 * @return void
	 */
	removeFormFieldNames: function() {
		this.getPaymentFormElement().find('*[name]').each(function (element) {
			$(this).attr('data-field-name', $(this).attr('name'));
			$(this).removeAttr('name');
		});
	},
	
	/**
	 * This method returns the form fields loaded by JavaScript. These fields should not be
	 * send to the shopping cart.
	 * 
	 * @return List<Object>
	 */
	getDynamicFormValues: function(removeHidden) {
		var output = {};
		this.getPaymentFormElement().find('*[data-field-name]').each($.proxy(function (key, element) {
			var name = $(element).attr('data-field-name');
			if (removeHidden && $(element).attr('type') == 'hidden' && !$(element).attr('originalelement')) {
				return;
			}
			if (name && name != 'alias') {
				output[name] = $(element).val();
			}
		}, this));
		return output;
	},
	
	getCheckoutFormValues: function() {
		var output = {};
		$.each(this.getCheckoutFormElement().serializeArray(), function(index, element){
			output[element.name] = element.value;
		});
		return output;
	},
	
	renderDataAsHiddenFields: function(data) {
		var me = this,
			output = '';
		$.each(data, function(key, value) {
			if ($.isArray(value)) {
				for (var i = 0; i < value.length; i++) {
					output += me.renderHiddenField(key + '[]', value[i]);
				}
			} else {
				output += me.renderHiddenField(key, value);
			}
		});
		return output;
	},
	
	renderHiddenField: function(key, value) {
		if (typeof value == 'string') {
			value = value.replace(/"/g, "&quot;");
		}
		return '<input type="hidden" name="' + key + '" value="' + value + '" />';
	},
	
	/**
	 * This method validates the payment form. In case it is invalid the method returns 
	 * false otherwise it returns true.
	 * 
	 * @return boolean
	 */
	validatePaymentForm: function() {
		this.cleanUpErrorMessages();
		if (this.skipValidation) {
			return true;
		}
		return Customweb.PayItEasyCw.Validation.validate(this.getPaymentFormElement().attr('id'));
	},
	
	attachListeners: function() {
		$('*').unbind('.payiteasycw');
		this.attachSubmitButtonHandler();
		this.attachFormSubmitHandler();
		this.attachAliasSelectHandler();
		this.removeFormFieldNames();
	},
	
	attachSubmitButtonHandler: function(event) {
		this.getSubmitElement().off('click');
		this.getSubmitElement().bind('click.payiteasycw', $.proxy(function(event){
			this.getCheckoutFormElement().submit();
			event.preventDefault();
			return false;
		}, this));
	},
	
	attachFormSubmitHandler: function() {
		this.getCheckoutFormElement().bind('submit.payiteasycw', $.proxy(function(event) {
			this.handleFormSubmitEvent();
			event.preventDefault();
			return false;
		}, this));
	},
	
	attachAliasSelectHandler: function() {
		$('#aliasField select[name=alias]').attr('id', 'aliasSelect');
		this.getAliasSelectElement().bind('change.payiteasycw', $.proxy(function(){
			this.loadAliasData();
		}, this));
	},
	
	handleFormSubmitEvent: function() {
		if (!this.validatePaymentForm()) {
			return;
		}
		
		this.setLoadingIndicator(true);
		this.blockUI();
		
		$.ajax({
			type: 'POST',
			url: this.orderUrl,
			data: this.createDataForAjaxCall(),
			success: $.proxy(function(response){
				this.handleAjaxResponse(response);
			}, this)
		});
	},
	
	createDataForAjaxCall: function() {
		if (this.authorizationMethod == 'AjaxAuthorization' || this.authorizationMethod == 'HiddenAuthorization') {
			parameters = this.getCheckoutFormValues();
		} else {
			parameters = $.extend({}, this.getDynamicFormValues(), this.getCheckoutFormValues());
		}
		if (this.getAliasSelectElement().size()) {
			parameters['alias'] = this.getAliasSelectElement().val();
		}
		return parameters;
	},
	
	handleAjaxResponse: function(response) {
		try {
			var objects = $.parseJSON(response);
		}
		catch(e) {
			this.handleAjaxFailure('An unknown error occurred.');
			return false;
		}
		
		if (objects.error) {
			this.handleAjaxFailure(objects.error);
			return false;
		} else if (objects.redirect) {
			document.location = objects.redirect;
		} else {
			this.startPayment(objects);
		}
	},
	
	handleAjaxFailure: function(errorMessage) {
		this.getErrorElement().removeClass('is--hidden');
		this.getErrorElement().find('.alert--content').html(errorMessage);
		$(window).scrollTop(0);
		this.unblockUI();
		this.setLoadingIndicator(false);
	},
	
	startPayment: function(response) {
		if (this.authorizationMethod == 'AjaxAuthorization') {
			$.getScript(response.ajaxScriptUrl, $.proxy(function(){
				eval("var callbackFunction = " + response.ajaxSubmitCallback);
				callbackFunction($.extend(this.getDynamicFormValues(true), response.hiddenFields));
			}, this));
		} else {
			this.sendDataAsForm(response.formActionUrl, $.extend(this.getDynamicFormValues(true), response.hiddenFields));
		}
	},
	
	sendDataAsForm: function(url, values) {
		var newForm = '<form id="payiteasycw_redirect_form" action="' + url + '" method="POST">';
		newForm += this.renderDataAsHiddenFields(values);
		newForm += '</form>';
		$('body').append(newForm);
		$('#payiteasycw_redirect_form').submit();
	},
	
	loadAliasData: function() {
		this.setLoadingIndicator(true);
		this.blockUI();
		$.getJSON(this.visibleFieldsUrl, {
			aliasId: this.getAliasSelectElement().val(),
			paymentMethod: this.paymentMethod
		}, $.proxy(function(response){
			this.setLoadingIndicator(false);
			this.unblockUI();
			
			if (response.error) {
				this.handleAjaxFailure(objects.error);
				return false;
			}
			
			$('#visibleFormFields').html(response.visibleFormFields.fields);
			$('#visibleFormValidation').html(response.visibleFormFields.validation);
			this.removeFormFieldNames();
			this.aliasId = this.getAliasSelectElement().val();
		}, this));
	},

	setLoadingIndicator: function(flag) {
		if (flag) {
			this.getSubmitElement().data('htmlBackup', this.getSubmitElement().html());
			this.getSubmitElement().html(this.getSubmitElement().text() + '<div class="js--loading"></div>').attr('disabled', 'disabled');
		} else {
			this.getSubmitElement().html(this.getSubmitElement().data('htmlBackup')).removeAttr('disabled');
		}
	},
	
	/**
	 * This method returns an element which should be blocked during AJAX calls.
	 * 
	 * @return Object
	 */
	getBlockingElement: function() {
		var blockingElement = this.getPaymentFormElement();
		if (typeof blockingElement === 'undefined' || blockingElement.length <= 0) {
			return $('body');
		}
		else {
			return blockingElement;
		}
	},
	
	/**
	 * This method blocks the user from entering other data. This method should be called
	 * before any AJAX call is executed.
	 * 
	 * @return void
	 */
	blockUI: function() {
		var element = this.getBlockingElement();
		var height = element.outerHeight();
		var width = element.outerWidth();
		var offset = element.position();
		element.append('<div class="payiteasycw-ajax-overlay"></div>');
		element.find('.payiteasycw-ajax-overlay').height(height).width(width).css({zIndex: 10000, top: offset.top, left: offset.left, position:'absolute'});
	},
	
	/**
	 * This method unblocks the user interface and allows the user do do any user action.
	 * 
	 * @return void
	 */
	unblockUI: function() {
		this.getBlockingElement().find('.payiteasycw-ajax-overlay').remove();
	},
	
	cleanUpErrorMessages: function() {
		$('#payiteasycw-errors').html('');
		this.getErrorElement().addClass('is--hidden');
	},
	
	getSubmitElement: function() {
		return $('.table--actions.actions--bottom button[type="submit"]');
	},
	
	getErrorElement: function() {
		return $('#payiteasycw-ajax-errors div.alert');
	},
	
	getPaymentFormElement: function() {
		return $('#payiteasycw-payment-form');
	},
	
	getCheckoutFormElement: function() {
		return $('#confirm--form');
	},
	
	getAliasSelectElement: function() {
		return $('#aliasSelect');
	}
};