<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * Util helper
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Helpers_Util extends Enlight_Class {
	/**
	 *
	 * @var Customweb_DependencyInjection_Container_Default
	 */
	private static $container = null;

	/**
	 *
	 * @var Customweb_Database_Entity_Manager
	 */
	private static $entityManager = null;

	/**
	 *
	 * @var Customweb_Database_Driver_PDO_Driver
	 */
	private static $driver = null;

	/**
	 *
	 * @var Customweb_Payment_Endpoint_Dispatcher
	 */
	private static $endpointDispatcher = null;

	/**
	 *
	 * @var string
	 */
	private static $pluginPath = null;

	/**
	 *
	 * @var Shopware\Models\Order\Order
	 */
	private static $temporaryOrder = null;

	/**
	 *
	 * @param string $path
	 */
	public static function setPluginPath($path){
		self::$pluginPath = $path;
	}

	/**
	 *
	 * @return Customweb_DependencyInjection_Container_Default
	 */
	public static function createContainer(){
		if (self::$container === null) {
			$packages = array(
			0 => 'Customweb_PayItEasy',
 			1 => 'Customweb_Payment_Authorization',
 		);
			$packages[] = 'PayItEasyCw_Components_';
			$packages[] = 'PayItEasyCw_Entities_';
			$packages[] = 'Customweb_Payment_Alias_Handler';
			$packages[] = 'Customweb_Payment_TransactionHandler';
			$packages[] = 'Customweb_Payment_SettingHandler';
			$packages[] = 'Customweb_Mvc_Template_Smarty_Renderer';

			$provider = new Customweb_DependencyInjection_Bean_Provider_Editable(
					new Customweb_DependencyInjection_Bean_Provider_Annotation($packages));
			$provider->addObject(self::getEntityManager())->addObject(self::getDriver())->addObject(
					PayItEasyCw_Components_Request::getInstance())->addObject(self::getAssetResolver())->addObject(
					self::getSmartyContainerBean())->add('databaseTransactionClassName', 'PayItEasyCw_Entities_Transaction')->add(
					'storageDatabaseEntityClassName', 'PayItEasyCw_Entities_Storage');
			self::$container = new Customweb_DependencyInjection_Container_Default($provider);
		}

		return self::$container;
	}

	/**
	 *
	 * @return Customweb_Asset_IResolver
	 */
	public static function getAssetResolver(){
		$basePath = self::$pluginPath;
		$baseUrl = str_replace(rtrim(Shopware()->DocPath(), '/'), rtrim(self::getUrl(array(
			'controller' => 'index',
			'action' => 'index'
		)), '/'), $basePath);

		return new Customweb_Asset_Resolver_Composite(
				array(
					new Customweb_Asset_Resolver_Simple($basePath . 'Templates/frontend/assets/payiteasycw/',
							$baseUrl . 'Templates/frontend/assets/payiteasycw/', array(
								'application/x-smarty'
							)),
					new Customweb_Asset_Resolver_Simple($basePath . 'Views/frontend/assets/payiteasycw/',
							$baseUrl . 'Views/frontend/assets/payiteasycw/', array(
								'application/x-smarty'
							)),
					new Customweb_Asset_Resolver_Simple($basePath . 'Assets/', $baseUrl . 'Assets/')
				));
	}

	/**
	 *
	 * @return Customweb_Mvc_Template_IRenderer
	 */
	public static function getTemplateRenderer(){
		return self::createContainer()->getBean('Customweb_Mvc_Template_IRenderer');
	}

	/**
	 *
	 * @return Customweb_Mvc_Template_Smarty_ContainerBean
	 */
	private static function getSmartyContainerBean(){
		return new Customweb_Mvc_Template_Smarty_ContainerBean(clone Shopware()->Template());
	}

	/**
	 *
	 * @return Customweb_Payment_Endpoint_Dispatcher
	 */
	public static function getEndpointDispatcher(){
		if (self::$endpointDispatcher == null) {
			$container = self::createContainer();
			$packages = array(
			0 => 'Customweb_PayItEasy',
 			1 => 'Customweb_Payment_Authorization',
 		);
			$adapter = new PayItEasyCw_Components_EndpointAdapter();

			self::$endpointDispatcher = new Customweb_Payment_Endpoint_Dispatcher($adapter, $container, $packages);
		}
		return self::$endpointDispatcher;
	}

	/**
	 *
	 * @return Customweb_Database_Entity_Manager
	 */
	public static function getEntityManager(){
		if (self::$entityManager === null) {
			$cache = new Customweb_Cache_Backend_Memory();
			self::$entityManager = new Customweb_Database_Entity_Manager(self::getDriver(), $cache);
		}
		return self::$entityManager;
	}

	/**
	 *
	 * @return Customweb_Database_Driver_PDO_Driver
	 */
	public static function getDriver(){
		if (self::$driver === null) {
			$pdo = Shopware()->Db()->getConnection();
			self::$driver = new PayItEasyCw_Components_Driver($pdo);
		}
		return self::$driver;
	}

	/**
	 *
	 * @return Customweb_Storage_IBackend
	 */
	public static function getStorage(){
		$storage = self::createContainer()->getBean('Customweb_Storage_IBackend');
		if (!($storage instanceof Customweb_Storage_IBackend)) {
			throw new Exception("Storage must be of type 'Customweb_Storage_IBackend'");
		}
		return $storage;
	}

	protected static function getAuthorizationAdapterFactory(){
		$factory = self::createContainer()->getBean('Customweb_Payment_Authorization_IAdapterFactory');

		if (!($factory instanceof Customweb_Payment_Authorization_IAdapterFactory)) {
			throw new Exception("The payment api has to provide a class which implements 'Customweb_Payment_Authorization_IAdapterFactory' as a bean.");
		}

		return $factory;
	}

	/**
	 *
	 * @param string $authorizationMethodName
	 * @return Customweb_Payment_Authorization_IAdapter
	 */
	public static function getAuthorizationAdapter($authorizationMethodName){
		return self::getAuthorizationAdapterFactory()->getAuthorizationAdapterByName($authorizationMethodName);
	}

	/**
	 *
	 * @param Customweb_Payment_Authorization_IOrderContext $orderContext
	 * @return Customweb_Payment_Authorization_IAdapter
	 */
	public static function getAuthorizationAdapterByContext(Customweb_Payment_Authorization_IOrderContext $orderContext){
		return self::getAuthorizationAdapterFactory()->getAuthorizationAdapterByContext($orderContext);
	}

	/**
	 * Build and return a url out of the given parameters.
	 *
	 * @param array $params
	 * @return string
	 */
	public static function getUrl($params){
		$router = Shopware()->Front()->Router();
		if(PayItEasyCw_Components_Request::getInstance()->getProtocol() == 'HTTPS') {
			$params['forceSecure'] = true;
		}
		$url = $router->assemble($params);

		return $url;
	}

	/**
	 * Load and return a transaction object by transaction id or temporary order.
	 *
	 * @param string $transactionId
	 * @throws Exception
	 * @return PayItEasyCw_Entities_Transaction
	 */
	public static function loadTransaction($transactionId = null, $cache = true){
		$transaction = null;
		if (empty($transactionId)) {
			$order = self::getTemporaryOrder();
			if ($order instanceof Shopware\Models\Order\Order) {
				$transactions = PayItEasyCw_Helpers_Util::getEntityManager()->searchByFilterName('PayItEasyCw_Entities_Transaction',
						'loadByTemporaryOrderId', array(
							'>orderId' => $order->getId()
						), $cache);
				if (!empty($transactions)) {
					$transaction = end($transactions);
				}
			}
		}
		else {
			$transaction = PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_Transaction', $transactionId,
					$cache);
		}

		if (!($transaction instanceof PayItEasyCw_Entities_Transaction) || $transaction->getTransactionObject() == null) {
			throw new Exception("Not a valid transaction provided");
		}

		return $transaction;
	}

	/**
	 *
	 * @param string $paymentId
	 * @throws Exception
	 * @return PayItEasyCw_Entities_Transaction
	 */
	public static function loadTransactionByPaymentId($paymentId){
		$transactions = PayItEasyCw_Helpers_Util::getEntityManager()->searchByFilterName('PayItEasyCw_Entities_Transaction',
				'loadByPaymentId', array(
					'>paymentId' => $paymentId
				));
		if (!empty($transactions)) {
			$transaction = end($transactions);
		}

		if (!($transaction instanceof PayItEasyCw_Entities_Transaction) || $transaction->getTransactionObject() == null) {
			throw new Exception("Not a valid transaction provided");
		}

		return $transaction;
	}

	/**
	 * Load and return all transaction objects associated with the specified order.
	 *
	 * @param int $orderId
	 * @return array
	 */
	public static function loadTransactionsByOrder($orderId){
		return PayItEasyCw_Helpers_Util::getEntityManager()->searchByFilterName('PayItEasyCw_Entities_Transaction', 'loadByOrderId',
				array(
					'>orderId' => $orderId
				));
	}

	/**
	 * Load and return the initial transaction object of the specified order.
	 *
	 * @param int $orderId
	 * @return PayItEasyCw_Entities_Transaction|boolean
	 */
	public static function loadInitialTransactionByOrder($orderId){
		$transactions = PayItEasyCw_Helpers_Util::getEntityManager()->searchByFilterName('PayItEasyCw_Entities_Transaction',
				'loadByOrderId', array(
					'>orderId' => $orderId
				));
		if (is_array($transactions)) {
			foreach ($transactions as $transaction) {
				if ($transaction->getTransactionObject() != null && $transaction->getTransactionObject()->isAuthorized()) {
					return $transaction;
				}
			}
		}

		return false;
	}

	/**
	 *
	 * @param string $customerId
	 * @return PayItEasyCw_Entities_PaymentCustomerContext
	 */
	public static function loadPaymentCustomerContextByCustomer($customerId){
		$paymentContexts = PayItEasyCw_Helpers_Util::getEntityManager()->searchByFilterName(
				'PayItEasyCw_Entities_PaymentCustomerContext', 'loadByCustomerId', array(
					'>customerId' => $customerId
				));
		if (!empty($paymentContexts)) {
			$paymentContext = end($paymentContexts);
		}
		else {
			$paymentContext = new PayItEasyCw_Entities_PaymentCustomerContext();
			$paymentContext->setCustomerId($customerId);
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($paymentContext);
		}
		return $paymentContext;
	}

	/**
	 *
	 * @param int $basketId
	 * @return PayItEasyCw_Entities_ExternalCheckoutContext
	 */
	public static function loadExternalCheckoutContext(){
		$contextId = Shopware()->Session()->PayItEasyCwExternalCheckoutContextId;
		$context = PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_ExternalCheckoutContext', $contextId);
		if ($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext && $context != null && $context->getContextId()) {
			return $context;
		} else {
			return null;
		}
	}

	/**
	 * Get the id of the active session.
	 *
	 * @return string
	 */
	public static function getSessionId(){
		$sessionId = Shopware()->Session()->offsetGet('sessionId');
		if (empty($sessionId)) {
			$sessionId = session_id();
		}
		return $sessionId;
	}

	/**
	 * Return whether the specified order contains recurring items.
	 *
	 * @param int $orderId
	 * @return boolean
	 */
	public static function isOrderRecurring($orderId){
		if (Shopware()->Plugins()->get('Frontend')->getPluginId('SwagAboCommerce') != null) {
			try {
				$order = Shopware()->Models()->find('Shopware\Models\Order\Order', $orderId);
				$temporaryId = $order->getTemporaryId();
				if (!empty($temporaryId)) {
					$builder = Shopware()->Models()->createQueryBuilder();
					$builder->select(Shopware()->Models()->getExpressionBuilder()->count('basket.id'))->from('Shopware\Models\Order\Basket', 'basket')->innerJoin(
							'basket.attribute', 'attribute')->where('basket.sessionId = :sessionId')->andWhere(
							'attribute.swagAboCommerceDeliveryInterval IS NOT NULL')->setParameters(array(
						'sessionId' => self::getSessionId()
					));

					$count = $builder->getQuery()->getSingleScalarResult();

					return (bool) $count;
				}
				else {
					$aboOrder = Shopware()->Models()->getRepository('Shopware\CustomModels\SwagAboCommerce\Order')->findOneBy(
							array(
								'orderId' => $orderId
							));
					return ($aboOrder instanceof Shopware\CustomModels\SwagAboCommerce\Order);
				}
			}
			catch (Exception $e) {
				return false;
			}
		}

		return false;
	}

	/**
	 * Return the wrapper for the specified payment method.
	 *
	 * @param int $paymentId
	 * @return PayItEasyCw_Components_PaymentMethodWrapper
	 */
	public static function getPayment($paymentId){
		$payment = Shopware()->Models()->find('Shopware\Models\Payment\Payment', $paymentId);
		return new PayItEasyCw_Components_PaymentMethodWrapper($payment);
	}

	/**
	 * Return the current temporary order.
	 *
	 * @return Shopware\Models\Order\Order
	 */
	public static function getTemporaryOrder(){
		return Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array(
			'temporaryId' => self::getSessionId()
		));
	}

	/**
	 * Return the current temporary order, or create one if there is none.
	 *
	 * @return Shopware\Models\Order\Order
	 */
	public static function getOrCreateTemporaryOrder(){
		if (self::$temporaryOrder == null) {
			$userLoggedIn = Shopware()->Modules()->Admin()->sCheckUser();
			if (!empty($userLoggedIn)
					&& Shopware()->Modules()->Basket()->sCountBasket() >= 1
					&& !Shopware()->Modules()->Basket()->sCheckMinimumCharge()) {
				$checkout = new PayItEasyCw_Components_Checkout();
				$checkout->confirmAction();
				$checkout->postDispatch();
				self::$temporaryOrder = self::getTemporaryOrder();
			}
		}
		return self::$temporaryOrder;
	}

	/**
	 *
	 * @return array
	 */
	public static function getOrderStatusOptions(){
		return self::getStatusOptions('state');
	}

	/**
	 *
	 * @return array
	 */
	public static function getPaymentStatusOptions($customValues){
		$statuses = self::getStatusOptions('payment');
		if (is_array($customValues)) {
			return array_merge($customValues, $statuses);
		}
		return $statuses;
	}
	protected static $statusOptionsCache = array();

	protected static function getStatusOptions($group){
		if (!isset(self::$statusOptionsCache[$group])) {
			$states = Shopware()->Models()->getRepository('Shopware\Models\Order\Status')->findBy(array(
				'group' => $group
			));
			$options = array();
			foreach ($states as $status) {
				$options[] = array(
					'value' => (string) $status->getId(),
					'text' => $status->getDescription()
				);
			}
			self::$statusOptionsCache[$group] = $options;
		}
		return self::$statusOptionsCache[$group];
	}

	/**
	 *
	 * @param string $transactionId
	 * @return string
	 */
	public static function waitForNotification($transactionId){
		$maxTime = Customweb_Util_System::getMaxExecutionTime() - 2;
		$startTime = microtime(true);
		while (true) {
			if (microtime(true) - $startTime >= $maxTime) {
				break;
			}

			$transaction = PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_Transaction', $transactionId,
					false);
			if (!($transaction instanceof PayItEasyCw_Entities_Transaction) || $transaction->getTransactionObject() == null) {
				sleep(2);
				continue;
			}
			if ($transaction->getTransactionObject()->isAuthorized() && $transaction->getOrderId() !== null) {
				$order = Shopware()->Models()->find('Shopware\Models\Order\Order', $transaction->getOrderId());
				if ($order instanceof Shopware\Models\Order\Order) {
					$session = Shopware()->Session();

					if ($session->offsetExists('sOrderVariables')) {
						$variables = $session->offsetGet('sOrderVariables');
						$variables['sOrderNumber'] = $order->getNumber();
						$session->offsetSet('sOrderVariables', $variables);
					}
				}

				return PayItEasyCw_Helpers_Util::getUrl(
						array(
							'controller' => 'checkout',
							'action' => 'finish',
							'forceSecure' => true,
							'sAGB' => true,
							'cstrxid' => $transactionId
						));
			}
			if ($transaction->getTransactionObject()->isAuthorizationFailed()) {
				$errorMessages = $transaction->getTransactionObject()->getErrorMessages();
				$messageToDisplay = nl2br(end($errorMessages));
				reset($errorMessages);

				$session = Shopware()->Session();
				$session['PayItEasyCwCheckoutError'] = $messageToDisplay;

				return PayItEasyCw_Helpers_Util::getUrl(
						array(
							'controller' => 'checkout',
							'action' => 'confirm',
							'forceSecure' => true
						));
			}
			sleep(2);
		}

		$session = Shopware()->Session();
		$session['PayItEasyCwCheckoutError'] = Customweb_I18n_Translation::__(
				'There has been a problem during the processing of your payment. Please contact the shop owner to make sure your order was placed successfully.');

		return PayItEasyCw_Helpers_Util::getUrl(array(
			'controller' => 'checkout',
			'action' => 'confirm',
			'forceSecure' => true
		));
	}

	public static function getCountryByAddress(Customweb_Payment_Authorization_OrderContext_IAddress $address)
	{
		if ($address->getCountryIsoCode() == null) {
			return null;
		} else {
			return Shopware()->Models()->getRepository('Shopware\Models\Country\Country')->findOneByIso($address->getCountryIsoCode());
		}
	}

	public static function getStateByAddress(Customweb_Payment_Authorization_OrderContext_IAddress $address)
	{
		if ($address->getState() == null) {
			return null;
		} else {
			return Shopware()->Models()->getRepository('Shopware\Models\Country\State')->findOneByShortCode($address->getState());
		}
	}

	public static function getConfigValue($key) {
		return Shopware()->Config()->getByNamespace('payiteasycw', $key);
	}

	public static function isCreateOrderBefore()
	{
		return self::getConfigValue('order_creation') == "before";
	}

	public static function isEsdBasket(array $basket)
	{
		$details = $basket['content'];
		foreach ($details as $detail) {
			if ($detail['esd'] == 0 && $detail['modus'] != 2) {
				return false;
			}
		}
		return true;
	}

	public static function isEsdOrder(Shopware\Models\Order\Order$order)
	{
		foreach ($order->getDetails() as $detail) {
			if ($detail->getEsdArticle() == 0 && $detail->getMode() != 2) {
				return false;
			}
		}
		return true;
	}
}