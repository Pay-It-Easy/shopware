<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 * @Bean
 */
class PayItEasyCw_Components_LayoutRenderer extends Customweb_Mvc_Layout_Renderer
{
	/**
	 * @var Customweb_Mvc_Layout_IRenderContext
	 */
	private static $context = null;
	
	/**
	 * @return Customweb_Mvc_Layout_IRenderContext
	 */
	public static function getContext()
	{
		return self::$context;
	}

	public function render(Customweb_Mvc_Layout_IRenderContext $context) {
		self::$context = $context;

		$front = Shopware()->Front();
		$request = new Enlight_Controller_Request_RequestHttp();
		$request->setRequestUri($front->Request()->getBaseUrl() . '/PayItEasyCwEndpoint/layout/');
		$request->setActionName('layout');
		$front->setRequest($request);
		$response = $front->dispatch();
		$html = $response->getBody();

		$matches = array();
		preg_match('/^[^:]+:\/\/[^\/]+/i', PayItEasyCw_Helpers_Util::getUrl(array(
			'controller' => 'index',
			'forceSecure' => true
		)), $matches);
		$baseUrl = $matches[0];

		$html = Customweb_Util_Html::replaceRelativeUrls($html, $baseUrl);
		return $html;
	}
}