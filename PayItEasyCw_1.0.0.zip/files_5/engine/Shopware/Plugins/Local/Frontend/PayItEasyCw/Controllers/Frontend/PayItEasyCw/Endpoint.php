<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Frontend_PayItEasyCwEndpoint extends Enlight_Controller_Action
{
	public static $layoutTemplate = 'Layout';
	
	public function indexAction()
	{
		$dispatcher = PayItEasyCw_Helpers_Util::getEndpointDispatcher();
		$response = $dispatcher->dispatch(PayItEasyCw_Components_Request::getInstance());
		$wrapper = new Customweb_Core_Http_Response($response);
		$wrapper->send();
		die();
	}
	
	public function layoutAction()
	{
		$context = PayItEasyCw_Components_LayoutRenderer::getContext();
	
		$this->View()->loadTemplate('frontend/checkout/payiteasycw/' . self::$layoutTemplate . '.tpl');
		$this->View()->assign('payiteasycwtitle', $context->getTitle());
		$this->View()->assign('payiteasycwcssFiles', $context->getCssFiles());
		$this->View()->assign('payiteasycwjavascriptFiles', $context->getJavaScriptFiles());
		$this->View()->assign('payiteasycwmainContent', $context->getMainContent());
	}
}