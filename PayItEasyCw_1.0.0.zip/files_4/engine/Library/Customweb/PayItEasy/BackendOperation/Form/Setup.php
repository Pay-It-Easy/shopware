<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Form/ElementGroup.php';
require_once 'Customweb/Form/Control/Html.php';
require_once 'Customweb/Form/WideElement.php';
require_once 'Customweb/Form/Element.php';
require_once 'Customweb/I18n/Translation.php';
require_once 'Customweb/Payment/BackendOperation/Form/Abstract.php';



/**
 * @BackendForm
 */
class Customweb_PayItEasy_BackendOperation_Form_Setup extends Customweb_Payment_BackendOperation_Form_Abstract {

	public function getTitle(){
		return Customweb_I18n_Translation::__("Setup");
	}

	public function getElementGroups(){
		return array(
			$this->getSetupGroup(),
			$this->getUrlGroup() 
		);
	}

	private function getUrlGroup(){
		$group = new Customweb_Form_ElementGroup();
		$group->addElement($this->getNotificationUrlElement());
		return $group;
	}

	private function getNotificationUrlElement(){
		$control = new Customweb_Form_Control_Html('notificationURL', $this->getEndpointAdapter()->getUrl('process', 'normalauth'));
		$element = new Customweb_Form_Element(Customweb_I18n_Translation::__("Notification URL"), $control);
		$element->setDescription(
				Customweb_I18n_Translation::__(
						"This URL has to be placed in the backend of Pay-It-Easy under Configuration > Form Service and their in the two fields for 'Shop notification URL'.
				This option is only necessary for the payment method GiroPay."));
		return $element;
	}

	private function getSetupGroup(){
		$group = new Customweb_Form_ElementGroup();
		$group->setTitle(Customweb_I18n_Translation::__("Short Installation Instructions:"));
		
		$control = new Customweb_Form_Control_Html('description', 
				Customweb_I18n_Translation::__(
						'This is a brief installation instruction of the main and most important installation steps. It is important that you strictly follow the check-list. Only by doing so, the secure usage in correspondence with all security regulations can be guaranteed.'));
		$element = new Customweb_Form_WideElement($control);
		$group->addElement($element);
		
		$control = new Customweb_Form_Control_Html('steps', $this->createOrderedList($this->getSteps()));
		
		$element = new Customweb_Form_WideElement($control);
		$group->addElement($element);
		return $group;
	}

	private function getSteps(){
		return array(
			Customweb_I18n_Translation::__(
					"Enter the Service Username, Service Password, Payment API Username and Payment API Password that you receive from the PSP."),
			Customweb_I18n_Translation::__(
					"In order for the notification response to be processed by your shop the form service has to be set in the Backend of the PSP under configuration > Form Service . You find the notification URL below."),
			Customweb_I18n_Translation::__("Activate the payment method that you want to accept payments with.") 
		);
	}

	private function createOrderedList(array $steps){
		$list = '<ol>';
		foreach ($steps as $step) {
			$list .= "<li>$step</li>";
		}
		$list .= '</ol>';
		return $list;
	}
}