<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Core/String.php';
require_once 'Customweb/Payment/BackendOperation/Adapter/Service/ICancel.php';
require_once 'Customweb/PayItEasy/AbstractAdapter.php';
require_once 'Customweb/I18n/Translation.php';
require_once 'Customweb/PayItEasy/Helper.php';
require_once 'Customweb/Core/Charset/ISO88591.php';



/**
 *
 * @author Thomas Brenner
 * @Bean
 *
 */
class Customweb_PayItEasy_BackendOperation_Adapter_Cancellation extends Customweb_PayItEasy_AbstractAdapter implements 
		Customweb_Payment_BackendOperation_Adapter_Service_ICancel {

	public function cancel(Customweb_Payment_Authorization_ITransaction $transaction){
		$transaction->cancelDry();
		$this->doCancellation($transaction);
		$transaction->cancel();
	}

	protected function doCancellation(Customweb_Payment_Authorization_ITransaction $transaction){
		$response = Customweb_PayItEasy_Helper::sendRequest($this->buildCancellationParameters($transaction), $this->getConfiguration());
		if (!isset($response['rc']) || $response['rc'] != '000') {
			$message = Customweb_I18n_Translation::__('The cancel failed with errorcode: !error', array('!error' => $response['rc']));
			if(isset($response['rmsg']) && $response['rmsg'] != ''){
				$message = Customweb_Core_String::_($response['rmsg'], new Customweb_Core_Charset_ISO88591())->toString();
			}
			throw new Exception($message);
		}
	}

	private function buildCancellationParameters(Customweb_PayItEasy_Authorization_Transaction $transaction){
		$methodParameters = $this->getContainer()->getPaymentMethodByTransaction($transaction)->getPaymentSpecificParameters($transaction, 'normal');
		$originParameters = $transaction->getAuthorizationParameters();
		$parameters = array(
			'command' => 'reversal',
			'payment_options' => $methodParameters['paymentmethod'],
			'orderid' => $originParameters['orderid'],
			'trefnum' => $transaction->getTrefnum() 
		);
		return $parameters;
	}
}