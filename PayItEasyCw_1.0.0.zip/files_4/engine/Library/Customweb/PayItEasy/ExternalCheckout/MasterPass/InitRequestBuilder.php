<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/PayItEasy/ExternalCheckout/MasterPass/AbstractRequestBuilder.php';
require_once 'Customweb/Util/Currency.php';
require_once 'Customweb/Util/Rand.php';



class Customweb_PayItEasy_ExternalCheckout_MasterPass_InitRequestBuilder extends Customweb_PayItEasy_ExternalCheckout_MasterPass_AbstractRequestBuilder {
	
	public function build() {
		
		$additionalData = array( 'internalReference' => Customweb_Util_Rand::getRandomString(10, ''));
		
		$parameters = array();
		
		$parameters['command'] = 'open';
		$parameters['payment_options'] = 'masterpass';
		$parameters['orderid'] = $additionalData['internalReference'];
		
		$this->getContainer()->getCheckoutService()->updateProviderData($this->getContext(), array_merge($this->getContext()->getProviderData(), $additionalData));
		
		
		$parameters['amount'] = Customweb_Util_Currency::formatAmount($this->getContext()->getOrderAmountInDecimals(),
				$this->getContext()->getCurrencyCode(), '', '');
		$parameters['currency'] = $this->getContext()->getCurrencyCode();
						

		$parameters['walletreturnurl'] = $this->getContainer()->getEndpointUrl('masterpass', 'return', array('context-id' => $this->getContext()->getContextId(), 'token' => $this->getToken()));
		
		return $parameters;
	}
	

	
	
}
	