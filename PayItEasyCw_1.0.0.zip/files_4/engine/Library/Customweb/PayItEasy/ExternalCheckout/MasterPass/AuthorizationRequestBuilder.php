<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/PayItEasy/ExternalCheckout/MasterPass/AbstractRequestBuilder.php';
require_once 'Customweb/Util/Currency.php';
require_once 'Customweb/PayItEasy/Helper.php';



class Customweb_PayItEasy_ExternalCheckout_MasterPass_AuthorizationRequestBuilder extends Customweb_PayItEasy_ExternalCheckout_MasterPass_AbstractRequestBuilder {
	
	private $transaction;
	
	public function __construct(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_PayItEasy_Container $container, Customweb_PayItEasy_Authorization_Transaction $transaction) {
		parent::__construct($context, $container, '');
		$this->transaction = $transaction;
	}
	
	/**
	 * 
	 * @return Customweb_PayItEasy_Authorization_Transaction
	 */
	protected function getTransaction() {
		return $this->transaction;
	}
	
	public function build() {
		$parameters = array();
		
		$paymentMethod = $this->getContainer()->getPaymentMethodByTransaction($this->getTransaction());
		
		$parameters['command'] = $this->getTransaction()->getPaymentAction();
		$parameters['payment_options'] = 'creditcard';
		
		$responseData = $this->getContext()->getProviderData();
	
		$parameters['amount'] = Customweb_Util_Currency::formatAmount(
				$this->getTransaction()->getTransactionContext()->getOrderContext()->getOrderAmountInDecimals(),
				$this->getTransaction()->getCurrencyCode(), '', '');
		
		$parameters['currency'] = $this->getTransaction()->getTransactionContext()->getOrderContext()->getCurrencyCode();
		$parameters['orderid'] = $responseData['internalReference']; 
		$parameters['basketnr'] = Customweb_PayItEasy_Helper::getTransactionAppliedSchema($this->getTransaction(), $this->getContainer()->getConfiguration());
		$parameters['walletref'] = $responseData['walletref'];
		
		return $parameters;
	}
}