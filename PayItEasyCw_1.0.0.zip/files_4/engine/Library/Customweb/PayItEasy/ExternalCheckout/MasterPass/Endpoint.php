<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Mvc/Template/RenderContext.php';
require_once 'Customweb/Payment/ExternalCheckout/AbstractCheckoutEndpoint.php';
require_once 'Customweb/Core/Http/Response.php';
require_once 'Customweb/PayItEasy/Container.php';
require_once 'Customweb/PayItEasy/ExternalCheckout/MasterPass/InitRequestBuilder.php';
require_once 'Customweb/Payment/Authorization/OrderContext/Address/Default.php';
require_once 'Customweb/I18n/Translation.php';
require_once 'Customweb/Core/Charset/ISO88591.php';
require_once 'Customweb/PayItEasy/ExternalCheckout/MasterPass/AuthorizationRequestBuilder.php';
require_once 'Customweb/PayItEasy/ExternalCheckout/MasterPass/GetAddressRequestBuilder.php';
require_once 'Customweb/Core/String.php';
require_once 'Customweb/Mvc/Layout/RenderContext.php';
require_once 'Customweb/Mvc/Template/SecurityPolicy.php';
require_once 'Customweb/PayItEasy/Helper.php';



/**
 * @Controller("masterpass")
 */
class Customweb_PayItEasy_ExternalCheckout_MasterPass_Endpoint extends Customweb_Payment_ExternalCheckout_AbstractCheckoutEndpoint {
	
	/**
	 *
	 * @var Customweb_PayItEasy_Container
	 */
	private $container;

	public function __construct(Customweb_DependencyInjection_IContainer $container){
		parent::__construct($container);
		$this->container = new Customweb_PayItEasy_Container($container);
	}

	/**
	 * @Action("getjssnippet")
	 */
	public function getJsSnippet(Customweb_Core_Http_IRequest $request){
		$context = $this->loadContextFromRequest($request);
		$this->checkContextTokenInRequest($request, $context);
		try {
			// We set already here the payment method to be able to access the
			// setting data in the redirection parameter builder.
			$checkoutService = $this->container->getCheckoutService();
			foreach ($checkoutService->getPossiblePaymentMethods($context) as $method) {
				if (strtolower($method->getPaymentMethodName()) == 'creditcard') {
					$checkoutService->updatePaymentMethod($context, $method);
					break;
				}
			}
			$builder = new Customweb_PayItEasy_ExternalCheckout_MasterPass_InitRequestBuilder($context, $this->container, $this->getSecurityTokenFromRequest($request));
			$responseParameters = Customweb_PayItEasy_Helper::sendRequest($builder->build(), $this->container->getConfiguration());
			
			if(!isset($responseParameters['posherr']) || $responseParameters['posherr'] != '0' ) {
				$errorMessage = Customweb_I18n_Translation::__('Unkown Error occured.');
				if(isset($responseParameters['rmsg'])) {
					$errorMessage = Customweb_Core_String::_($responseParameters['rmsg'], new Customweb_Core_Charset_ISO88591())->toString();
					
				}
				throw new Exception($errorMessage);
			}
			$checkoutService->updateProviderData($context, array_merge($context->getProviderData(), $responseParameters));
			
			return json_encode(
					array(
						'status' => 'success',
						 'js' => $responseParameters['walletjs']
					)
			);
					
		}
		catch(Exception $e) {
			$this->getCheckoutService()->markContextAsFailed($context, $e->getMessage());
			return json_encode(
					array(
						'status' => 'error',
						'message' => $e->getMessage(),
						'cartUrl' => $context->getCartUrl(),
					)
			);
		}
	}
	
	/**
	 * @Action("return")
	 */
	public function updateContextAction(Customweb_Core_Http_IRequest $request){
		
		$parameters = $request->getParameters();
		$checkoutService = $this->container->getCheckoutService();
		$this->getTransactionHandler()->beginTransaction();
		$context = $this->loadContextFromRequest($request);
		$this->checkContextTokenInRequest($request, $context);
		
		try {
			
			$checkoutService->updateProviderData($context, array_merge($context->getProviderData(), $parameters));
			
			if(!isset($parameters['mpstatus'])) {
				throw new Exception(Customweb_I18n_Translation::__('Status field not set.'));

			}
			if($parameters['mpstatus'] == 'cancel' ) {
				throw new Exception(Customweb_I18n_Translation::__('Cancelled by the customer.'));
			}
			
			if($parameters['mpstatus'] == 'success') {
				$builder = new Customweb_PayItEasy_ExternalCheckout_MasterPass_GetAddressRequestBuilder($context, $this->container, $this->getSecurityTokenFromRequest($request));
				$responseParameters = Customweb_PayItEasy_Helper::sendRequest($builder->build(), $this->container->getConfiguration());
				if(!isset($responseParameters['posherr']) || $responseParameters['posherr'] != '0' ) {
					$errorMessage = Customweb_I18n_Translation::__('Unkown Error occured.');
					if(isset($responseParameters['rmsg'])) {
						$errorMessage = Customweb_Core_String::_($responseParameters['rmsg'], new Customweb_Core_Charset_ISO88591())->toString();
						
					}
					throw new Exception($errorMessage);
				}
				$address = $this->extractAddress($responseParameters);
				$email = $this->extractEmailAddress($responseParameters);
				$checkoutService->updateBillingAddress($context, $address);
				$checkoutService->updateShippingAddress($context, $address);
				$this->getTransactionHandler()->commitTransaction();
				return $checkoutService->authenticate($context, $email, $this->getConfirmationPageUrl($context, $this->getSecurityTokenFromRequest($request)));
			}
		}
		
		catch(Exception $e) {
			$this->getCheckoutService()->markContextAsFailed($context, $e->getMessage());
			$this->getTransactionHandler()->commitTransaction();
			return Customweb_Core_Http_Response::redirect($context->getCartUrl());
		}
	}
	
	/**
	 * @Action("confirmation")
	 */
	public function confirmationAction(Customweb_Core_Http_IRequest $request){
	
		$context = $this->loadContextFromRequest($request);
		$this->checkContextTokenInRequest($request, $context);
		try {
			
			$checkoutService = $this->container->getCheckoutService();
			$parameters = $request->getParameters();
				
			$templateContext = new Customweb_Mvc_Template_RenderContext();
			$confirmationErrorMessage = null;
			$shippingMethodErrorMessage = null;
			$additionalFormErrorMessage = null;
			if (isset($parameters['masterpass_update_shipping'])) {
				try {
					$checkoutService->updateShippingMethod($context, $request);
				}
				catch (Exception $e) {
					$shippingMethodErrorMessage = $e->getMessage();
				}
			}
			else if (isset($parameters['masterpass_confirmation'])) {
				try {
					$checkoutService->processAdditionalFormElements($context, $request);
				} catch (Exception $e) {
					$additionalFormErrorMessage = $e->getMessage();
				}
				if ($additionalFormErrorMessage === null) {
					try {
						$checkoutService->validateReviewForm($context, $request);
	
						$transaction = $checkoutService->createOrder($context);
						if (!$transaction->isAuthorized() && !$transaction->isAuthorizationFailed()) {
							$this->authorizeTransaction($context, $transaction);
						}
						if ($transaction->isAuthorizationFailed()) {
							$confirmationErrorMessage = current($transaction->getErrorMessages());
						}
						else {
							return Customweb_Core_Http_Response::redirect($transaction->getSuccessUrl());
						}
					}
					catch (Exception $e) {
						$confirmationErrorMessage = $e->getMessage();
					}
				}
			}
				
			$templateContext->setSecurityPolicy(new Customweb_Mvc_Template_SecurityPolicy());
			$templateContext->setTemplate('checkout/masterpass/confirmation');
				
			$templateContext->addVariable('additionalFormElements', $checkoutService->renderAdditionalFormElements($context, $additionalFormErrorMessage));
			$templateContext->addVariable('shippingPane', $checkoutService->renderShippingMethodSelectionPane($context, $shippingMethodErrorMessage));
			$templateContext->addVariable('reviewPane', $checkoutService->renderReviewPane($context, true, $confirmationErrorMessage));
			$templateContext->addVariable('confirmationPageUrl', $this->getConfirmationPageUrl($context, $this->getSecurityTokenFromRequest($request)));
			$templateContext->addVariable('javascript', $this->getAjaxJavascript('.payiteasy-masterpass-shipping-pane', '.payiteasy-masterpass-confirmation-pane'));
				
			$content = $this->getTemplateRenderer()->render($templateContext);
				
			$layoutContext = new Customweb_Mvc_Layout_RenderContext();
			$layoutContext->setTitle(Customweb_I18n_Translation::__('MasterPass: Order Confirmation'));
			$layoutContext->setMainContent($content);
			return $this->getLayoutRenderer()->render($layoutContext);
				
		}
		catch(Exception $e) {
			$this->getCheckoutService()->markContextAsFailed($context, $e->getMessage());
			$this->getTransactionHandler()->commitTransaction();

			return Customweb_Core_Http_Response::redirect($context->getCartUrl());
		}
	}
	
	private function authorizeTransaction(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_PayItEasy_Authorization_Transaction $transaction){
		$this->getTransactionHandler()->beginTransaction();
		try {
			$builder = new Customweb_PayItEasy_ExternalCheckout_MasterPass_AuthorizationRequestBuilder($context, $this->container, $transaction);
			$responseParameters = Customweb_PayItEasy_Helper::sendRequest($builder->build(), $this->container->getConfiguration());
			$transaction->setAuthorizationParameters($responseParameters);
			if(!isset($responseParameters['posherr']) || $responseParameters['posherr'] != '0' ) {
				$errorMessage = Customweb_I18n_Translation::__('Unkown Error occured.');
				if(isset($responseParameters['rmsg'])) {
					$errorMessage = Customweb_Core_String::_($responseParameters['rmsg'], new Customweb_Core_Charset_ISO88591())->toString();
					
				}
				throw new Exception($errorMessage);
			}
			if (!isset($responseParameters['rc']) || $responseParameters['rc'] != '000') {
				$message = Customweb_I18n_Translation::__('The transaction failed with an unkwon error');
				if (isset($responseParameters['rc'])) {
					$message = Customweb_I18n_Translation::__('The transaction failed with error code: !code', array(
						'!code' => $responseParameters['rc']
					));
				}
				throw new Exception($message);
			}
			$transaction->authorize();
			$transaction->setTrefnum($responseParameters['trefnum']);
			$transaction->setPaymentId($transaction->getExternalTransactionId());
			if ($transaction->getPaymentAction() == 'authorization') {
				$transaction->capture();
			}
		}
		catch (Exception $e) {
			$transaction->setAuthorizationFailed($e->getMessage());
		}
		$this->getTransactionHandler()->persistTransactionObject($transaction);
		$this->getTransactionHandler()->commitTransaction();
	}

	private function getConfirmationPageUrl(Customweb_Payment_ExternalCheckout_IContext $context, $token){
		return $this->getUrl('masterpass', 'confirmation', 
				array(
					'context-id' => $context->getContextId(),
					'token' => $token,
				)
		);
	}

	/**
	 * @return Customweb_PayItEasy_Method_Factory
	 */
	protected function getMethodFactory() {
		return $this->getContainer()->getBean('Customweb_PayItEasy_Method_Factory');
	}
	
	protected function getPaymentMethodByTransaction(Customweb_PayItEasy_Authorization_Transaction $transaction){
		return $this->getMethodFactory()->getPaymentMethod($transaction->getTransactionContext()->getOrderContext()->getPaymentMethod(), $transaction->getAuthorizationMethod());
	}
		
	private function extractAddress(array $parameters) {
		$requiredParameters = array(
			'customer_lastname',
			'customer_addr_street',
			'customer_addr_zip',
			'customer_addr_city',
			'customer_addr_country',
			'customer_email',				
		);
		
		foreach ($requiredParameters as $parameterName) {
			if (!isset($parameters[$parameterName])) {
				throw new Exception("Parameter $parameterName is missing.");
			}
		}
		
		$address = new Customweb_Payment_Authorization_OrderContext_Address_Default();
		
		if(strpos($parameters['customer_lastname'],' ') === false) {
			$address->setFirstName($parameters['customer_lastname']);
			$address->setLastName($parameters['customer_lastname']);
			
		}
		else {
			list($firstName, $lastName) = explode(' ', $parameters['customer_lastname'], 2);
			$address->setFirstName($firstName)
				->setLastName($lastName);
		}
		$address
			->setStreet($parameters['customer_addr_street'])
			->setPostCode($parameters['customer_addr_zip'])
			->setCity($parameters['customer_addr_city'])
			->setCountryIsoCode($parameters['customer_addr_country'])
			->setEMailAddress($parameters['customer_email']);
	
		if(isset($parameters['customer_phone'])) {
			$address->setPhoneNumber($parameters['customer_phone']);
		}
		
		return $address;
	}
	
	private function extractEmailAddress(array $parameters) {
		if(!isset($parameters['customer_email'])) {
			throw new Exception("Parameter customer_email is missing.");
		}
		return $parameters['customer_email'];
	}
	
}