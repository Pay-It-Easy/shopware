<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/I18n/LocalizableException.php';
require_once 'Customweb/I18n/Translation.php';


/**
 * 
 * @author Thomas Brenner
 * @Bean
 */
class Customweb_PayItEasy_Configuration{
	
	/**
	 *         					    		  
	 * @var Customweb_Payment_IConfigurationAdapter
	 */
	private $configurationAdapter = null;
	private $version = "1.6";
	
	private $handler;
	
	
	public function __construct(Customweb_Payment_IConfigurationAdapter $configurationAdapter) {
		$this->configurationAdapter = $configurationAdapter;
	}
	
	/**
	 * Returns whether the gateway is in test mode or in live mode.
	 *         					    		  
	 * @return boolean True if the system is in test mode. Else return false.
	 */
	public function isTestMode()
	{
		return $this->getConfigurationAdapter()->getConfigurationValue('operation_mode') != 'live';
	}
	
	public function getPaymentPageUrl() {
		if($this->isTestMode()) {
			return "https://apistg.pay-it-easy.de/web-api/SSLPayment.po";
		}
		else{
			return "https://api.pay-it-easy.de/web-api/SSLPayment.po";
		}
	}
	
	public function getServerUrl() {
		if($this->isTestMode()) {
			return "https://apistg.pay-it-easy.de/web-api/Request.po";
		}
		else{
			return "https://api.pay-it-easy.de/web-api/Request.po";
		}
	}
	
	
	
	public function getSSLPassword() {
		$password = null;
		if($this->isTestMode()) {
			$password = $this->getConfigurationAdapter()->getConfigurationValue('ssl_password_test');
		} else {
			$password = $this->getConfigurationAdapter()->getConfigurationValue('ssl_password_live');
		}
		if(empty($password)){
			throw new Customweb_I18n_LocalizableException(Customweb_I18n_Translation::__("The given SSL password is empty. Please check the SSL password settings for Pay-It-Easy."));
		}
		return $password;
	}
	
	public function getSSLMerchant() {
		$merchant = null;
		if($this->isTestMode()) {
			$merchant = $this->getConfigurationAdapter()->getConfigurationValue('ssl_merchant_test');
		} else {
			$merchant = $this->getConfigurationAdapter()->getConfigurationValue('ssl_merchant_live');
		}
		if(empty($merchant)){
			throw new Customweb_I18n_LocalizableException(Customweb_I18n_Translation::__("The given SSL merchant is empty. Please check the SSL merchant settings for Pay-It-Easy."));
		}
		return $merchant;
	}
	
	public function getOrderIdSchema(){
		return $this->getConfigurationAdapter()->getConfigurationValue('order_id_schema');
	}
	
	public function getUsername() {
		$username = null;
		if($this->isTestMode()) {
			$username = $this->getConfigurationAdapter()->getConfigurationValue('username_test');
		} else {
			$username = $this->getConfigurationAdapter()->getConfigurationValue('username_live');
		}
		if(empty($username)){
			throw new Customweb_I18n_LocalizableException(Customweb_I18n_Translation::__("The given user id is empty. Please check the user id settings for Pay-It-Easy."));
		}
		return $username;
	}
	
	public function getPassword() {
		$password = null;
		if($this->isTestMode()) {
			$password = $this->getConfigurationAdapter()->getConfigurationValue('shop_password_test');
		} else {
			$password = $this->getConfigurationAdapter()->getConfigurationValue('shop_password_live');
		}
		if(empty($password)){
			throw new Customweb_I18n_LocalizableException(Customweb_I18n_Translation::__("The given shop password is empty. Please check the shop password settings for Pay-It-Easy."));
		}
		return $password;
	}
	
	/**
	 *
	 * @return Customweb_Payment_IConfigurationAdapter
	 */
	public function getConfigurationAdapter() {
		return $this->configurationAdapter;
	}

	public function getVersion(){
		return $this->version;
	}
	
	public function getShopId() {
		return $this->configurationAdapter->getConfigurationValue('shop_id');
	}
	
	
	
}
