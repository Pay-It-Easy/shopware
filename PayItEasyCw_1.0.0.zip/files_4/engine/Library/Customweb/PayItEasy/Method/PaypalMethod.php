<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Util/String.php';
require_once 'Customweb/PayItEasy/Method/DefaultMethod.php';
require_once 'Customweb/Util/Currency.php';
require_once 'Customweb/Payment/Authorization/IInvoiceItem.php';
require_once 'Customweb/I18n/Translation.php';

/**
 *
 * @author Thomas Brenner
 * @Method(paymentMethods={'Paypal'})
 */
class Customweb_PayItEasy_Method_PaypalMethod extends Customweb_PayItEasy_Method_DefaultMethod {

	public function getPaymentSpecificParameters(Customweb_PayItEasy_Authorization_Transaction $transaction, $type){
		$specificParameters = array(
			'command' => 'sslform',
			'payment_options' => $transaction->getPaymentAction(),
			'paymentmethod' => 'paypal',
			'basketid' => $transaction->getExternalTransactionId(),
			'sessionid' => $this->getGlobalConfiguration()->getShopId(),
		);
		
		return array_merge(parent::getPaymentSpecificParameters($transaction, $type), $specificParameters, $this->getLineItems($transaction));
	}

	private function getLineItems(Customweb_PayItEasy_Authorization_Transaction $transaction){
		$orderContext = $transaction->getTransactionContext()->getOrderContext();
		$loopcounter = 1;
		$parameters = array();
		$totalAmount = 0;
		
		foreach ($orderContext->getInvoiceItems() as $item) {
			if ($item->getQuantity() == 0) {
				continue;
			}
			$amount = $item->getAmountIncludingTax() / $item->getQuantity();
			if ($item->getType() == Customweb_Payment_Authorization_IInvoiceItem::TYPE_DISCOUNT) {
				$amount = $amount * -1;
			}
			$parameters['basketitem_name' . $loopcounter] = Customweb_Util_String::substrUtf8($item->getName(), 0, 127);
			$parameters['basketitem_qty' . $loopcounter] = number_format($item->getQuantity(), 0, "", "");
			$parameters['basketitem_amount' . $loopcounter] = Customweb_Util_Currency::formatAmount($amount, $transaction->getCurrencyCode(), ',', '');
			$totalAmount = $totalAmount + Customweb_Util_Currency::formatAmount($amount, $transaction->getCurrencyCode(), '', '') *
					 $parameters['basketitem_qty' . $loopcounter];
			$loopcounter++;
		}
		
		// Add fix for rounding errors.
		$orderAmountSmallest = Customweb_Util_Currency::formatAmount($orderContext->getOrderAmountInDecimals(), 
				$transaction->getCurrencyCode(), '', '');
		if (Customweb_Util_Currency::compareAmount($orderAmountSmallest, $totalAmount, $transaction->getCurrencyCode()) !== 0) {
			$amount = $orderAmountSmallest - $totalAmount;
			$parameters['basketitem_name' . (string) $loopcounter] = Customweb_I18n_Translation::__("Rounding Adjustments");
			$parameters['basketitem_qty' . $loopcounter] = 1;
			$parameters['basketitem_amount' . $loopcounter] = Customweb_Util_Currency::formatAmount($amount, $transaction->getCurrencyCode(), ',', '');
			$loopcounter++;
		}
		return $parameters;
	}
}