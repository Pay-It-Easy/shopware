<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/PayItEasy/Method/DefaultMethod.php';
require_once 'Customweb/Payment/Authorization/Method/Sepa/Mandate.php';

/**
 *
 * @author Thomas Brenner
 * @Method(paymentMethods={'DirectDebitsSepa'})
 */
class Customweb_PayItEasy_Method_SepaMethod extends Customweb_PayItEasy_Method_DefaultMethod {

	public function getVisibleFormFieldsPaymentPage(Customweb_Payment_Authorization_IPaymentCustomerContext $customerContext){
		return array();
	}

	public function getPaymentSpecificParameters(Customweb_PayItEasy_Authorization_Transaction $transaction, $type){
		$schema = '{year}-{month}-{day}: {random}';
		$mandateId = Customweb_Payment_Authorization_Method_Sepa_Mandate::generateMandateId($schema);
		$mandateDate = new DateTime("now");
		return array_merge(parent::getPaymentSpecificParameters($transaction, $type), 
				array(
					'command' => 'sslform',
					'paymentmethod' => 'directdebit',
					'transactiontype' => $transaction->getPaymentAction(),
					'version' => $this->getGlobalConfiguration()->getVersion(),
					'mandateid' => $mandateId,
					'mandatesigned' => $mandateDate->format("Ymd") 
				));
	}
}