<?php 



/**
 *
 * @author Thomas Brenner
 * 
 *
 */
class Customweb_PayItEasy_AbstractParameterBuilder {
	
		private $transaction;
		private $container;
	
		public function __construct(Customweb_PayItEasy_Authorization_Transaction $transaction, Customweb_PayItEasy_Container $container) {
			$this->container = $container;
			$this->transaction = $transaction;
		}

		/**
		 * @return Customweb_PayItEasy_Configuration
		 */
		protected function getConfiguration(){
			return $this->getContainer()->getConfiguration();
		}
		
		protected function getContainer() {
			return $this->container;
		}
		
		protected function getTransaction() {
			return $this->transaction;
		}
		
		protected function getOrderContext() {
			return $this->transaction->getTransactionContext()->getOrderContext();
		}
		

}