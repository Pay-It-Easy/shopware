<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Core/Http/Request.php';
require_once 'Customweb/Core/Http/Client/Factory.php';
require_once 'Customweb/Core/Http/Response.php';
require_once 'Customweb/Payment/Util.php';
require_once 'Customweb/Core/Url.php';
require_once 'Customweb/Core/Http/Authorization/Basic.php';

class Customweb_PayItEasy_Helper {
	
	private function __construct(){
		// prevent any instantiation of this class
	}

	/**
	 *
	 * Performs an HTTP Query
	 *
	 * @param array $body
	 * @param Customweb_PayItEasy_Configuration $configuration
	 * @return Body
	 */
	public static function sendRequest(array $body, Customweb_PayItEasy_Configuration $configuration) {
		$url = new Customweb_Core_Url($configuration->getServerUrl());
		$url->setUser($configuration->getSSLMerchant())->setPass($configuration->getSSLPassword());
		$request = new Customweb_Core_Http_Request($url);
		$request->setBody($body);
		$request->setAuthorization(new Customweb_Core_Http_Authorization_Basic($configuration->getUsername(), $configuration->getPassword()));
		$request->setMethod("POST");
		$request->appendHeader('Content-Type:application/x-www-form-urlencoded');
		$client = Customweb_Core_Http_Client_Factory::createClient();
	
		$response = new Customweb_Core_Http_Response($client->send($request));
		return $response->getParsedBody();
	}
	
	
	public static final function getTransactionAppliedSchema(Customweb_Payment_Authorization_ITransaction $transaction, Customweb_PayItEasy_Configuration $configuration)
	{
		$schema = $configuration->getOrderIdSchema();
		$id = $transaction->getExternalTransactionId();
	
		return Customweb_Payment_Util::applyOrderSchema($schema, $id, 17);
	}
}