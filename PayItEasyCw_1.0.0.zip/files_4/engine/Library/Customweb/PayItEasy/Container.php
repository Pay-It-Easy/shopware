<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Payment/Util.php';
require_once 'Customweb/I18n/Translation.php';
require_once 'Customweb/Payment/AbstractContainer.php';

class Customweb_PayItEasy_Container extends Customweb_Payment_AbstractContainer {

	public function getProcessNormalAuthorizationUrl($transactionId){
		return $this->getEndpointAdapter()->getUrl('process', 'normalauth', array(
			'cw_transaction_id' => $transactionId 
		));
	}

	public function getProcessInitialAliasAuthUrl($transactionId){
		return $this->getEndpointAdapter()->getUrl('process', 'initialaliasauth', array(
			'cw_transaction_id' => $transactionId 
		));
	}

	public function getProcessAliasAuthUrl($transactionId){
		return $this->getEndpointAdapter()->getUrl('process', 'aliasauth', array(
			'cw_transaction_id' => $transactionId 
		));
	}
	
	public function getEndpointUrl($controller, $action, array $parameters) {
		return $this->getEndpointAdapter()->getUrl($controller, $action, $parameters);
	}

	/**
	 *
	 * @return Customweb_PayItEasy_Configuration
	 */
	public function getConfiguration(){
		return $this->getBean('Customweb_PayItEasy_Configuration');
	}

	/**
	 *
	 * @return Customweb_PayItEasy_Method_Factory
	 */
	public function getPaymentMethodFactory(){
		return $this->getBean('Customweb_PayItEasy_Method_Factory');
	}

	/**
	 *
	 * @param Customweb_PayItEasy_Authorization_Transaction $transaction
	 */
	public function getPaymentMethodByTransaction(Customweb_PayItEasy_Authorization_Transaction $transaction){
		return $this->getPaymentMethodFactory()->getPaymentMethod($transaction->getPaymentMethod(), $transaction->getAuthorizationMethod());
	}

	public function checkUrlLength($url, $length){
		if (strlen($url) > $length) {
			throw new Exception(Customweb_I18n_Translation::__('Error with url string length.'));
		}
		else {
			return $url;
		}
	}

	public function getCleanedUpLanguage($language){
		$allowed = array(
			'de_DE',
			'en_US',
			'fr_FR',
			'da_DK',
			'cs_CZ',
			'es_ES',
			'it_IT',
			'nl_NL',
			'pt_PT',
			'sv_SE',
			'pl_PL',			
		);
		return substr(Customweb_Payment_Util::getCleanLanguageCode($language, $allowed) ,0,2);
	}
	
	/**
	 * @return Customweb_Payment_ExternalCheckout_ICheckoutService
	 */
	public function getCheckoutService() {
		return $this->getBean('Customweb_Payment_ExternalCheckout_ICheckoutService');
	}
}