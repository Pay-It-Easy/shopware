<?php

require_once 'Customweb/Util/Url.php';
require_once 'Customweb/Util/Currency.php';
require_once 'Customweb/PayItEasy/AbstractParameterBuilder.php';
require_once 'Customweb/PayItEasy/Helper.php';
require_once 'Customweb/Util/Rand.php';



/**
 *
 * @author Thomas Brenner
 *
 */
class Customweb_PayItEasy_Authorization_ParameterBuilder extends Customweb_PayItEasy_AbstractParameterBuilder {

	public function buildRedirectionUrl(){
		$paymentMethod = $this->getContainer()->getPaymentMethodByTransaction($this->getTransaction());
		$parameters = array_merge($this->buildBaseParameters(), $this->buildTransactionParameters(), 
				$paymentMethod->getPaymentSpecificParameters($this->getTransaction(), 'normal'), $this->buildNotifcationFailedParameters());
		$parameters['mac'] = $this->hashValues($parameters);
		
		return Customweb_Util_Url::appendParameters($this->getConfiguration()->getPaymentPageUrl(), $parameters);
	}

	public function buildInitialAliasRedirectionUrl(){
		$paymentMethod = $this->getContainer()->getPaymentMethodByTransaction($this->getTransaction());
		$parameters = array_merge($this->buildBaseParameters(), $this->buildTransactionParameters(), 
				$paymentMethod->getPaymentSpecificParameters($this->getTransaction(), 'initial'), $this->buildNotifcationFailedParameters());
		$parameters['payment_options'] = 'generate_ppan';
		$uniqueId = '';
		if (!empty($customerId)) {
			$uniqueId = 'cw_' . $customerId . '_' . Customweb_Util_Rand::getRandomString(10, '');
		}
		else {
			$uniqueId = 'cw_' . Customweb_Util_Rand::getRandomString(10, '');
		}
		$parameters['ppan'] = $uniqueId;
		$parameters['mac'] = $this->hashValues($parameters);
		
		return Customweb_Util_Url::appendParameters($this->getConfiguration()->getPaymentPageUrl(), $parameters);
	}

	public function buildAliasRedirectionUrl(Customweb_PayItEasy_Authorization_Transaction $oldTransaction){
		$paymentMethod = $this->getContainer()->getPaymentMethodByTransaction($this->getTransaction());
		$parameters = array_merge($this->buildBaseParameters(), $this->buildTransactionParameters(), 
				$paymentMethod->getPaymentSpecificParameters($this->getTransaction(), 'alias'), $this->buildNotifcationFailedParameters());
		$parameters['ppan'] = $oldTransaction->getPpanNumber();
		
		$parameters['mac'] = $this->hashValues($parameters);
		return Customweb_Util_Url::appendParameters($this->getConfiguration()->getPaymentPageUrl(), $parameters);
	}
	
	// --------------------------------------------------------------------- HELPING FUNCTIONS ---------------------------------------------------------------------
	protected function buildBaseParameters(){
		return array(
			'sslmerchant' => $this->getConfiguration()->getSSLMerchant(),
			'locale' => $this->getContainer()->getCleanedUpLanguage($this->getTransaction()->getTransactionContext()->getOrderContext()->getLanguage()),
		);
	}

	
	protected function buildTransactionParameters(){
		return array(
			'currency' => $this->getTransaction()->getTransactionContext()->getOrderContext()->getCurrencyCode(),
			'amount' => Customweb_Util_Currency::formatAmount(
					$this->getTransaction()->getTransactionContext()->getOrderContext()->getOrderAmountInDecimals(),
					$this->getTransaction()->getCurrencyCode(), ',', ''),
			'orderid' => $this->getTransaction()->getExternalTransactionId(),
			'basketnr' => Customweb_PayItEasy_Helper::getTransactionAppliedSchema($this->getTransaction(), $this->getConfiguration())
		);
	}

	protected function hashValues(array $parameters){
		ksort($parameters);
		return hash_hmac('sha1', implode('', $parameters), $this->getConfiguration()->getSSLPassword());
	}

	protected function buildNotifcationFailedParameters(){
		/* @var $transaction Customweb_PayItEasy_Authorization_Transaction */
		if ($this->getTransaction()->getAuthorizationMethod() != 'IframeAuthorization') {
			return array(
				'notificationfailedurl' => $this->getContainer()->checkUrlLength($this->getTransaction()->getSuccessUrl(), 255) 
			);
		}
		else {
			$url = $this->getContainer()->checkUrlLength(
					Customweb_Util_Url::appendParameters($this->getTransaction()->getTransactionContext()->getIframeBreakOutUrl(), 
							$this->getTransaction()->getTransactionContext()->getCustomParameters()), 255);
			return array(
				'notificationfailedurl' => $url 
			);
		}
	}
}