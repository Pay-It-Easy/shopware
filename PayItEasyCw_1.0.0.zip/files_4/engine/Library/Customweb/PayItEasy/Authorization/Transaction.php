<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Payment/Authorization/DefaultTransaction.php';
require_once 'Customweb/I18n/Translation.php';
require_once 'Customweb/Payment/Authorization/ITransactionContext.php';


class Customweb_PayItEasy_Authorization_Transaction extends Customweb_Payment_Authorization_DefaultTransaction
{
	private $ppanNumber;	
	private $expiryYear = "";
	private $expiryMonth = "";
	private $sellerprotection;
	private $trefnum;

	public function getPaymentAction() {
		$capturingMode = $this->getTransactionContext()->getCapturingMode();
		if ($capturingMode === null) {
			$capturingMode = $this->getTransactionContext()->getOrderContext()->getPaymentMethod()->getPaymentMethodConfigurationValue('capturing');
		}
		if($capturingMode == Customweb_Payment_Authorization_ITransactionContext::CAPTURING_MODE_DEFERRED) {
			return 'preauthorization';
		}
		return 'authorization';
	}

	
	public function setAuthorizationType($authorizationType) {
		$this->authorizationType = $authorizationType;		
	}
	
	public function getAuthorizationType() {
		return $this->authorizationType;
	}
	
	public function getPpanNumber(){
		return $this->ppanNumber;
	}

	public function setPpanNumber($ppanNumber){
		$this->ppanNumber = $ppanNumber;
		return $this;
	}

	public function getSellerprotection(){
		return $this->sellerprotection;
	}

	public function setSellerprotection($sellerprotection){
		$this->sellerprotection = $sellerprotection;
		return $this;
	}
	
	public function getExpiryYear(){
		return $this->expiryYear;
	}

	public function getExpiryMonth(){
		return $this->expiryMonth;
	}

	public function setExpiryDate($date){
		$this->expiryYear = substr($date, 0, 2);
		$this->expiryMonth = substr($date, 2);
	}

	public function getTrefnum(){
		return $this->trefnum;
	}

	public function setTrefnum($trefnum){
		$this->trefnum = $trefnum;
		return $this;
	}
		
	public function isCaptureClosable() {
		return false;
	}
	
	protected function getTransactionSpecificLabels() {
		$labels = array();
		$parameters = $this->getAuthorizationParameters();
		if(isset($parameters['creditc'])) {
			$labels['cardnumber'] = array(
				'label' => Customweb_I18n_Translation::__('Card Number'),
				'value' => $parameters['creditc']
			);
		}
		if(isset($parameters['expdat'])) {
			$labels['cardexpiry'] = array(
				'label' => Customweb_I18n_Translation::__('Card Expiry Date'),
				'value' => substr($parameters['expdat'],2). '/'. substr($parameters['expdat'],0,2)
			);
		}
		if(isset($parameters['basketnr'])) {
			$labels['basketNr'] = array(
				'label' => Customweb_I18n_Translation::__('Basket Number'),
				'value' => $parameters['basketnr']
			);
		}
		return $labels;
	}
	
}