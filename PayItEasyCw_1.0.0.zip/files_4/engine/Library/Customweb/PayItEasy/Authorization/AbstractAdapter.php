<?php 
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

require_once 'Customweb/Core/String.php';
require_once 'Customweb/Core/Http/Response.php';
require_once 'Customweb/PayItEasy/Authorization/ParameterBuilder.php';
require_once 'Customweb/Util/Currency.php';
require_once 'Customweb/Payment/Authorization/ErrorMessage.php';
require_once 'Customweb/PayItEasy/AbstractAdapter.php';
require_once 'Customweb/I18n/Translation.php';
require_once 'Customweb/PayItEasy/Helper.php';
require_once 'Customweb/Core/Charset/ISO88591.php';


/**
 *
 * @author Thomas Brenner
 *
 */
class Customweb_PayItEasy_Authorization_AbstractAdapter extends Customweb_PayItEasy_AbstractAdapter{
	
	public function processNormalAuthorization(Customweb_PayItEasy_Authorization_Transaction $transaction, array $parameters){
		$transaction->setAuthorizationParameters($parameters);
		if (!isset($parameters['mac']) || $parameters['mac'] != $this->hashValues()) {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(Customweb_I18n_Translation::__('Verification Error.'),
							Customweb_I18n_Translation::__('An error during the calculation of the hash value occured, fraud possible.')));
			return $this->finalizeNormalAuthorizationRequest($transaction);
		}
		$this->performAuthorization($transaction, $parameters);
		return $this->finalizeNormalAuthorizationRequest($transaction);
	}
	
	public function processInitialAliasAuthorization(Customweb_PayItEasy_Authorization_Transaction $transaction, array $parameters){
		$transaction->setAuthorizationParameters($parameters);
		if ($parameters['mac'] != $this->hashValues()) {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(Customweb_I18n_Translation::__('Verification Error.'),
							Customweb_I18n_Translation::__('An error during the calculation of the hash value occured, fraud possible.')));
			return $this->finalizeAliasAuthorizationRequest($transaction);
		}
		$parameterBuilder = new Customweb_PayItEasy_Authorization_ParameterBuilder($transaction, $this->getContainer());
		//Handling case where alias already exists
		if (isset($parameters['directPosErrorCode']) && $parameters['directPosErrorCode'] == "358") {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(
							Customweb_I18n_Translation::__(
									'Your credit card probably has already been saved. Please choose this card or registrate a new one.'),
							Customweb_I18n_Translation::__('The transaction failed with error code: !code',
									array(
										'!code' => $parameters['directPosErrorCode']
									))));
			return $this->finalizeAliasAuthorizationRequest($transaction);
		}
	
		if (isset($parameters['directPosErrorCode']) && $parameters['directPosErrorCode'] != "0") {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(Customweb_I18n_Translation::__('The transaction failed. Please try again.'),
							Customweb_I18n_Translation::__('The transaction failed with error code: !code',
									array(
										'!code' => $parameters['directPosErrorCode']
									))));
			return $this->finalizeAliasAuthorizationRequest($transaction);
		}
	
		//Request to gather the AliasForDisplay
		try {
			$result = Customweb_PayItEasy_Helper::sendRequest($parameterBuilder->buildPpanInfoUrl($parameters['ppan']), $this->getConfiguration());
				
			if ($result['posherr'] == "0") {
				$transaction->setAliasForDisplay($result['creditc']);
				$transaction->setExpiryDate($result['expdat']);
				$transaction->setPpanNumber($parameters['ppan']);
			}
			else {
				$transaction->setAliasForDisplay(null);
			}
		}
		catch(Exception $e) {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(Customweb_I18n_Translation::__('The transaction failed.'), $e->getMessage()));
		}
		$this->performAuthorization($transaction, $parameters);
		return $this->finalizeAliasAuthorizationRequest($transaction);
	}
	
	public function processAliasAuthorization(Customweb_PayItEasy_Authorization_Transaction $transaction, array $parameters){
		$transaction->setAuthorizationParameters($parameters);
		if ($parameters['mac'] != $this->hashValues()) {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(Customweb_I18n_Translation::__('Verification Error.'),
							Customweb_I18n_Translation::__('An error during the calculation of the hash value occured, fraud possible.')));
			return $this->finalizeAliasAuthorizationRequest($transaction);
		}
		if (isset($parameters['directPosErrorCode']) && $parameters['directPosErrorCode'] != "0") {
			$transaction->setAuthorizationFailed(
					new Customweb_Payment_Authorization_ErrorMessage(Customweb_I18n_Translation::__('The transaction failed. Please try again.'),
							Customweb_I18n_Translation::__('The transaction failed with error code: !code',
									array(
										'!code' => $parameters['directPosErrorCode']
									))));
			return $this->finalizeAliasAuthorizationRequest($transaction);
		}
		$this->performAuthorization($transaction, $parameters);
		return $this->finalizeAliasAuthorizationRequest($transaction);
	}
	
	public function performAuthorization(Customweb_PayItEasy_Authorization_Transaction $transaction, $parameters){
		$paymentMethod = $this->getContainer()->getPaymentMethodFactory()->getPaymentMethod($transaction->getPaymentMethod(), $transaction->getAuthorizationMethod());
		try {
			$this->validateInformation($transaction, $parameters);
			$transaction->setTrefnum($parameters['trefnum']);
			$transaction->authorize(Customweb_I18n_Translation::__('Customer sucessfully returned from the PayItEasy payment page.'));
			if ($transaction->getPaymentAction() == 'authorization' || $paymentMethod->automaticCapture()) {
				$transaction->capture();
			}
		}
		catch (Exception $e) {
			$transaction->setAuthorizationFailed($e->getMessage());
		}
	}
	
	public function finalizeNormalAuthorizationRequest(Customweb_Payment_Authorization_ITransaction $transaction){
		
		if ($transaction->isAuthorizationFailed()) {
			$url = $transaction->getFailedUrl();
		}
		else {
			$url = $transaction->getSuccessUrl();
		}
		$response = new Customweb_Core_Http_Response();
		$response->setBody('rurls='.$url);
		return $response;
	}
	
	public function finalizeAliasAuthorizationRequest(Customweb_Payment_Authorization_ITransaction $transaction){
	
		if ($transaction->isAuthorizationFailed()) {
			$response = 'Redirect: '.$transaction->getFailedUrl();
		}
		else {
			$response = 'Redirect: '.$transaction->getSuccessUrl();
		}
		return $response;
	}
	
	protected function validateInformation(Customweb_PayItEasy_Authorization_Transaction $transaction, array $parameters){
		$paymentMethod = $this->getContainer()->getPaymentMethodFactory()->getPaymentMethod($transaction->getPaymentMethod(), $transaction->getAuthorizationMethod());
		if (!isset($parameters['rc'])) {
			$message = Customweb_I18n_Translation::__('The transaction failed with an unkwon error');
			if (isset($parameters['directPosErrorMessage'])) {
				$message = Customweb_Core_String::_($parameters['directPosErrorMessage'], new Customweb_Core_Charset_ISO88591())->toString();
			}
			throw new Exception($message);
		}
		if ($parameters['rc'] != $paymentMethod->getSuccessCode()) {
			$message = Customweb_I18n_Translation::__('The transaction failed with error code: !code', array(
				'!code' => $parameters['rc']
			));
			if (isset($parameters['directPosErrorMessage'])) {
				$message = Customweb_Core_String::_($parameters['directPosErrorMessage'], new Customweb_Core_Charset_ISO88591())->toString();
			}
			throw new Exception($message);
		}
		if ($parameters['currency'] != $transaction->getTransactionContext()->getOrderContext()->getCurrencyCode() ||
				$parameters['amount'] != Customweb_Util_Currency::formatAmount($transaction->getTransactionContext()->getOrderContext()->getOrderAmountInDecimals(), $transaction->getCurrencyCode(), ',', '')) {
					throw new Exception(Customweb_I18n_Translation::__('The notification information could not be validated.'));
				}
	}
	
	protected function hashValues(){
		$request = $this->getContainer()->getHttpRequest();
		$parameters = $request->getParsedBody();
		unset($parameters['mac']);
		ksort($parameters);
		return hash_hmac('sha1', implode('', $parameters), $this->getConfiguration()->getSSLPassword());
	}
	
	protected function createUrl(Customweb_Payment_Authorization_ITransaction $transaction, array $formData){
		$parameterBuilder = new Customweb_PayItEasy_Authorization_ParameterBuilder($transaction, $this->getContainer());
		if ($transaction->getTransactionContext()->getAlias() == "new" || $transaction->getTransactionContext()->createRecurringAlias()) {
			return $parameterBuilder->buildInitialAliasRedirectionUrl();
		}
		else if ($transaction->getTransactionContext()->getAlias() != null) {
			return $parameterBuilder->buildAliasRedirectionUrl($transaction->getTransactionContext()->getAlias());
		}
		else {
			return $parameterBuilder->buildRedirectionUrl();
		}
	}

}