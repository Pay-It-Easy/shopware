<?php 



interface Customweb_Database_Entity_Meta_IFilter {
	
	public function getName();
	
	public function getWhere();
	
	public function getOrderBy();
	
}