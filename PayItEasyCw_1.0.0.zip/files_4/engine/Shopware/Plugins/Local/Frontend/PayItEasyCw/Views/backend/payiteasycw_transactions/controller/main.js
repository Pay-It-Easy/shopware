//{block name="backend/payiteasycw_transactions/controller/main"}
Ext.define('Shopware.apps.PayiteasycwTransactions.controller.Main', {
    extend: 'Ext.app.Controller',

    init: function() {
        var me = this;

        me.subApplication.transactionStore = me.subApplication.getStore('Transaction');
        me.subApplication.transactionStore.load();

        me.mainWindow = me.getView('main.Window').create({
            transactionStore: me.subApplication.transactionStore,
        });
        me.callParent(arguments);
    }
});
//{/block}