/**
 * Add custom fields to payment model.
 * 
 * @author Simon Schurter
 */
 //{block name="backend/payment/model/payment" append}
	Shopware.apps.Payment.model.Payment.prototype.fields.add(new Ext.data.Field({ name: 'configValues', type: 'string'}));
	Shopware.apps.Payment.model.Payment.prototype.fields.add(new Ext.data.Field({ name: 'configForm', type: 'string'}));
	Shopware.apps.Payment.model.Payment.prototype.fields.add(new Ext.data.Field({ name: 'configFormShops', type: 'string'}));
	Shopware.apps.Payment.model.Payment.prototype.fields.add(new Ext.data.Field({ name: 'payiteasycw', type: 'boolean'}));
//{/block}