<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class is used to render form elements to html.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_FormRenderer extends Customweb_Form_Renderer
{
	public function getFormCssClass()
	{
		return 'register grid_20 payiteasycw-form';
	}
	
	public function renderElementGroupPrefix(Customweb_Form_IElementGroup $elementGroup)
	{
		return '<div class="element-group shipping_address">';
	}
	
	public function renderElementGroupPostfix(Customweb_Form_IElementGroup $elementGroup)
	{
		return '</div>';
	}
	
	public function renderElementGroupTitle(Customweb_Form_IElementGroup $elementGroup)
	{
		$output = '';
		$title = $elementGroup->getTitle();
		if (! empty($title)) {
			$cssClass = $this->getCssClassPrefix() . $this->getElementGroupTitleCssClass();
			$output .= '<h2 class="headingbox_dark largesize ' . $cssClass . '">' . $title . '</h2>';
		}
		return $output;
	}
	
	public function renderElementPrefix(Customweb_Form_IElement $element)
	{
		$classes = $this->getCssClassPrefix() . $this->getElementCssClass();
		$classes .= ' ' . $this->getCssClassPrefix() . $element->getElementIntention()->getCssClass();
	
		$errorMessage = $element->getErrorMessage();
		if (! empty($errorMessage)) {
			$classes .= ' ' . $this->getCssClassPrefix() . $this->getElementErrorCssClass();
		}
	
		if ($element instanceof Customweb_Form_WideElement) {
			$classes .= ' wide';
		}
	
		return '<div class="' . $classes . '" id="' . $element->getElementId() . '">';
	}
	
	public function renderControl(Customweb_Form_Control_IControl $control)
	{
		if (method_exists($control, 'getInputType')) {
			$additional = '';
			if ($control->getInputType() == 'password') {
				$additional = 'text';
			}
			$control->setCssClass($control->getInputType() . ' form-control ' . $additional);
		}
		if ($control instanceof Customweb_Form_Control_MultiSelect) {
			$originalControl = $control;
			$control = new Customweb_Form_Control_MultiCheckbox($originalControl->getRawControlName(), $originalControl->getOptions(), $originalControl->getDefaultValues());
		}
		return $control->render($this);
	}
	
	protected function renderButtons(array $buttons)
	{
		$output = '<div class="space">&nbsp;</div><div class="actions">';
		foreach ($buttons as $button) {
			$output .= $this->renderButton($button);
		}
		$output .= '</div>';
		return $output;
	}
	
	public function renderButton(Customweb_Form_IButton $button)
	{
		return '<input class="button-right right large ' . $this->getButtonClasses($button) . '" type="submit" name="button[' . $button->getMachineName() . ']" value="' . $button->getTitle() . '" id="' . $button->getId() . '" />';
	}
	
	protected function renderValidatorCallbacks(array $elements)
	{
		$js = "
		if(typeof window.Customweb == 'undefined'){
			window.Customweb = {};
		}
	
		if(typeof Customweb.PayItEasyCw == 'undefined'){
			Customweb.PayItEasyCw = {};
		}
	
		Customweb.PayItEasyCw.Validation = {
			validators: [],
	
			getFormElement: function(obj) {
				var obj_parent = obj.parentNode;
				if (!obj_parent) return false;
				if (obj_parent.tagName.toLowerCase() == 'form') { return obj_parent; }
				else { return getFormElement(obj_parent); }
			},
	
			addValidator: function(id, fn) {
				var me = this;
				var formId = $('#'+id).parents('form').attr('id');
				if (id == 'sAGB') formId = 'payiteasycw-payment-form';
				if (typeof this.validators[formId] == 'undefined') {
					this.validators[formId] = [];
				}
				this.validators[formId].push(fn);
			},
	
			validate: function(formId) {
				var validators = this.validators[formId];
				var isValid = true;
				for (var i=0; i<validators.length; i++) {
					if (!validators[i]()) {
						isValid = false;
					}
				}
				return isValid;
			}
		};
		\n";
	
		$prefix = '';
		if ($this->getNamespacePrefix() !== NULL) {
			$prefix = $this->getNamespacePrefix();
		}
		$js .= 'var ' . $prefix . 'registerValidatorCallbacks = function () { ';
		foreach($elements as $element) {
			foreach ($element->getValidators() as $validator) {
				$id = $validator->getControl()->getControlId();
				$js .= 'Customweb.PayItEasyCw.Validation.addValidator("' . $id . '", function (e) {';
				// Create Callback function:
				$js .= ' var el = document.getElementById("' . $id . '"); var callback = ' . $this->getValidationCallbackJs($validator) . ';';
				// Invoke callback
				$js .= ' return callback(e, el);';
				$js .= '}); ';
			}
		}
	
		// Check that the general conditions and terms are accapted:
		$js .= 'Customweb.PayItEasyCw.Validation.addValidator("sAGB", function (e) { ';
		$js .= ' var el = document.getElementById("sAGB"); var callback = ' . $this->getValidationJs('element.checked', Customweb_I18n_Translation::__('Please confirm the general terms and conditions')) . ';';
		// Invoke callback
		$js .= ' return callback(e, el);';
		$js .= '}); ';
	
		$js .= '}; ';
		return $js;
	}
	
	public function getValidationCallbackJs($validator)
	{
		return $this->getValidationJs($validator->getValidationCondition(), $validator->getErrorMessage());
	}
	
	protected function getValidationJs($jsCondition, $message) {
		$js = 'function (e, element) { ' .
			'if (element) {' .
			'$(element).removeClass("instyle_error"); ' .
			'$("#" + element.id + "_validation_error").remove(); ' .
			'if (!(' .
			$jsCondition.
			')) {' .
			'$(element).addClass("instyle_error");' .
			'if (element.id == "sAGB"){' .
			'$("#confirm, #gFull").prepend("<div class=\"error bold center alert alert-danger\" id=\"" + element.id + "_validation_error\">' . str_replace('"', '\"', $message) . '</div>");' .
			'$(window).scrollTop(0); ' .
			'} else {' .
			'$(element).parents(".control-group").children(".controls").after("<div class=\"form-error\" id=\"" + element.id + "_validation_error\">' . str_replace('"', '\"', $message) . '</div>");' .
			'}' .
			'return false;' .
			'};}; return true; }';
		return $js;
	}
}