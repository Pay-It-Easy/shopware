/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/history"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.History', {
    extend: 'Ext.container.Container',
    
    layout: 'border',
        
    initComponent: function() {
        var me = this;
 
        me.items = me.getItems();
 
        me.callParent(arguments);
    },
    
    getItems: function() {
    	var me = this;
    	    	
    	var items = [
    		me.createGrid()
    	];
    	
    	return items;
    },
    
    createGrid: function() {
    	var me = this;
    	
    	var grid = Ext.create('Ext.grid.Panel', {
            region: 'center',
    		columns: [
    			{
    			    header: '{s name=payiteasycw/5fc732311905cb27e82d67f4f6511f7f}Date{/s}',
    			    dataIndex: 'date',
    			    xtype:'datecolumn',
    			    format:'d.m.Y H:i:s',
    			    width: 120
    			},
    			{
    	            header: '{s name=payiteasycw/418c5509e2171d55b0aee5c2ea4442b5}Action{/s}',
    	            dataIndex: 'action',
    	            width: 150
            	},
            	{
    	            header: '{s name=payiteasycw/78e731027d8fd50ed642340b7c9a63b3}Message{/s}',
    	            dataIndex: 'message',
    	            flex: 1
            	}
    		],
    		store: me.record.getHistory()
    	});
    	grid.store.sort([{
    		property : 'date',
    		direction: 'DESC'
    	}]);
    	
    	return grid;
    }
});
//{/block}