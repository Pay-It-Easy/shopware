<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @Entity(tableName = 'payiteasycw_external_checkout_context')
 */
class PayItEasyCw_Entities_ExternalCheckoutContext extends Customweb_Payment_ExternalCheckout_AbstractContext {

	private $dispatchId;

	private $addressesUpdated = false;

	protected function loadPaymentMethodByMachineName($machineName){
		$payment = Shopware()->Models()->getRepository('Shopware\Models\Payment\Payment')->findOneByName('payiteasycw_' . $machineName);
		return new PayItEasyCw_Components_PaymentMethodWrapper($payment);
	}

	public function update(){
		$this->updateBillingAddressOnCustomer();
		$this->updateShippingAddressOnCustomer();

		$order = null;
		if (Shopware()->Modules()->Admin()->sCheckUser()) {
			$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
		}

		$this->setLanguageCode(Shopware()->Shop()->getLocale()->getLocale());

		$this->setCartUrl(PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'checkout',
			'action'		=> 'cart',
		)));

		$this->setDefaultCheckoutUrl(PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'checkout',
			'action'		=> 'confirm',
		)));

		$session = Shopware()->Session();
		if (Shopware()->Modules()->Admin()->sCheckUser()) {
			$this->setCustomerId($session['sUserId']);
			$this->setCustomerEmailAddress($session['sUserMail']);

			if ($order == null) {
				$checkout = new PayItEasyCw_Components_Checkout();
				$checkout->confirmAction();
				$checkout->postDispatch();
				$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
			}
		}

		if ($order != null) {
			$this->setCurrencyCode($order->getCurrency());
			$this->setInvoiceItems(PayItEasyCw_Components_InvoiceItems::collectInvoiceItemsByOrder($order));
		} else {
			$checkout = new PayItEasyCw_Components_Checkout();
			$currencyId = Shopware()->Session()->sBasketCurrency;
			if (empty($currencyId)) {
				$currencyId = Shopware()->Shop()->getCurrency()->getId();
			}
			if (!empty($currencyId)) {
				$currency = Shopware()->Models()->find('Shopware\Models\Shop\Currency', $currencyId);
				$this->setCurrencyCode($currency->getCurrency());
				$this->setInvoiceItems(PayItEasyCw_Components_InvoiceItems::collectInvoiceItemsByBasket($checkout->getBasket()));
			}
		}
	}

	public function hasBasketChanged(Customweb_Core_Http_IRequest $request){
		$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
		$parameters = $request->getParameters();
		if (!isset($parameters['external-checkout-context-updated-on']) || $parameters['external-checkout-context-updated-on'] != $this->getUpdatedOn()->format('Y-m-d H:i:s')
			|| $order->getCurrency() != $this->getCurrencyCode()
			|| serialize(PayItEasyCw_Components_InvoiceItems::collectInvoiceItemsByOrder($order)) != serialize($this->getInvoiceItems())) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @Column(type = 'integer')
	 */
	public function getDispatchId(){
		return $this->dispatchId;
	}

	public function setDispatchId($dispatchId){
		$this->dispatchId = $dispatchId;
		return $this;
	}

	/**
	 *
	 * @return Shopware\Models\Customer\Customer
	 */
	public function getCustomer(){
		if ($this->getCustomerId() == null) {
			return null;
		} else {
			return Shopware()->Models()->find('Shopware\Models\Customer\Customer', $this->getCustomerId());
		}
	}

	public function isAddressesUpdated(){
		return $this->addressesUpdated;
	}

	public function setAddressesUpdated(){
		$this->addressesUpdated = true;
		return $this;
	}

	private function updateBillingAddressOnCustomer()
	{
		if ($this->getBillingAddress() == null || !($this->getBillingAddress() instanceof Customweb_Payment_Authorization_OrderContext_IAddress)) {
			return;
		}
		if (!Shopware()->Modules()->Admin()->sCheckUser()) {
			return;
		}

		$billingAddress = $this->getBillingAddress();
		$country = PayItEasyCw_Helpers_Util::getCountryByAddress($billingAddress);
		$state = PayItEasyCw_Helpers_Util::getStateByAddress($billingAddress);
		$billingStreet = Customweb_Util_Address::splitStreet($billingAddress->getStreet(), $billingAddress->getCountryIsoCode(), $billingAddress->getPostCode());
		$data = array(
			'firstname' => $billingAddress->getFirstName(),
			'lastname' => $billingAddress->getLastName(),
			'phone' => $billingAddress->getPhoneNumber(),
			'birthyear' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('Y') : null,
			'birthmonth' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('n') : null,
			'birthday' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('j') : null,
			'company' => $billingAddress->getCompanyName(),
			'street' => $billingStreet['street'],
			'streetnumber' => $billingStreet['street-number'],
			'zipcode' => $billingAddress->getPostCode(),
			'city' => $billingAddress->getCity(),
			'country' => $country != null ? $country->getId() : null,
			'stateID' => $state != null ? $state->getId() : null,
		);
		if ($billingAddress->getGender() == 'male' || $billingAddress->getGender() == 'female' || $this->isAddressesUpdated()) {
			$data['salutation'] = ($billingAddress->getGender() == 'male' ? 'mr' : ($billingAddress->getGender() == 'female' ? 'ms' : ''));
		}
		foreach ($data as $key => $value) {
			if ($value === null) {
				unset($_POST[$key]);
			} else {
				Shopware()->Front()->Request()->setPost($key, $value);
			}
		}
		Shopware()->Modules()->Admin()->sSYSTEM->_POST = $_POST;
		Shopware()->Modules()->Admin()->sUpdateBilling();
	}

	private function updateShippingAddressOnCustomer()
	{
		if ($this->getShippingAddress() == null || !($this->getShippingAddress() instanceof Customweb_Payment_Authorization_OrderContext_IAddress)) {
			return;
		}
		if (!Shopware()->Modules()->Admin()->sCheckUser()) {
			return;
		}

		$shippingAddress = $this->getShippingAddress();
		$country = PayItEasyCw_Helpers_Util::getCountryByAddress($shippingAddress);
		$state = PayItEasyCw_Helpers_Util::getStateByAddress($shippingAddress);
		$shippingStreet = Customweb_Util_Address::splitStreet($shippingAddress->getStreet(), $shippingAddress->getCountryIsoCode(), $shippingAddress->getPostCode());
		$data = array(
			'firstname' => $shippingAddress->getFirstName(),
			'lastname' => $shippingAddress->getLastName(),
			'company' => $shippingAddress->getCompanyName(),
			'street' => $shippingStreet['street'],
			'streetnumber' => $shippingStreet['street-number'],
			'zipcode' => $shippingAddress->getPostCode(),
			'city' => $shippingAddress->getCity(),
			'country' => $country != null ? $country->getId() : null,
			'stateID' => $state != null ? $state->getId() : null,
		);
		if ($shippingAddress->getGender() == 'male' || $shippingAddress->getGender() == 'female' || $this->isAddressesUpdated()) {
			$data['salutation'] = ($shippingAddress->getGender() == 'male' ? 'mr' : ($shippingAddress->getGender() == 'female' ? 'ms' : ''));
		}
		foreach ($data as $key => $value) {
			if ($value === null) {
				unset($_POST[$key]);
			} else {
				Shopware()->Front()->Request()->setPost($key, $value);
			}
		}
		Shopware()->Modules()->Admin()->sSYSTEM->_POST = $_POST;
		Shopware()->Modules()->Admin()->sUpdateShipping();
	}
}