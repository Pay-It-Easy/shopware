//{namespace name=backend/payiteasycw/main}

/**
 * Add custom fields to order model.
 * 
 * @author Simon Schurter
 */
//{block name="backend/order/model/order/fields" append}
	{ name : 'payiteasycw', type: 'boolean' },
	{ name : 'pluginId', type: 'int' },
//{/block}