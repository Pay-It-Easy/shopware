<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 * @Bean
 */
class PayItEasyCw_Components_ExternalCheckoutService extends Customweb_Payment_ExternalCheckout_AbstractCheckoutService
{
	private static $active = false;
	
	private $checkoutVariables = null;
	
	public static function isActive()
	{
		return self::$active;
	}
	
	public function updateBillingAddress(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_Payment_Authorization_OrderContext_IAddress $address) {
		parent::updateBillingAddress($context, $address);
		$context->setAddressesUpdated();
	}
	
	public function updateShippingAddress(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_Payment_Authorization_OrderContext_IAddress $address) {
		parent::updateShippingAddress($context, $address);
		$context->setAddressesUpdated();
	}
	
	public function loadContext($contextId, $cache = true)
	{
		return $this->getEntityManager()->fetch('PayItEasyCw_Entities_ExternalCheckoutContext', $contextId, $cache);
	}
	
	public function authenticate(Customweb_Payment_ExternalCheckout_IContext $context, $emailAddress, $successUrl)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		if (Shopware()->Modules()->Admin()->sCheckUser()) {
			$context->update();
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($context);
			return Customweb_Core_Http_Response::redirect($successUrl);
		}
		
		$checkIfMailExists = Shopware()->Db()->fetchRow(
				'SELECT id FROM s_user WHERE email = ? AND accountmode != 1',
				$emailAddress
		);
		if (!$checkIfMailExists && PayItEasyCw_Helpers_Util::getConfigValue('external_checkout_account_creation') == 'skip_selection') {
			$this->createGuestAccount($emailAddress, $context);
			$context->update();
			$this->getEntityManager()->persist($context);
			return Customweb_Core_Http_Response::redirect($successUrl);
		}
		
		$context->setAuthenticationEmailAddress($emailAddress);
		$context->setAuthenticationSuccessUrl($successUrl);
		$this->getEntityManager()->persist($context);
		
		return Customweb_Core_Http_Response::redirect(PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'account',
			'action'		=> 'login',
			'sTarget'		=> 'PayItEasyCwExternalCheckout',
			'forceSecure'	=> true,
		)));
	}
	
	public function renderShippingMethodSelectionPane(Customweb_Payment_ExternalCheckout_IContext $context, $errorMessages)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$templateContext = new Customweb_Mvc_Template_RenderContext();
		$templateContext->setSecurityPolicy(new Customweb_Mvc_Template_SecurityPolicy());
		$templateContext->setTemplate('externalCheckout/shippingMethodSelection');
		$templateContext->addVariables($this->getCheckoutVariables());
		$templateContext->addVariable('shippingMethodSelectionError', $errorMessages);
		$templateContext->addVariable('esdBasket', $this->isEsdBasket());
		return PayItEasyCw_Helpers_Util::getTemplateRenderer()->render($templateContext);
	}
	
	public function getPossiblePaymentMethods(Customweb_Payment_ExternalCheckout_IContext $context)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$query = Shopware()->Models()->createQuery("SELECT p FROM Shopware\Models\Payment\Payment p WHERE p.name LIKE 'payiteasycw_%'");
		$paymentMethods = array();
		foreach ($query->getResult() as $payment) {
			$paymentMethods[] = new PayItEasyCw_Components_PaymentMethodWrapper($payment);
		}
		return $paymentMethods;
	}
	
	public function renderReviewPane(Customweb_Payment_ExternalCheckout_IContext $context, $renderConfirmationFormElements, $errorMessage)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$templateContext = new Customweb_Mvc_Template_RenderContext();
		$templateContext->setSecurityPolicy(new Customweb_Mvc_Template_SecurityPolicy());
		$templateContext->setTemplate('externalCheckout/review');
		$templateContext->addVariables($this->getCheckoutVariables());
		$templateContext->addVariable('reviewError', $errorMessage);
		$templateContext->addVariable('processingLabel', Customweb_I18n_Translation::__('Processing'));
		$templateContext->addVariable('renderConfirmationFormElements', $renderConfirmationFormElements);
		$templateContext->addVariable('contextUpdatedOn', $context->getUpdatedOn()->format('Y-m-d H:i:s'));
		return PayItEasyCw_Helpers_Util::getTemplateRenderer()->render($templateContext);
	}
		
	public function validateReviewForm(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_Core_Http_IRequest $request)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$parameters = $request->getParameters();
		
		$this->getCheckoutVariables();
		if ($context->hasBasketChanged($request)) {
			$context->update();
			$this->getEntityManager()->persist($context);
			throw new Exception(Customweb_I18n_Translation::__('The shopping cart has been altered!'));
		}
		
		if ($context->getShippingMethodName() == null) {
			throw new Exception(Customweb_I18n_Translation::__('Please select a shipping method before sending the order.'));
		}
		
		if (!Shopware()->Config()->get('IgnoreAGB') && (!isset($parameters['sAGB']) || empty($parameters['sAGB']))) {
			throw new Exception(Customweb_I18n_Translation::__('Please confirm the general terms and conditions'));
		}
	}
	
	public function renderAdditionalFormElements(Customweb_Payment_ExternalCheckout_IContext $context, $errorMessage) {
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$templateContext = new Customweb_Mvc_Template_RenderContext();
		$templateContext->setSecurityPolicy(new Customweb_Mvc_Template_SecurityPolicy());
		$templateContext->setTemplate('externalCheckout/additionalForm');
		$templateContext->addVariables($this->getCheckoutVariables());
		$templateContext->addVariable('additionalFormError', $errorMessage);
		
		$templateContext->addVariable('incompleteInformationLabel', Customweb_I18n_Translation::__('Incomplete Information'));
		
		$billingSalutation = Shopware()->Db()->fetchOne(
				'SELECT salutation FROM s_user_billingaddress WHERE userID = ?',
				array(Shopware()->Session()->sUserId)
		);
		$shippingSalutation = Shopware()->Db()->fetchOne(
				'SELECT salutation FROM s_user_shippingaddress WHERE userID = ?',
				array(Shopware()->Session()->sUserId)
		);
		$templateContext->addVariable('billingSalutationField', empty($billingSalutation));
		$templateContext->addVariable('shippingSalutationField', empty($shippingSalutation));
		$templateContext->addVariable('billingSalutation', $billingSalutation);
		$templateContext->addVariable('shippingSalutation', $shippingSalutation);
		
		return PayItEasyCw_Helpers_Util::getTemplateRenderer()->render($templateContext);
	}
	
	public function processAdditionalFormElements(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_Core_Http_IRequest $request) {
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$parameters = $request->getParameters();
		$session = Shopware()->Session();
		
		$billingSalutation = $context->getCustomer()->getBilling()->getSalutation();
		if (empty($billingSalutation)) {
			if (isset($parameters['register_personal_billing_salutation']) && !empty($parameters['register_personal_billing_salutation'])){
				Shopware()->Db()->update('s_user_billingaddress', array(
					'salutation' => $parameters['register_personal_billing_salutation']
				), array(
					'userID='.(int) $session->sUserId
				));
			} else {
				throw new Exception(Customweb_I18n_Translation::__('Please select the salutation of the billing address.'));
			}
		}
		
		$shippingSalutation = $context->getCustomer()->getShipping()->getSalutation();
		if (empty($shippingSalutation)) {
			if (isset($parameters['register_personal_shipping_salutation']) && !empty($parameters['register_personal_shipping_salutation'])){
				Shopware()->Db()->update('s_user_shippingaddress', array(
					'salutation' => $parameters['register_personal_shipping_salutation']
				), array(
					'userID='.(int) $session->sUserId
				));
			} else {
				throw new Exception(Customweb_I18n_Translation::__('Please select the salutation of the shipping address.'));
			}
		}
		
		if (isset($parameters['sComment']) && !empty($parameters['sComment'])) {
			$session['sComment'] = trim(strip_tags($parameters['sComment']));
		}
		
		if (isset($parameters['sNewsletter']) && !empty($parameters['sNewsletter'])) {
			$session['sNewsletter'] = $parameters['sNewsletter'] ? true : false;
		}
	}
	
	protected function updateShippingMethodOnContext(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_Core_Http_IRequest $request)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$parameters = $request->getParameters();
		
		$context->setDispatchId($parameters['sDispatch']);

		$session = Shopware()->Session();
		$session['sDispatch'] = (int) $parameters['sDispatch'];
	}
	
	protected function extractShippingName(Customweb_Payment_ExternalCheckout_IContext $context, Customweb_Core_Http_IRequest $request)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$parameters = $request->getParameters();
		$dispatch = Shopware()->Models()->find('Shopware\Models\Dispatch\Dispatch', $parameters['sDispatch']);
		return $dispatch->getName();
	}
	
	protected function createTransactionContextFromContext(Customweb_Payment_ExternalCheckout_IContext $context)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		$this->redirectOnEmptyBasket();
		
		$this->getCheckoutVariables();
		
		$orderHelper = new PayItEasyCw_Components_Order();
		$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
		$paymentMethod = $context->getPaymentMethod();
		if (!($paymentMethod instanceof PayItEasyCw_Components_PaymentMethodWrapper)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Components_PaymentMethodWrapper');
		}
		
		if (PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			$orderHelper->backupBasket();
			$orderNumber = $orderHelper->createOrder();
			$orderHelper->restoreBasket();
			$orderHelper->createTemporaryOrder();
			
			$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $orderNumber));
		}
		
		$transaction = $paymentMethod->createTransaction($order);
		$transaction->setSessionData(array(
			'session' => $_SESSION,
			'shopId' => Shopware()->Shop()->getId(),
			'currency' => Shopware()->Shop()->getCurrency()->toArray(),
			'id' => session_id()
		));
		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);
		
		$session = Shopware()->Session();
		if (!empty($session['sNewsletter'])) {
			Shopware()->Modules()->Admin()->sUpdateNewsletter(true, Shopware()->Modules()->Admin()->sGetUserMailById(), true);
		}
		
		$transactionContext = $paymentMethod->getTransactionContext($transaction, $order);
		
		if (PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			$transaction->setOrderId($order->getId());
			$transaction->setShopId($order->getShop()->getId());
			$transaction->setTemporaryOrderId(null);
			$transaction->setLastSetOrderStatusSettingKey(null);
			$transaction->setEmailData(PayItEasyCw_Components_Order::getEmailVariables());
			if ($transactionContext instanceof PayItEasyCw_Components_RecurringTransactionContext) {
				$paymentMethod->finishRecurring($transaction, $order);
			}
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);
			
			$orderHelper = new PayItEasyCw_Components_Order($transaction);
			$orderHelper->updateOrder();
		}
		
		return $transactionContext;
	}
	
	protected function refreshContext(Customweb_Payment_ExternalCheckout_AbstractContext $context)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		if ($this->isEsdBasket()) {
			$context->setShippingMethodName(Customweb_I18n_Translation::__('No shipping method needed.'));
		} elseif ($context->getDispatchId() == null && Shopware()->Session()->sDispatch != null) {
			$context->setDispatchId(Shopware()->Session()->sDispatch);
			$dispatch = Shopware()->Models()->find('Shopware\Models\Dispatch\Dispatch', Shopware()->Session()->sDispatch);
			$context->setShippingMethodName($dispatch->getName());
		}
		
		$paymentMethod = $context->getPaymentMethod();
		if ($paymentMethod != null && $paymentMethod instanceof PayItEasyCw_Components_PaymentMethodWrapper) {
			if ($this->isEsdBasket() && !$paymentMethod->getPaymentMethod()->getEsdActive()) {
				throw new Exception(Customweb_I18n_Translation::__('This checkout method is not available for instant downloads.'));
			}
			Shopware()->Modules()->Admin()->sSYSTEM->_POST['sPayment'] = $paymentMethod->getPaymentMethod()->getId();
			Shopware()->Modules()->Admin()->sValidateStep3();
			Shopware()->Modules()->Admin()->sUpdatePayment();
		}
		
		if ($context->getBillingAddress() !== null && $context->getBillingAddress() instanceof Customweb_Payment_Authorization_OrderContext_IAddress) {
			$country = PayItEasyCw_Helpers_Util::getCountryByAddress($context->getBillingAddress());
			if ($country != null) {
				if (!$country->getActive()) {
					$context->setBillingAddress(null);
					throw new Exception(Customweb_I18n_Translation::__('It is not possible to checkout in your country.'));
				}
			}
		}
		
		if ($context->getShippingAddress() !== null && $context->getShippingAddress() instanceof Customweb_Payment_Authorization_OrderContext_IAddress) {
			$country = PayItEasyCw_Helpers_Util::getCountryByAddress($context->getShippingAddress());
			if ($country != null) {
				if (!$country->getActive()) {
					$context->setShippingAddress(null);
					throw new Exception(Customweb_I18n_Translation::__('It is not possible to checkout in your country.'));
				}
			}
		}
		
		if (Shopware()->Modules()->Admin()->sCheckUser()) {
			$checkout = new PayItEasyCw_Components_Checkout();
			$checkout->confirmAction();
			$checkout->postDispatch();
		}
		
		$context->update();
	}
	
	protected function updateUserSessionWithCurrentUser(Customweb_Payment_ExternalCheckout_AbstractContext $context)
	{
		if (!($context instanceof PayItEasyCw_Entities_ExternalCheckoutContext)) {
			throw new Customweb_Core_Exception_CastException('PayItEasyCw_Entities_ExternalCheckoutContext');
		}
		
		if (Shopware()->Modules()->Admin()->sCheckUser()) {
			$context->update();
			return;
		}
		
		$emailAddress = $context->getCustomerEmailAddress();
		$userId = Shopware()->Db()->fetchRow(
			'SELECT id FROM s_user WHERE email = ? AND accountmode != 1',
			$emailAddress
		);
		if ($userId) {
			$user = Shopware()->Models()->find('Shopware\Models\Customer\Customer', $userId);
			
			Shopware()->Front()->Request()->setPost('email',$emailAddress);
			Shopware()->Front()->Request()->setPost('passwordMD5', $user->getPassword());
			Shopware()->Modules()->Admin()->sSYSTEM->_POST = $_POST;
			Shopware()->Modules()->Admin()->sLogin(true);
			Shopware()->Modules()->Basket()->sRefreshBasket();
		} else {
			$this->createGuestAccount($emailAddress, $context);
		}
		
		$context->update();
	}
	
	private function createGuestAccount($emailAddress, Customweb_Payment_ExternalCheckout_AbstractContext $context)
	{
		$billingAddress = $context->getBillingAddress();
		$shippingAddress = $context->getShippingAddress();
		$country = PayItEasyCw_Helpers_Util::getCountryByAddress($billingAddress);
		$billingStreet = Customweb_Util_Address::splitStreet($billingAddress->getStreet(), $billingAddress->getCountryIsoCode(), $billingAddress->getPostCode());
		$shippingStreet = Customweb_Util_Address::splitStreet($shippingAddress->getStreet(), $shippingAddress->getCountryIsoCode(), $shippingAddress->getPostCode());
		$register = array(
			'auth' => array(
				'accountmode' => 1,
				'email' => $emailAddress,
				'receiveNewsletter' => false,
				'encoderName' => 'md5',
				'password' => md5(uniqid(rand())),
			),
			'billing' => array(
				'customer_type' => 'private',
				'salutation' => ($billingAddress->getGender() == 'male' ? 'mr' : ($billingAddress->getGender() == 'female' ? 'ms' : '')),
				'firstname' => $billingAddress->getFirstName(),
				'lastname' => $billingAddress->getLastName(),
				'phone' => $billingAddress->getPhoneNumber(),
				'birthyear' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('Y') : null,
				'birthmonth' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('n') : null,
				'birthday' => $billingAddress->getDateOfBirth() != null ? $billingAddress->getDateOfBirth()->format('j') : null,
				'company' => $billingAddress->getCompanyName(),
				'street' => $billingStreet['street'],
				'streetnumber' => $billingStreet['street-number'],
				'zipcode' => $billingAddress->getPostCode(),
				'city' => $billingAddress->getCity(),
				'country' => $country != null ? $country->getId() : null,
				'shippingAddress' => 1
			),
			'shipping' => array(
				'salutation' => ($shippingAddress->getGender() == 'male' ? 'mr' : ($shippingAddress->getGender() == 'female' ? 'ms' : '')),
				'firstname' => $shippingAddress->getFirstName(),
				'lastname' => $shippingAddress->getLastName(),
				'company' => $shippingAddress->getCompanyName() != null ? $shippingAddress->getCompanyName() : '',
				'department' => '',
				'street' => $shippingStreet['street'],
				'streetnumber' => $shippingStreet['street-number'],
				'zipcode' => $shippingAddress->getPostCode(),
				'city' => $shippingAddress->getCity(),
				'country' => $country != null ? $country->getId() : null,
			)
		);
		Shopware()->Session()->sRegister = $register;
		self::$active = true;
		Shopware()->Modules()->Admin()->sSaveRegister();
		self::$active = false;
	}
	
	private function getCheckoutVariables()
	{
		if ($this->checkoutVariables == null) {
			$checkout = new PayItEasyCw_Components_Checkout();
			$checkout->confirmAction();
			$checkout->postDispatch();
			$this->checkoutVariables = $checkout->View()->getAssign();
			
			$session = Shopware()->Session();
			$session['sOrderVariables'] = new ArrayObject($checkout->View()->getAssign(), ArrayObject::ARRAY_AS_PROPS);
		}
		return $this->checkoutVariables;
	}
	
	private function redirectOnEmptyBasket()
	{
		if (Shopware()->Modules()->Basket()->sCountBasket()<1) {
			header("Location: " . PayItEasyCw_Helpers_Util::getUrl(array(
				'module'		=> 'frontend',
				'controller'	=> 'checkout',
				'action'		=> 'cart',
			)));
			die();
		}
	}
	
	private function isEsdBasket()
	{
		if (Shopware()->Modules()->Admin()->sCheckUser()) {
			return PayItEasyCw_Helpers_Util::isEsdOrder(PayItEasyCw_Helpers_Util::getTemporaryOrder());
		} else {
			$checkout = new PayItEasyCw_Components_Checkout();
			return PayItEasyCw_Helpers_Util::isEsdBasket($checkout->getBasket());
		}
	}
}