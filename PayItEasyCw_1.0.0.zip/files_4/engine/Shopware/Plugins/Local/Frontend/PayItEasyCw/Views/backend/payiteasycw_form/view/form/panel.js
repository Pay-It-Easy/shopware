//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_form/view/form/panel"}
Ext.define('Shopware.apps.PayiteasycwForm.view.form.Panel', {
    extend : 'Ext.panel.Panel',
    autoShow: true,
    alias : 'widget.payiteasycw-main-panel',
    region: 'center',
    layout: 'anchor',
    autoScroll: true,
    bodyPadding: '0',
    name:  'panel',
    preventHeader: true,
    border: 0,

    initComponent: function(){
        var me = this;
        me.items = [];
        me.callParent(arguments);
    },

    loadRecord: function(record, shop){
        var me = this;
        me.renderForm(record, shop);
    },

    renderForm: function(record, shop){
        var me = this,
            itemToRemove;
        while(itemToRemove = me.items.first()){
          me.remove(itemToRemove, true);
        }
        me.iframe = Ext.create('Ext.Component', {
        	autoEl: {
        		tag: 'iframe',
        		src: record.get('formUrl').replace('_shop_', shop.get('id'))
        	}
        });
        me.add(me.iframe);
        me.doLayout();
    }
});
//{/block}