//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_base/view/transaction/window"}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.Window', {
    extend: 'Enlight.app.Window',

    cls: Ext.baseCSSPrefix + 'payiteasycw-base-transaction-window',
    alias: 'widget.payiteasycw-transactions-base-transaction-window',
    border: false,
    autoShow: true,
    layout: 'fit',
    width: 900,
    height: '90%',
    stateful: true,
    footerButton:false,
    stateId: 'shopware-payiteasycw-base-transaction-window',

    initComponent: function() {
      var me = this;

      me.callParent(arguments);
      
      if(me.record) {
          me.createPanel();
      }
  },
  
  createPanel: function() {
	  var me = this;
	  
	  me.detailPanel = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.Transaction', {
          record: me.record
      });
	  me.add(me.detailPanel);
	  me.updateTitle(me.record);
  },
  
  updateRecord: function(record) {
  	var me = this;
  	me.record = record;
  	me.detailPanel.updateRecord(record);
  	me.updateTitle(record);
  },
  
  updateTitle: function() {
	  var me = this;
	  me.setTitle('{s name=payiteasycw/e8b83248afc06b980e2fb0a5e1d74614}Transaction Details{/s}: ' + me.record.get('transactionId'));
  }
});
//{/block}