<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

use Shopware\Models\Order\Order;
use Shopware\Models\Payment\Payment;

/**
 * This class represents a transaction context.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_TransactionContext implements Customweb_Payment_Authorization_ITransactionContext, Customweb_Payment_Authorization_PaymentPage_ITransactionContext, Customweb_Payment_Authorization_Hidden_ITransactionContext, Customweb_Payment_Authorization_Iframe_ITransactionContext, Customweb_Payment_Authorization_Server_ITransactionContext, Customweb_Payment_Authorization_Widget_ITransactionContext, Customweb_Payment_Authorization_Ajax_ITransactionContext
{
	/**
	 * @transient
	 * @var PayItEasyCw_Entities_Transaction
	 */
	private $transaction = null;

	/**
	 * @transient
	 * @var PayItEasyCw_Entities_Transaction
	 */
	private $alias = null;

	/**
	 * @var integer
	 */
	protected $transactionId;

	/**
	 *
	 * @var integer
	 */
	protected $orderId = null;

	/**
	 *
	 * @var string
	 */
	protected $orderNumber = null;

	/**
	 *
	 * @var boolean
	 */
	protected $useOrderNumber = false;

	/**
	 * @var PayItEasyCw_Components_OrderContext
	 */
	protected $orderContext;

	/**
	 * @var PayItEasyCw_Entities_PaymentCustomerContext
	 */
	protected $customerContext;

	/**
	 * @var string|integer
	 */
	protected $aliasTransactionId = null;

	/**
	 * @var string
	 */
	protected $capturingMode;

	/**
	 * Create a transaction context.
	 *
	 * @param PayItEasyCw_Entities_Transaction $transaction
	 * @param Shopware\Models\Order\Order $order
	 * @param Shopware\Models\Payment\Payment $paymentMethod
	 * @param string|integer $aliasTransactionId
	 */
	public function __construct(PayItEasyCw_Entities_Transaction $transaction, Order $order, Payment $paymentMethod, $aliasTransactionId = NULL)
	{
		$this->transactionId = $transaction->getTransactionId();
		if ($order->getTemporaryId() == '') {
			$this->orderId = $order->getId();
			$this->orderNumber = $order->getNumber();
			$this->useOrderNumber = (PayItEasyCw_Helpers_Util::getConfigValue('order_identifier') == 'order_number');
		}
		$this->orderContext = new PayItEasyCw_Components_OrderContext($order->getId(), $paymentMethod->getId());
		$this->customerContext = PayItEasyCw_Helpers_Util::loadPaymentCustomerContextByCustomer($order->getCustomer()->getId());
		$this->capturingMode = $this->getOrderContext()->getPaymentMethod()->getPaymentMethodConfigurationValue('capturing');

		if ($this->getOrderContext()->getPaymentMethod()->getPaymentMethodConfigurationValue('alias_manager') == 'active') {
			if ($aliasTransactionId === NULL || $aliasTransactionId === 'new') {
				$this->aliasTransactionId = 'new';
			} else {
				$this->aliasTransactionId = intval($aliasTransactionId);
			}
		}

		unset($_SESSION['payiteasycw_checkout_id']);
	}

	public function __sleep() {
		return array('transactionId', 'capturingMode', 'aliasTransactionId', 'customerContext', 'orderContext', 'orderId', 'orderNumber', 'useOrderNumber');
	}

	public function getOrderContext()
	{
		return $this->orderContext;
	}

	public function getTransactionId()
	{
		return $this->transactionId;
	}

	public function getOrderId()
	{
		if ($this->useOrderNumber) {
			return $this->orderNumber;
		} else {
			return $this->orderId;
		}
	}

	public function isOrderIdUnique()
	{
		return !$this->useOrderNumber;
	}

	/**
	 * @return PayItEasyCw_Entities_Transaction
	 */
	public function getTransaction() {
		if ($this->transaction === NULL) {
			$this->transaction = PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_Transaction', $this->transactionId);
		}
		return $this->transaction;
	}

	public function getCapturingMode()
	{
		return null;
	}

	public function getAlias()
	{
		if ($this->getOrderContext()->getPaymentMethod()->getPaymentMethodConfigurationValue('alias_manager') !== 'active') {
			return null;
		}

		if ($this->aliasTransactionId === 'new') {
			return 'new';
		}

		if ($this->aliasTransactionId !== null) {
			if ($this->alias == null) {
				$this->alias = PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_Transaction', $this->aliasTransactionId)->getTransactionObject();
			}
			return $this->alias;
		}

		return null;
	}

	public function createRecurringAlias()
	{
		return $this->getOrderContext()->isRecurring();
	}

	public function getCustomParameters()
	{
		return array(
			'cstrxid' => $this->transactionId
		);
	}

	public function getPaymentCustomerContext()
	{
		return $this->customerContext;
	}

	protected function getProcessUrl()
	{
		return PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'PayItEasyCwProcess',
			'action'		=> 'process',
			'forceSecure'	=> true
		));
	}

	public function getNotificationUrl()
	{
		return $this->getProcessUrl();
	}

	public function getSuccessUrl()
	{
		return PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'PayItEasyCwProcess',
			'action'		=> 'success',
			'forceSecure'	=> true
		));
	}

	public function getFailedUrl()
	{
		return PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'PayItEasyCwProcess',
			'action'		=> 'fail',
			'forceSecure'	=> true
		));
	}

	public function getIframeBreakOutUrl()
	{
		return PayItEasyCw_Helpers_Util::getUrl(array(
			'module'		=> 'frontend',
			'controller'	=> 'PayItEasyCwCheckout',
			'action'		=> 'breakout',
			'forceSecure'	=> true
		));
	}

	public function getJavaScriptSuccessCallbackFunction()
	{
		return "function(url){window.location = url;}";
	}

	public function getJavaScriptFailedCallbackFunction()
	{
		return "function(url){window.location = url;}";
	}
}
