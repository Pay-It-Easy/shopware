//{block name="backend/payiteasycw_form/store/form"}
Ext.define('Shopware.apps.PayiteasycwForm.store.Form', {
    extend : 'Ext.data.TreeStore',
    
    alias : 'store.form',
    
    autoLoad : false,
    
    pageSize : 30,
    
    model : 'Shopware.apps.PayiteasycwForm.model.Form'
});
//{/block}