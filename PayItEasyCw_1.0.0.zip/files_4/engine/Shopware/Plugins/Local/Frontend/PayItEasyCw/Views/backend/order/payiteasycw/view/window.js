/**
 * This view extends the order window with a order transactions tab.
 * 
 * @author Simon Schurter
 */
//{block name="backend/order/view/detail/window" append}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.Order.Plugin{$payiteasycw_plugin_id}.view.window.TransactionTab', {
	/**
     * Return order transaction tab.
     * 
     * @return Ext.container.Container
     */
    createOrderTransactionTab: function(parent) {
        var me = this;
        
        var tabTransactionStore = Ext.create('Shopware.apps.PayiteasycwBase.store.Transaction');
        
        me.transactionList = Ext.create('Shopware.apps.Order.Payiteasycw.view.List', {
        	store: tabTransactionStore,
        	layout: {
                type: 'vbox',
                align: 'stretch'
            },
        	region: 'north',
        	height: '20%'
        });
        
        me.transactionDetail = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.Transaction', {
        	region: 'center'
        });
        
        parent.orderTransactionsTab = Ext.create('Ext.container.Container', {
            title: '{s name=payiteasycw/c15b977dd99332ca8623fbdfb86827e8}Transactions{/s}',
            disabled: parent.record.get('id') === null,
            layout: 'border',
            items: [
                me.transactionList,
                me.transactionDetail
            ],
            listeners: {
                activate: function() {
                	tabTransactionStore.load({
                		params: {
                			orderId: parent.record.get('id')
                		}
                	});
                	parent.fireEvent('orderTransactionsTabActivated', parent);
                }
            }
        });
 
        return parent.orderTransactionsTab;
    }
});

Ext.define('Shopware.apps.Order.Payiteasycw.view.Window', {
    override: 'Shopware.apps.Order.view.detail.Window',
    
    alias: 'widget.payiteasycw-order-transaction-window',
 
    /**
     * @Override
     * Create the main tab panel which displays the different tabs.
     *
     * @return Ext.tab.Panel
     */
    createTabPanel: function() {
        var me = this, result;
 
        result = me.callParent(arguments);
        
        if (me.record.get('payiteasycw') == true) {
        	me.transactionTab = Ext.create('Shopware.apps.Order.Plugin' + me.record.get('pluginId') + '.view.window.TransactionTab');
        	result.add(me.transactionTab.createOrderTransactionTab(me));
        }
 
        return result;
    },
    
    updateRecord: function(record) {
    	var me = this;
    	me.transactionTab.transactionDetail.updateRecord(record);
    }
});
//{/block}