/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/overview"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.Overview', {
    extend: 'Ext.form.Panel',
    
    alias:'widget.payiteasycw-base-transaction-overview',
    
	layout: 'column',
	
	initComponent: function() {
        var me = this;
        me.registerEvents();
        me.items = me.getItems();
        me.dockedItems = me.createToolbar();
        me.callParent(arguments);
    },
    
    registerEvents: function() {
        this.addEvents(
            'updateTransaction'
        );
    },
    
    getItems: function() {
    	var me = this;
    	
    	var fields = me.createFields();
    	
    	var items = [
    		me.createColumn(fields.left),
    		me.createColumn(fields.right),
    	];
    	
    	return items;
    },
    
    createColumn: function(fields) {
    	var me = this;
    	
    	var column = Ext.create('Ext.container.Container', {
    		columnWidth:	0.5,
    	    layout:			'anchor',
    	    padding:		'10px 20px',
    	    defaults: {
    	    	anchor:		'100%',
    	    	xtype:		'displayfield',
    	        labelWidth:	155,
    	        fieldStyle:	'margin-top: 5px;'
    	    },
    	    items:			fields
    	});
    	
    	return column;
    },
    
    createFields: function() {
        var me = this,
        	field,
        	fields = { left: [], right: [] },
        	labels = me.record.get('labels'),
        	count = Math.ceil(Object.keys(labels).length / 2),
        	i = 1;
        for (var key in labels) {
        	field = { value: labels[key]['value'], fieldLabel: labels[key]['label'], helpText: labels[key]['description'] };
        	if (i <= count) {
        		fields.left.push(field);
        	} else {
        		fields.right.push(field);
        	}
        	i++;
        }
        return fields;
    },
    
    createToolbar: function() {
    	var me = this;
    	
    	var toolbar = [{
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            border: 0,
            defaults: {
            	xtype: 'button'
            },
            items: me.createButtons()
        }];
    	
    	return toolbar;
    },
    
    createButtons: function() {
    	var me = this;
    	
    	var buttons = [{ xtype: 'component', flex: 1 }];
    	
    	
    	
    	return buttons;
    },
});
//{/block}