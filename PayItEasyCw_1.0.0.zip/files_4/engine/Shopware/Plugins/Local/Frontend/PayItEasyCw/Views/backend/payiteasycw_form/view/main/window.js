//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_form/view/main/window"}
Ext.define('Shopware.apps.PayiteasycwForm.view.main.Window', {
	extend: 'Enlight.app.Window',
	
    title: 'Pay-It-Easy',
    cls: Ext.baseCSSPrefix + 'form-window',
    alias: 'widget.payiteasycw-main-window',
    border: false,
    autoShow: true,
    layout: 'border',
    height: '90%',
    width: 925,

    stateful:true,
    stateId:'shopware-form-window',

    initComponent: function() {
        var me = this;

        me.registerEvents();
        me.tabPanel = me.createTabPanel();
        me.tree = Ext.create('Shopware.apps.PayiteasycwForm.view.form.Tree');
        me.items = [{
            xtype: 'container',
            region: 'center',
            layout: 'border',
            items: [ me.tabPanel ]
        }, me.tree ];
        
        me.on('resize', function(me){
        	if (me.tabPanel.getActiveTab()) {
	        	var iframe = me.tabPanel.getActiveTab().iframe;
	        	if (iframe) {
	        		iframe.getEl().dom.contentWindow.payiteasycwLayout();
	        	}
        	}
        });

        me.callParent(arguments);
    },

    registerEvents: function() {
        this.addEvents(
            'changeTab'
        );
    },

    createTabPanel: function() {
        var me = this;

        return Ext.create('Ext.tab.Panel', {
            autoShow: false,
            //disabled to enable it, when the tree is clicked at least once
            disabled: true,
            layout: 'fit',
            region: 'center',
            autoScroll: true,
            border: 0,
            bodyBorder: false,
            defaults: {
                layout: 'fit'
            },
            items: [],

            listeners: {
                tabchange: function(tabPanel, newTab, oldTab) {
                    me.fireEvent('changeTab', tabPanel, newTab, oldTab);
                }
            }
        });

    }
});
//{/block}