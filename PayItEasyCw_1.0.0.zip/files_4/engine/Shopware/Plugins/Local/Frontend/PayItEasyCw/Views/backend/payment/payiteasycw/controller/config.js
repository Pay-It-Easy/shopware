/**
 * Override payment controller to handle custom payment configurations.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payment/payiteasycw/controller/config"}
Ext.define('Shopware.apps.Payment.Payiteasycw.controller.Config', {
    override:'Shopware.apps.Payment.controller.Payment',
        
    panel: undefined,
    elements: [],
    
    /**
     * @Override
     * Encode custom configuration values so they are sent to the server and
     * persisted.
     */
    onSavePayment:function(generalForm, countryGrid, subShopGrid, surchargeGrid){
    	var record = generalForm.getRecord(),
    		me = this;
    	
    	if (record.get('payiteasycw') == true) {
	    	var values = {},
	    		key,
	    		element,
	    		valid = true;
	    	for (key in me.elements) {
	    		element = me.elements[key];
	    		if (!element.isValid()) {
	    			valid = false;
	    		}
	    		values[element.getName()] = element.getValue();
	    	}
	    	
	    	if (!valid) {
	    		return;
	    	}
	    	
	    	record.set('configValues', Ext.encode(values));
    	}
    	
    	me.callParent(arguments);
    },
    
    /**
     * @Override
     * Add the fields for the custom configuration to the payment configuration
     * form.
     */
    onItemClick:function(view, record) {
    	var win = view.up('window'),
	        form = win.generalForm,
	        me = this;
    	
    	form.remove(me.panel);
    	me.panel = null;
    	me.elements = [];
    	
    	me.callParent(arguments);
    	
    	if (record.get('payiteasycw') == true) {
			var panel = me.createFormPanel(record);
			if (panel) {
				me.panel = form.add(panel);
				form.doLayout();
			}
    	}
    },
    
    createFormPanel: function(record) {
    	var me = this;
    	
    	formElements = Ext.decode(record.get('configForm'));
    	defaultValues = Ext.decode(record.get('configValues'));
		shops = Ext.decode(record.get('configFormShops'));
		
		if (formElements) {
			var tabs = [];
			for (k = 0; k < shops.length; k++) {
	            tabs.push(me.createFormShopTab(formElements, shops[k], defaultValues));
			}
			
			return Ext.create('Ext.tab.Panel', {
				autoScroll: true,
	            border: 0,
	            bodyBorder: false,
	            margin: '0 -10px',
	            activeTab: 0,
	            items: tabs
			});
		}
    },
    
    createFormShopTab: function(formElements, shop, defaultValues) {
    	var me = this;
    	
		var fieldPanel = Ext.create('Ext.form.Panel', {
        	region:			'center',
            layout:			'anchor',
            autoScroll:		true,
            bodyPadding:	'10px',
            preventHeader:	true,
            border:			0,
            defaults: {
                labelStyle:	'font-weight: 700; text-align: right;',
                labelWidth:	130,
                anchor:		'100%'
            }
        });
        for (i = 0; i < formElements.length; i++) {
        	var field = me.createFormElement(formElements[i], shop.id, defaultValues);
        	me.elements.push(fieldPanel.add(field));
        }
        return {
			xtype: 'container',
			title: shop.name,
			items: [fieldPanel]
		};
    },
    
    createFormElement: function(formElement, shopId, defaultValues) {
    	var me = this;
    	
    	var field = {
            xtype			: formElement.xtype,
            fieldLabel		: formElement.title,
            name			: shopId + '__' + formElement.name,
            valueField		: 'value',
            displayField	: 'text',
            helpText		: formElement.description,
            allowBlank		: !formElement.required || formElement.xtype == 'multiselect'
        };
    	if (formElement.validTypes) {
    		field.validTypes = formElement.validTypes;
    	}
    	if (defaultValues && defaultValues[shopId] && defaultValues[shopId][formElement.name]) {
    		field.value = defaultValues[shopId][formElement.name];
    	} else if (formElement.value) {
    		field.value = formElement.value;
    	}
    	if (formElement.options) {
    		var dataStore = Ext.create('Ext.data.Store', {
                fields:	['value', 'text'],
                data:	formElement.options
    		});
    		field.store = dataStore;
    		field.forceSelection = true;
    	}
    	return field;
    }
});
//{/block}