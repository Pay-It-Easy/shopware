//{block name="backend/payiteasycw_form/controller/form"}
Ext.define('Shopware.apps.PayiteasycwForm.controller.Form', {
    extend:'Ext.app.Controller',
    
    currentRecord: null,

    refs: [
        { ref: 'mainWindow', selector: 'payiteasycw-main-window' }
    ],

    init:function(){
        var me = this;
        me.control({
            'payiteasycw-main-window payiteasycw-main-tree':{
                itemclick:	me.onItemClick
            },
            'payiteasycw-main-window':{
                changeTab:	me.onChangeTab
            },

        });
        me.callParent(arguments);
    },

    onChangeTab:function(tabPanel, newTab, oldTab){
    	var me = this;
    	
        newTab.loadRecord(me.currentRecord, newTab.shopRecord);
    },

    onItemClick:function(view, record) {
        var me = this,
        	win = view.up('window'),
            tabPanel = win.tabPanel,
            tabToRemove;
        
        me.currentRecord = record;
        
        tabPanel.removeAll();
        for (var i = 0; i < win.shopStore.getTotalCount(); i++) {
        	tabPanel.add({
        		xtype: 'payiteasycw-main-panel',
        		title: win.shopStore.getAt(i).get('name'),
        		shopRecord: win.shopStore.getAt(i)
        	});
        }
        tabPanel.doLayout();

        tabPanel.setDisabled(false);
        tabPanel.setActiveTab(0);
    }
});
//{/block}