<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

namespace Shopware\CustomModels\PayItEasyCw\Payment;

use Symfony\Component\Validator\Constraints as Assert, Doctrine\Common\Collections\ArrayCollection, Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * This class represents a payment method configuration.
 *
 * @author Simon Schurter
 *
 * @ORM\Entity
 * @ORM\Table(name="payiteasycw_payment_config")
 */
class Config extends ModelEntity
{
	/**
	 * @var integer $paymentId
	 *
	 * @ORM\Column(name="payment_id", type="integer", nullable=false)
	 * @ORM\Id
	 */
	private $paymentId;

	/**
	 * @var string $shopId
	 *
	 * @ORM\Column(name="shop_id", type="integer", nullable=false)
	 * @ORM\Id
	 */
	private $shopId;

	/**
	 * @var string $name
	 *
	 * @ORM\Column(name="name", type="string", nullable=false)
	 * @ORM\Id
	 */
	private $name;

	/**
	 * @var string $value
	 *
	 * @ORM\Column(name="value", type="string", nullable=true)
	 */
	private $value;


	public function __construct()
	{
		return $this;
	}

	public function setPaymentId($paymentId)
	{
		$this->paymentId = $paymentId;
		return $this;
	}

	public function getPaymentId()
	{
		return $this->paymentId;
	}

	public function setShopId($shopId)
	{
		$this->shopId = $shopId;
		return $this;
	}

	public function getShopId()
	{
		return $this->shopId;
	}

	public function setName($name)
	{
		$this->name = $name;
		return $this;
	}

	public function getName()
	{
		return $this->name;
	}

	public function setValue($value)
	{
		$this->value = $value;
		return $this;
	}

	public function getValue()
	{
		return $this->value;
	}
}
