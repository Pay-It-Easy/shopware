/**
 * This model represents a order transaction refund entry.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/model/transaction_capture"}
Ext.define('Shopware.apps.PayiteasycwBase.model.TransactionCapture', {
    extend: 'Ext.data.Model',
 
    fields: [
        //{block name="backend/payiteasycw_base/model/transaction_capture/fields"}{/block}
        { name: 'id', type: 'string' },
        { name: 'amount', type: 'string' },
        { name: 'date', type: 'date' },
        { name: 'status', type: 'string' },
        
        { name: 'labels', type: 'object' },
    ]
});
//{/block}