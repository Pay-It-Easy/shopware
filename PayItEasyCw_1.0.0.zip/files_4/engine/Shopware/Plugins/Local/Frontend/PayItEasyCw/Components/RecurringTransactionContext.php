<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

use Shopware\Models\Order\Order;
use Shopware\Models\Payment\Payment;

/**
 * This class represents a transaction context.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_RecurringTransactionContext extends PayItEasyCw_Components_TransactionContext implements Customweb_Payment_Authorization_Recurring_ITransactionContext
{
	protected $initialTransactionId;

	private $initialTransaction = null;

	public function __construct(PayItEasyCw_Entities_Transaction $transaction, Order $order, Payment $paymentMethod, $aboId) {
		parent::__construct($transaction, $order, $paymentMethod);
		$this->orderContext = new PayItEasyCw_Components_RecurringOrderContext($order->getId(), $paymentMethod->getId());

		$abo = Shopware()->Models()->find('Shopware\CustomModels\SwagAboCommerce\Order', $aboId);
		if ($abo instanceof Shopware\CustomModels\SwagAboCommerce\Order) {
			$initialTransaction = PayItEasyCw_Helpers_Util::loadInitialTransactionByOrder($abo->getOrderId());
			if ($initialTransaction !== false) {
				$this->initialTransactionId = $initialTransaction->getTransactionId();
			}
		}

		if ($this->initialTransactionId == null) {
			throw new Exception(sprintf("No initial transaction found for order %s.", $order->getId()));
		}
	}

	public function getOrderId()
	{
		if (!PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			return null;
		} else {
			return parent::getOrderId();
		}
	}

	public function __sleep() {
		$fields = parent::__sleep();
		$fields[] = 'initialTransactionId';
		return $fields;
	}

	/**
	 * (non-PHPdoc)
	 * @see Customweb_Payment_Authorization_Recurring_ITransactionContext::getInitialTransaction()
	 */
	public function getInitialTransaction() {
		if ($this->initialTransaction === NULL) {
			$this->initialTransaction = PayItEasyCw_Helpers_Util::loadTransaction($this->initialTransactionId);
		}
		return $this->initialTransaction->getTransactionObject();
	}
}