//{block name="backend/payiteasycw_form/store/shop"}
Ext.define('Shopware.apps.PayiteasycwForm.store.Shop', {
    extend : 'Ext.data.Store',
    
    alias : 'store.shop',
    
    autoLoad : false,
    
    model : 'Shopware.apps.PayiteasycwForm.model.Shop'
});
//{/block}