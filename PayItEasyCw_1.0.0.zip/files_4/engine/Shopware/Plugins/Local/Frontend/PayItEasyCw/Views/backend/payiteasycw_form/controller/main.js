//{block name="backend/payiteasycw_form/controller/main"}
Ext.define('Shopware.apps.PayiteasycwForm.controller.Main', {
    extend: 'Ext.app.Controller',

    requires: [ 'Shopware.apps.PayiteasycwForm.controller.Form' ],

    init: function() {
        var me = this;

        me.subApplication.formStore = me.subApplication.getStore('Form');
        me.subApplication.formStore.load();
        
        me.subApplication.shopStore = me.subApplication.getStore('Shop');
        me.subApplication.shopStore.load();

        me.mainWindow = me.getView('main.Window').create({
            formStore: me.subApplication.formStore,
            shopStore: me.subApplication.shopStore
        });
        me.callParent(arguments);
    }
});
//{/block}