//{block name="backend/payiteasycw_base/controller/main"}
Ext.define('Shopware.apps.PayiteasycwBase.controller.Main', {
    extend: 'Ext.app.Controller',

    init: function() {
        var me = this;
        if (me.subApplication.action && me.subApplication.action.toLowerCase() === 'transaction') {
        	if (me.subApplication.params && me.subApplication.params.transactionId) {
        		var store = me.subApplication.getStore('Transaction');
                
                me.mainWindow = me.subApplication.getView('transaction.Window').create().show();
                me.mainWindow.setLoading(true);
                
                store.load({
                	params: {
                		transactionId: me.subApplication.params.transactionId
                	},
                    callback:function (records) {
                        var transaction = records[0];
                        me.mainWindow.record = transaction;
                        me.mainWindow.createPanel();
                        me.mainWindow.setLoading(false);
                        me.subApplication.setAppWindow(me.mainWindow);
                    }
                });
        	}
        }
        me.callParent(arguments);
    }
});
//{/block}