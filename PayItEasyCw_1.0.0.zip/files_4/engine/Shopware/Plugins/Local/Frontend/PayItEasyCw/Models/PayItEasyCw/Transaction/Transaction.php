<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

namespace Shopware\CustomModels\PayItEasyCw\Transaction;

use Symfony\Component\Validator\Constraints as Assert, Doctrine\Common\Collections\ArrayCollection, Shopware\Components\Model\ModelEntity, Doctrine\ORM\Mapping AS ORM;

/**
 * This class represents a transaction
 *
 * @author Simon Schurter
 *
 * @ORM\Entity(repositoryClass="Repository")
 * @ORM\Table(name="payiteasycw_transaction")
 */
class Transaction extends ModelEntity
{
	/**
	 * @var integer $transactionId
	 *
	 * @ORM\Column(name="transactionId", type="integer", nullable=false)
	 * @ORM\Id
	 */
	private $transactionId;

	/**
	 * @var string $shopId
	 *
	 * @ORM\Column(name="transactionExternalId", type="string", nullable=true)
	 */
	private $transactionExternalId;

	/**
	 * @var integer $orderId
	 *
	 * @ORM\Column(name="orderId", type="integer", nullable=true)
	 */
	private $orderId;

	/**
	 * @var integer $temporaryOrderId
	 *
	 * @ORM\Column(name="temporaryOrderId", type="integer", nullable=true)
	 */
	private $temporaryOrderId;
	
	/**
	 * @var string $aliasForDisplay
	 *
	 * @ORM\Column(name="aliasForDisplay", type="string", nullable=true)
	 */
	private $aliasForDisplay;
	
	/**
	 * @var string $aliasActive
	 *
	 * @ORM\Column(name="aliasActive", type="string", nullable=true)
	 */
	private $aliasActive;
	
	/**
	 * @var string $paymentMachineName
	 *
	 * @ORM\Column(name="paymentMachineName", type="string", nullable=true)
	 */
	private $paymentMachineName;
	
	/**
	 * @var string $paymentMethod
	 *
	 * @ORM\Column(name="paymentMethod", type="string", nullable=true)
	 */
	private $paymentMethod;
	
	/**
	 * @var string $paymentId
	 *
	 * @ORM\Column(name="paymentId", type="string", nullable=true)
	 */
	private $paymentId;
	
	/**
	 * @var string $transactionObject
	 *
	 * @ORM\Column(name="transactionObject", type="string", nullable=true)
	 */
	private $transactionObject;
	
	/**
	 * @var string $authorizationType
	 *
	 * @ORM\Column(name="authorizationType", type="string", nullable=true)
	 */
	private $authorizationType;
	
	/**
	 * @var string $customerId
	 *
	 * @ORM\Column(name="customerId", type="string", nullable=true)
	 */
	private $customerId;
	
	/**
	 * @var \DateTime $createdOn
	 *
	 * @ORM\Column(name="createdOn", type="datetime", nullable=true)
	 */
	private $createdOn;
	
	/**
	 * @var \DateTime $updatedOn
	 *
	 * @ORM\Column(name="updatedOn", type="datetime", nullable=true)
	 */
	private $updatedOn;
	
	/**
	 * @var string $updatable
	 *
	 * @ORM\Column(name="updatable", type="string", nullable=true)
	 */
	private $updatable;
	
	/**
	 * @var \DateTime $executeUpdateOn
	 *
	 * @ORM\Column(name="executeUpdateOn", type="datetime", nullable=true)
	 */
	private $executeUpdateOn;
	
	/**
	 * @var float $authorizationAmount
	 *
	 * @ORM\Column(name="authorizationAmount", type="float", nullable=true)
	 */
	private $authorizationAmount;
	
	/**
	 * @var string $authorizationStatus
	 *
	 * @ORM\Column(name="authorizationStatus", type="string", nullable=true)
	 */
	private $authorizationStatus;
	
	/**
	 * @var string $paid
	 *
	 * @ORM\Column(name="paid", type="string", nullable=true)
	 */
	private $paid;
	
	/**
	 * @var string $currency
	 *
	 * @ORM\Column(name="currency", type="string", nullable=true)
	 */
	private $currency;
	
	/**
	 * @var string $sessionData
	 *
	 * @ORM\Column(name="sessionData", type="string", nullable=true)
	 */
	private $sessionData;
	
	/**
	 * @var string $emailData
	 *
	 * @ORM\Column(name="emailData", type="string", nullable=true)
	 */
	private $emailData;
	
	/**
	 * @var string $lastSetOrderStatusSettingKey
	 *
	 * @ORM\Column(name="lastSetOrderStatusSettingKey", type="string", nullable=true)
	 */
	private $lastSetOrderStatusSettingKey;
	
	/**
	 * @var \Shopware\Models\Customer\Customer
	 * @ORM\ManyToOne(targetEntity="\Shopware\Models\Customer\Customer")
	 * @ORM\JoinColumn(name="customerId", referencedColumnName="id")
	 */
	protected $customer;
	
	/**
	 * @var \Shopware\Models\Shop\Shop
	 * @ORM\OneToOne(targetEntity="\Shopware\Models\Shop\Shop")
	 * @ORM\JoinColumn(name="shopId", referencedColumnName="id")
	 */
	protected $shop;
	
	/**
	 * @var \Shopware\Models\Payment\Payment
	 * @ORM\OneToOne(targetEntity="\Shopware\Models\Payment\Payment")
	 * @ORM\JoinColumn(name="paymentMethod", referencedColumnName="id")
	 */
	protected $payment;
	
	/**
	 * Get id
	 *
	 * @return integer
	 */
	public function getId()
	{
		return $this->transactionId;
	}

	/**
	 * @return number
	 */
	public function getTransactionId()
	{
		return $this->transactionId;
	}

	/**
	 * @return number
	 */
	public function getTransactionExternalId()
	{
		return $this->transactionExternalId;
	}

	/**
	 * @return number
	 */
	public function getOrderId()
	{
		return $this->orderId;
	}

	/**
	 * @return number
	 */
	public function getTemporaryOrderId()
	{
		return $this->temporaryOrderId;
	}

	/**
	 * @return string
	 */
	public function getAliasForDisplay()
	{
		return $this->aliasForDisplay;
	}

	/**
	 * @return string
	 */
	public function getAliasActive()
	{
		return $this->aliasActive;
	}

	/**
	 * @return string
	 */
	public function getPaymentMachineName()
	{
		return $this->paymentMachineName;
	}

	/**
	 * @return string
	 */
	public function getPaymentMethod()
	{
		return $this->paymentMethod;
	}

	/**
	 * @return string
	 */
	public function getPaymentId()
	{
		return $this->paymentId;
	}

	/**
	 * @return string
	 */
	public function getTransactionObject()
	{
		return $this->transactionObject;
	}

	/**
	 * @return string
	 */
	public function getAuthorizationType()
	{
		return $this->authorizationType;
	}

	/**
	 * @return string
	 */
	public function getCustomerId()
	{
		return $this->customerId;
	}

	/**
	 * @return DateTime
	 */
	public function getCreatedOn()
	{
		return $this->createdOn;
	}

	/**
	 * @return DateTime
	 */
	public function getUpdatedOn()
	{
		return $this->updatedOn;
	}

	/**
	 * @return string
	 */
	public function getUpdatable()
	{
		return $this->updatable;
	}

	/**
	 * @return DateTime
	 */
	public function getExecuteUpdateOn()
	{
		return $this->executeUpdateOn;
	}

	/**
	 * @return number
	 */
	public function getAuthorizationAmount()
	{
		return $this->authorizationAmount;
	}

	/**
	 * @return string
	 */
	public function getAuthorizationStatus()
	{
		return $this->authorizationStatus;
	}

	/**
	 * @return string
	 */
	public function getPaid()
	{
		return $this->paid;
	}

	/**
	 * @return string
	 */
	public function getCurrency()
	{
		return $this->currency;
	}

	/**
	 * @return string
	 */
	public function getSessionData()
	{
		return $this->sessionData;
	}
	
	/**
	 * @return string
	 */
	public function getEmailData()
	{
		return $this->emailData;
	}

	/**
	 * @return string
	 */
	public function getLastSetOrderStatusSettingKey()
	{
		return $this->lastSetOrderStatusSettingKey;
	}

	/**
	 * @return \Shopware\Models\Customer\Customer
	 */
	public function getCustomer()
	{
		return $this->customer;
	}

	/**
	 * @return \Shopware\Models\Shop\Shop
	 */
	public function getShop()
	{
		return $this->shop;
	}

	/**
	 * @return \Shopware\Models\Payment\Payment
	 */
	public function getPayment()
	{
		return $this->payment;
	}
}
