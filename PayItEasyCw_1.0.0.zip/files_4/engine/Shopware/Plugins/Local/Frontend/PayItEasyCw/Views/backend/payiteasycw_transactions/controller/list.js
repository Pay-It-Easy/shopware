//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/controller/list"}
Ext.define('Shopware.apps.PayiteasycwTransactions.controller.List', {
    extend: 'Ext.app.Controller',

    refs:[
       { ref: 'transactionListGrid', selector: 'payiteasycw-transactions-list-main-window payiteasycw-transactions-list' },
    ],

    init: function () {
        var me = this;

        me.control({
            'payiteasycw-transactions-list-main-window payiteasycw-transactions-list': {
            	showDetail: me.onShowDetail,
                openOrder: me.onOpenOrder
            }
        });

        me.callParent(arguments);
    },
    
    onShowDetail: function(record) {
    	Shopware.app.Application.addSubApplication({
            name: 'Shopware.apps.PayiteasycwBase',
            action: 'transaction',
            localizedName: '{s name=payiteasycw/f4d5b76a2418eba4baeabc1ed9142b54}Transaction{/s}',
            params: {
                transactionId: record.get('transactionId')
            }
        });
    },

    onOpenOrder: function(record) {
        Shopware.app.Application.addSubApplication({
            name: 'Shopware.apps.Order',
            params: {
                orderId: record.get('orderId')
            }
        });
    }
});
//{/block}