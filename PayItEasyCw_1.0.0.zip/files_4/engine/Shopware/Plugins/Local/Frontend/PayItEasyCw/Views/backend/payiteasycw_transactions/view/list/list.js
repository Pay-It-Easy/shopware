//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/view/list/list"}
Ext.define('Shopware.apps.PayiteasycwTransactions.view.list.List', {
    extend:'Ext.grid.Panel',

    alias: 'widget.payiteasycw-transactions-list',

    region: 'center',
    autoScroll: true,

    initComponent:function () {
        var me = this;

        me.store = me.transactionStore;
        me.columns = me.getColumns();
        me.toolbar = me.getToolbar();
        me.pagingbar = me.getPagingBar();
        me.dockedItems = [ me.toolbar, me.pagingbar ];
        me.callParent(arguments);
    },

    registerEvents: function() {
        this.addEvents(
            'showDetail',
            'openOrder',
            'searchTransactions'
        );
    },

    getPagingBar:function () {
        var me = this;

        var pageSize = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel: '{s name=payiteasycw/98fe5522a7dcbfcab926b510651f59d5}Number of Transactions{/s}',
            labelWidth: 120,
            cls: Ext.baseCSSPrefix + 'page-size',
            queryMode: 'local',
            width: 180,
            listeners: {
                scope: me,
                select: me.onPageSizeChange
            },
            store: Ext.create('Ext.data.Store', {
                fields: [ 'value' ],
                data: [
                    { value: '20' },
                    { value: '40' },
                    { value: '60' },
                    { value: '80' },
                    { value: '100' }
                ]
            }),
            displayField: 'value',
            valueField: 'value'
        });
        pageSize.setValue(me.transactionStore.pageSize);

        var pagingBar = Ext.create('Ext.toolbar.Paging', {
            store: me.transactionStore,
            dock:'bottom',
            displayInfo:true
        });

        pagingBar.insert(pagingBar.items.length - 2, [ { xtype: 'tbspacer', width: 6 }, pageSize ]);

        return pagingBar;

    },

    onPageSizeChange: function(combo, records) {
        var record = records[0],
            me = this;

        me.transactionStore.pageSize = record.get('value');
        me.transactionStore.loadPage(1);
    },

    getColumns:function () {
        var me = this;

        var columns = [
            {
                header: '{s name=payiteasycw/5fc732311905cb27e82d67f4f6511f7f}Date{/s}',
                dataIndex: 'createdOn',
                flex: 1,
                renderer: me.dateColumn
            },
            {
                header: '{s name=payiteasycw/f847de525f37118f39327768ffb8714c}Transaction Id{/s}',
                dataIndex: 'transactionId',
                flex: 1
            },
            {
                header: '{s name=payiteasycw/69dfcb072307d1f23d6dae1ab92fffbf}Order Id{/s}',
                dataIndex: 'orderId',
                flex: 1,
                renderer: me.orderColumn
            },
            {
                header: '{s name=payiteasycw/e9f40e1f1d1658681dad2dac4ae0971e}Amount{/s}',
                dataIndex: 'authorizationAmount',
                flex: 1,
                renderer: me.amountColumn
            },
            {
                header: '{s name=payiteasycw/6ba408e34a2570d54dcc2b1c81a9a136}Payment Method{/s}',
                dataIndex: 'paymentMethod',
                flex: 2,
                renderer: me.paymentColumn
            },
            {
                header: '{s name=payiteasycw/fb54f3c5992b96d001bb16e8e92d968d}Shop{/s}',
                dataIndex: 'shopId',
                flex: 2,
                renderer: me.shopColumn
            },
            {
                header: '{s name=payiteasycw/9acb44549b41563697bb490144ec6258}Status{/s}',
                dataIndex: 'authorizationStatus',
                flex: 1,
                renderer: me.statusColumn
            },
            me.createActionColumn()
        ];

        return columns;
    },

    createActionColumn: function() {
        var me = this;

        return Ext.create('Ext.grid.column.Action', {
            width: 52,
            align: 'right',
            items:[
                me.createOpenOrderColumn(),
                me.createEditTransactionColumn()
            ]
        });
    },

    createEditTransactionColumn: function () {
        var me = this;

        return {
            iconCls: 'sprite-pencil',
            action: 'editTransaction',
            tooltip: '{s name=payiteasycw/18bfcf9eb3ac08540b473288c1237800}View Transaction{/s}',
            handler: function (view, rowIndex, colIndex, item) {
                var store = view.getStore(),
                        record = store.getAt(rowIndex);

                me.fireEvent('showDetail', record);
            }
        }
    },

    createOpenOrderColumn: function() {
        var me = this;
        return {
            iconCls: 'sprite-sticky-notes-pin',
            action: 'openOrder',
            tooltip: '{s name=payiteasycw/e83b9e3a8e85cdf4445c76f9042aa020}View Order{/s}',
            handler: function (view, rowIndex, colIndex, item) {
                var store = view.getStore(),
                record = store.getAt(rowIndex);

               me.fireEvent('openOrder', record);
            },
            getClass: function(value, metadata, record) {
                if (!record.get('orderId')) {
                    return Ext.baseCSSPrefix + 'hidden';
                }
            }
        };
    },

    getToolbar:function () {
        var me = this;

        return Ext.create('Ext.toolbar.Toolbar', {
            dock: 'top',
            ui: 'shopware-ui',
            items:[
                '->',
                {
                    xtype: 'textfield',
                    name: 'searchfield',
                    cls: 'searchfield',
                    width: 175,
                    emptyText: '{s name=payiteasycw/06a943c59f33a34bb5924aaf72cd2995}Search{/s}',
                    enableKeyEvents: true,
                    checkChangeBuffer: 500,
                    listeners: {
                        change: function(field, value) {
                            me.fireEvent('searchTransactions', value);
                        }
                    }
                },
                { xtype: 'tbspacer', width: 6 }
            ]
        });
    },

    /**
     * Formats the date column
     *
     * @param [string] - The date value
     * @return [string] - The passed value, formatted with Ext.util.Format.date()
     */
    dateColumn:function (value, metaData, record) {
        if ( value === Ext.undefined ) {
            return value;
        }

        return Ext.util.Format.date(value) + ' ' + Ext.util.Format.date(value, 'H:i');
    },
    
    /**
     * Formats the order id column
     *
     * @param [string] - The order id value
     * @return [string] - The passed value, formatted with Ext.util.Format.date()
     */
    orderColumn: function (value, metaData, record) {
        if (value === 0) {
            return '';
        }
        return value;
    },

    /**
     * Formats the amount column
     * @param [string] - The amount value
     * @return [string] - The passed value, formatted with Ext.util.Format.currency()
     */
    amountColumn:function (value, metaData, record) {
        if ( value === Ext.undefined ) {
            return value;
        }
        return Ext.util.Format.currency(value);
    },

    /**
     * Column renderer function for the payment column of the list grid.
     * @param [string] value    - The field value
     * @param [string] metaData - The model meta data
     * @param [string] record   - The whole data model
     */
    paymentColumn: function(value, metaData, record) {
        var payment = null;

        if (record instanceof Ext.data.Model && record.getPayment() instanceof Ext.data.Store && record.getPayment().first() instanceof Ext.data.Model) {
            payment = record.getPayment().first();
        }

        if (payment instanceof Ext.data.Model) {
            return payment.get('description');
        } else {
            return value;
        }
    },

    /**
     * Column renderer function for the shop column of the list grid.
     * @param [string] value    - The field value
     * @param [string] metaData - The model meta data
     * @param [string] record   - The whole data model
     */
    shopColumn: function(value, metaData, record) {
        var shop = record.getShop().first();

        if (shop instanceof Ext.data.Model) {
            return shop.get('name');
        } else {
            return value;
        }
    },
    
    /**
     * Formats the authorization status column
     *
     * @param [string] - The authorization status value
     * @return [string] - The formatted value
     */
    statusColumn: function(value, metaData, record) {
    	switch (value) {
    		case 'pending':
    			return '{s name=payiteasycw/7c6c2e5d48ab37a007cbf70d3ea25fa4}Pending{/s}';
    		case 'successful':
    			return '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}';
    		case 'failed':
    			return '{s name=payiteasycw/26934eb377001f66e37289a5c93fe284}Failed{/s}';
    		default:
    			return value;
    	}
     }
});
//{/block}

