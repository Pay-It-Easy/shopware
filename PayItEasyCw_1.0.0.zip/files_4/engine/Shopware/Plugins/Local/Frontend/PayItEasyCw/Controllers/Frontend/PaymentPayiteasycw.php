<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Frontend_PaymentPayiteasycw extends Enlight_Controller_Action
{
	public function indexAction()
	{
		$orderHelper = new PayItEasyCw_Components_Order();
		$orderHelper->saveCheckoutForm($this->Request());

		$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
		$wrapper = new PayItEasyCw_Components_PaymentMethodWrapper($order->getPayment());

		$orderContext = $wrapper->getOrderContext($order->getId());
		$paymentCustomerContext = PayItEasyCw_Helpers_Util::loadPaymentCustomerContextByCustomer($order->getCustomer()->getId());

		$aliasTransactionObject = null;
		if($orderContext->getPaymentMethod()->getPaymentMethodConfigurationValue('alias_manager') == 'active') {
			$aliasTransactionObject = 'new';
		}

		$this->View()->loadTemplate('frontend/checkout/payiteasycw/Payment.tpl');

		$this->View()->assign('alias', $wrapper->generateAliasSelect($orderContext));
		$this->View()->assign('visibleFieldsUrl', PayItEasyCw_Helpers_Util::getUrl(array('controller' => 'PayItEasyCwCheckout', 'action' => 'getAliasData', 'forceSecure' => true)));
		$this->View()->assign('orderUrl', PayItEasyCw_Helpers_Util::getUrl(array('controller' => 'PayItEasyCwCheckout', 'action' => 'saveForm', 'forceSecure' => true)));
		$this->View()->assign('paymentMethodId', $wrapper->getPaymentMethod()->getId());
		$this->View()->assign('visibleFormFields', $wrapper->generateVisibleFormFields($orderContext, $paymentCustomerContext, $aliasTransactionObject));
		$this->View()->assign('formHeading', Customweb_I18n_Translation::__('Payment Form'));
		$this->View()->assign('confirmPaymentLabel', Customweb_I18n_Translation::__('Confirm Payment'));
		$this->View()->assign('processingLabel', Customweb_I18n_Translation::__('Processing'));
		$this->View()->assign('javascriptRequiredMessage', Customweb_I18n_Translation::__('Javascript is required to checkout.'));
		$this->View()->assign('authorizationMethod', $wrapper->getAuthorizationMethodName($orderContext));
	}

	
}