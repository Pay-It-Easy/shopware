/**
 * This model represents a order transaction.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/model/transaction"}
Ext.define('Shopware.apps.PayiteasycwBase.model.Transaction', {
    extend: 'Ext.data.Model',
 
    fields: [
        //{block name="backend/payiteasycw_base/model/transaction/fields"}{/block}
        { name: 'transactionId', type: 'int' },
        { name: 'paymentMethod', type: 'string' },
        { name: 'createdOn', type: 'date' },
        { name: 'updatedOn', type: 'date' },
        { name: 'authorizationType', type: 'string' },
        { name: 'authorizationAmount', type: 'string' },
        { name: 'authorizationStatus', type: 'string' },
        { name: 'isAuthorized', type: 'boolean' },
        { name: 'labels', type: 'object' },
        
        { name: 'decimalPlaces', type: 'int' },
        { name: 'currencyCode', type: 'string' },
        
        { name: 'capturePossible', type: 'boolean' },
        { name: 'partialCapturePossible', type: 'boolean' },
        { name: 'captureClosable', type: 'boolean' },
        { name: 'capturableAmount', type: 'string' },
        { name: 'capturableItems', type: 'object' },
        
        { name: 'refundPossible', type: 'boolean' },
        { name: 'partialRefundPossible', type: 'boolean' },
        { name: 'refundClosable', type: 'boolean' },
        { name: 'refundableAmount', type: 'string' },
        { name: 'refundableItems', type: 'object' },
        
        { name: 'cancelPossible', type: 'boolean' },
        
        { name: 'updatable', type: 'boolean' },
    ],
    
    associations:[
          { type: 'hasMany', model: 'Shopware.apps.PayiteasycwBase.model.TransactionHistory', name: 'getHistory', associationKey: 'history' },
          { type: 'hasMany', model: 'Shopware.apps.PayiteasycwBase.model.TransactionCapture', name: 'getCaptures', associationKey: 'captures' },
          { type: 'hasMany', model: 'Shopware.apps.PayiteasycwBase.model.TransactionRefund', name: 'getRefunds', associationKey: 'refunds' },
    ],
 
    /**
     * Configure the data communication
     * 
     * @object
     */
    proxy: {
        type: 'ajax',
 
        /**
         * Configure the url mapping for the different store operations
         * 
         * @object
         */
        api: {
            read: '{url controller="PayiteasycwBaseTransaction" action="getTransactions"}'
        },
 
        reader: {
            type:			'json',
            root:			'data',
            totalProperty:	'total'
        }
    }
});
//{/block}