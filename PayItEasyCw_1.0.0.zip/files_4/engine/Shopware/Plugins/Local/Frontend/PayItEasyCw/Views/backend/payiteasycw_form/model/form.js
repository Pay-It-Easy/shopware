//{block name="backend/payiteasycw_form/model/form"}
Ext.define('Shopware.apps.PayiteasycwForm.model.Form', {
    extend : 'Ext.data.Model',

    alias : 'model.form',

    fields : [
        { name : 'id',       		type: 'int' },
        { name : 'text',       		type: 'string' },
        { name : 'formUrl',   		type: 'string' },
        { name : 'iconCls',  		type: 'string' }
    ],

    proxy : {
        type : 'ajax',
        api : {
            read : '{url controller="PayiteasycwForm" action=getForms}',
            update : '{url controller="PayiteasycwForm" action=saveForm}',
        },
        reader : {
            type : 'json',
            root: 'data'
        }
    }
});
//{/block}