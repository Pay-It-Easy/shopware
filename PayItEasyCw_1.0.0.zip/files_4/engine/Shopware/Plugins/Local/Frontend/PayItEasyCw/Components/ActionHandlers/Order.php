<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class extends actions called on the order controller.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_ActionHandlers_Order extends PayItEasyCw_Components_ActionHandlers_Abstract
{
	/**
	 * Extends template to load custom javascript files.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function indexAction(Enlight_Event_EventArgs $args)
	{
		$args->getSubject()
			->View()
			->extendsTemplate('backend/order/payiteasycw/app.js');
	}

	/**
	 * Loads further javascript files.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function loadAction(Enlight_Event_EventArgs $args)
	{
		$args->getSubject()
			->View()
			->extendsTemplate('backend/order/payiteasycw/view/window.js');
		$args->getSubject()
			->View()
			->assign(array(
				'payiteasycw_plugin_id' => $this->_pluginId
			));

		$args->getSubject()
			->View()
			->extendsTemplate('backend/order/payiteasycw/model/order.js');
	}

	/**
	 * Add some attributes to the order records.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function getListAction(Enlight_Event_EventArgs $args)
	{
		$result = $args->getSubject()
			->View()
			->getAssign();

		if ($result['success'] == false) {
			return;
		}

		$data = $result['data'];
		foreach ($data as $key => $order) {
			$payment = Shopware()->Models()
				->getRepository('Shopware\Models\Payment\Payment')
				->find($order['paymentId']);

			if ($payment instanceof Shopware\Models\Payment\Payment) {
				$data[$key]['payiteasycw'] = ($payment->getPluginId() == $this->_pluginId);
				$data[$key]['pluginId'] = $payment->getPluginId();
			}
		}

		$args->getSubject()
			->View()
			->clearAssign();
		$args->getSubject()
			->View()
			->assign(array(
				'success' => true,
				'data' => $data,
				'total' => $result['total']
			));
	}
}
