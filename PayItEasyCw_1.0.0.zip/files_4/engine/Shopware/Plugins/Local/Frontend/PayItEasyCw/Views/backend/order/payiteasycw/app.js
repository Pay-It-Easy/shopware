/**
 * Load required files.
 * 
 * @author Simon Schurter
 */
//{block name="backend/order/application" append}
	//{include file="backend/payiteasycw_base/controller/transaction.js"}
	//{include file="backend/payiteasycw_base/view/transaction/transaction.js"}
	//{include file="backend/payiteasycw_base/view/transaction/captures.js"}
	//{include file="backend/payiteasycw_base/view/transaction/captures/detail.js"}
	//{include file="backend/payiteasycw_base/view/transaction/captures/form.js"}
	//{include file="backend/payiteasycw_base/view/transaction/captures/grid.js"}
	//{include file="backend/payiteasycw_base/view/transaction/history.js"}
	//{include file="backend/payiteasycw_base/view/transaction/overview.js"}
	//{include file="backend/payiteasycw_base/view/transaction/refunds.js"}
	//{include file="backend/payiteasycw_base/view/transaction/refunds/detail.js"}
	//{include file="backend/payiteasycw_base/view/transaction/refunds/form.js"}
	//{include file="backend/payiteasycw_base/view/transaction/refunds/grid.js"}
    //{include file="backend/payiteasycw_base/model/transaction.js"}
	//{include file="backend/payiteasycw_base/model/transaction_history.js"}
	//{include file="backend/payiteasycw_base/model/transaction_capture.js"}
	//{include file="backend/payiteasycw_base/model/transaction_refund.js"}
	//{include file="backend/payiteasycw_base/store/transaction.js"}

	Ext.define('Shopware.apps.Order.Payiteasycw', {
		override: 'Shopware.apps.Order',
		
		launch: function() {
			var me = this;
			
			me.getController('Shopware.apps.PayiteasycwBase.controller.Transaction');
			return me.callParent(arguments);
		}
	});
//{/block}