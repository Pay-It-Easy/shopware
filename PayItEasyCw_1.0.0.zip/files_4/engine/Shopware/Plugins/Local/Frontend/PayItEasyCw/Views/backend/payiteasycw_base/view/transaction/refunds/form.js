/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/refunds/form"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.refunds.Form', {
    extend: 'Ext.form.Panel',
    
    alias:'widget.payiteasycw-base-transaction-refunds-form',
    
    style: {
		background: 'transparent'
	},
	bodyStyle: {
		background: 'transparent'
	},
	border: 0,
	autoScroll: true,
	layout: {
		type: 'table',
		columns: 7,
		tableAttrs: {
	        style: {
	            width: '100%'
	        }
	    }
	},
    
    initComponent: function() {
        var me = this;
        me.registerEvents();
        me.items = me.createFields();
        me.dockedItems = me.createToolbar();
        me.callParent(arguments);
    },
    
    registerEvents: function() {
        this.addEvents(
            'refundTransaction',
            'updateFields'
        );
    },
    
    createFields: function() {
    	var me = this;
    	
    	var fields = [];
          
        if (me.record.get('partialRefundPossible')) {
        	fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/b068931cc450442b63f5b3d276ea4297}Name{/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
    		fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/f8c461fd1f0a234e5df4bb9d6fecc69a}SKU{/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
    		fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/599dcce2998a6b40b1e38e8c6006cb0a}Type{/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
    		fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/1ba8a02e3f08527607256b38ea8d70a4}Tax Rate{/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
    		fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/221d2a4bfdae13dbd5aeff3b02adb8c1}Quantity{/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
    		fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/caa50ad854e063f84182fcd95eda6bbe}Total Amount (excl. Tax){/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
    		fields.push({
    			xtype: 'label',
    			text: '{s name=payiteasycw/1364dd7226a456f9781ef5eebd5782c5}Total Amount (incl. Tax){/s}',
    			cls: 'x-form-item-label',
    			padding: '0 5px 0 0',
    		});
        	
        	var items = me.record.get('refundableItems');
        	for (var i = 0; i < items.length; i++) {
        		if (items[i].type == 'discount') {
        			items[i].amountExclTax = -1 * items[i].amountExclTax;
        			items[i].amountInclTax = -1 * items[i].amountInclTax;
        		}
        		
        		fields.push({
        			layout: 'form',
        			border: 0,
        			padding: '0 5px 0 0',
            		items: {
	        			xtype: 'displayfield',
	        			value: items[i].name,
	        			hideLabel: true
            		}
        		});
        		fields.push({
        			layout: 'form',
        			border: 0,
        			padding: '0 5px 0 0',
            		items: {
	        			xtype: 'displayfield',
	        			value: items[i].sku,
	        			hideLabel: true
            		}
        		});
        		fields.push({
        			layout: 'form',
        			border: 0,
        			padding: '0 5px 0 0',
            		items: {
	        			xtype: 'displayfield',
	        			value: items[i].type,
	        			hideLabel: true
            		}
        		});
        		fields.push({
        			layout: 'form',
        			border: 0,
        			padding: '0 5px 0 0',
        			itemId: 'form-taxRate-' + i,
            		items: {
	        			xtype: 'displayfield',
	        			value: items[i].taxRate + ' %',
	        			hideLabel: true,
	        			fieldStyle: 'text-align: right;',
	        			valueOriginal: items[i].taxRate,
	        			row: i
            		}
        		});
        		fields.push({
        			layout: 'form',
        			border: 0,
        			padding: '0 5px 0 0',
        			itemId: 'form-qty-' + i,
            		items: {
	        			xtype: 'textfield',
	        			value: items[i].qty,
	        			hideLabel: true,
	        			fieldStyle: 'text-align: right;',
	        			listeners: {
	        				blur: {
	        					fn: function(element){
	        						me.fireEvent('updateFields', element, me.record, me);
	        					}
	        				}
	        			},
	        			valueBeforeChange: items[i].qty,
	        			valueOriginal: items[i].qty,
	        			row: i,
	        			totalRows: items.length,
	        			name: 'quantity[' + i + ']'
            		}
        		});
        		fields.push({
        			layout: 'form',
        			border: 0,
        			padding: '0 5px 0 0',
        			itemId: 'form-amountExclTax-' + i,
            		items: {
	        			xtype: 'textfield',
	        			value: items[i].amountExclTax,
	        			hideLabel: true,
	        			fieldStyle: 'text-align: right;',
	        			listeners: {
	        				blur: {
	        					fn: function(element){
	        						me.fireEvent('updateFields', element, me.record, me);
	        					}
	        				}
	        			},
	        			valueBeforeChange: items[i].amountExclTax,
	        			valueOriginal: items[i].amountExclTax,
	        			row: i,
	        			totalRows: items.length,
	        			name: 'amountExclTax[' + i + ']'
            		}
        		});
        		fields.push({
        			layout: 'form',
        			border: 0,
        			itemId: 'form-amountInclTax-' + i,
            		items: {
	        			xtype: 'textfield',
	        			value: items[i].amountInclTax,
	        			hideLabel: true,
	        			fieldStyle: 'text-align: right;',
	        			listeners: {
	        				blur: {
	        					fn: function(element){
	        						me.fireEvent('updateFields', element, me.record, me);
	        					}
	        				}
	        			},
	        			valueBeforeChange: items[i].amountInclTax,
	        			valueOriginal: items[i].amountInclTax,
	        			row: i,
	        			totalRows: items.length,
	        			name: 'amountInclTax[' + i + ']'
            		}
        		});
        	}
	        
	        fields.push({
				xtype: 'label',
				text: '{s name=payiteasycw/ba7cf61483e4ddfce4ceb20b0b414f5d}Total Refund Amount{/s}',
				cls: 'x-form-item-label',
				style: 'text-align: right;',
				width: '100%',
				colspan: 6
	    	});
	        fields.push({
	        	layout: 'form',
	        	border: 0,
	        	padding: '0 8px 0 0',
	        	itemId: 'form-totalAmount',
	    		items: {
		        	xtype: 'displayfield',
		        	value: me.record.get('refundableAmount'),
		        	hideLabel: true,
		        	fieldStyle: 'text-align: right;',
		        	width: '100%',
	    		}
	        });
        }
        
        fields.push({
        	xtype: 'hiddenfield',
        	name: 'transactionId',
        	value: me.record.get('transactionId'),
        });
    	
    	return fields;
    },
    
    createToolbar: function() {
    	var me = this;
    	
    	var toolbar = [{
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            border: 0,
            defaults: {
            	xtype: 'button'
            },
            items: me.createButtons()
        }];
    	
    	return toolbar;
    },
    
    createButtons: function() {
    	var me = this;
    	
    	var buttons = [];
    	
    	if (me.record.get('refundClosable') && me.record.get('partialRefundPossible')) {
    		buttons.push({
            	xtype: 'checkboxfield',
            	name: 'close',
            	value: 1,
            	boxLabel: '{s name=payiteasycw/70f9513b42e39e704740020f8703a78e}Close transaction for further refunds.{/s}',
            	hideLabel: true,
            	fieldStyle: 'float: left;'
            });
        } else {
        	buttons.push({
            	xtype: 'displayfield',
            	name: 'close',
            	value: '{s name=payiteasycw/b2eca51fef9b224bbf2ed72e33ee8296}The refund will automatically close the transaction for further refunds.{/s}',
            	hideLabel: true
            });
        }
    	
    	buttons.push({ xtype: 'component', flex: 1 });
    	
    	buttons.push({
            text: '{s name=payiteasycw/df6f85687a0d5820baa1a069a04eff2d}Refund{/s}',
            action: 'refund-transaction',
            cls: 'primary',
            handler: function() {
                var form = this.up('form').getForm();
                var values = form.getValues();
                if (form.isValid()) {
                   	me.disable();
                   	me.fireEvent('refundTransaction', values, me.record, me);
                }
            }
        });
    	
    	return buttons;
    },
        
});
//{/block}