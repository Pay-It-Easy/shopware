<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * Payment configuration helper
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Helpers_Payment_Config extends Enlight_Class
{

	private static $elementCache = array();

	/**
	 * Return the configuration form fields of a payment method.
	 *
	 * @param integer $paymentId
	 * @return array
	 */
	public static function getConfigForm($paymentId)
	{
		$payment = Shopware()->Models()->getRepository(
            'Shopware\Models\Payment\Payment'
        )->find($paymentId);

		
		if ($payment->getName() === 'payiteasycw_creditcard') {
			$result = array(
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Capturing')->toString(),
 					'description' => 'Should the amount be captured automatically after the
						order (direct) or should the amount only be reserved (deferred)?
					',
 					'name' => 'capturing',
 					'xtype' => 'combobox',
 					'value' => 'direct',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'direct', 'text' => Customweb_I18n_Translation::__('Directly after order')->toString()),
 						1 => array('value' => 'deferred', 'text' => Customweb_I18n_Translation::__('Deferred')->toString()),
 					),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Iframe Height')->toString(),
 					'description' => 'Define the height of the iframe element (only has an effect if iframe authorization is selected).
					',
 					'name' => 'iframe_height',
 					'xtype' => 'textfield',
 					'value' => '650',
 					'required' => 0,
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorized Status')->toString(),
 					'description' => 'This status is set, when the payment was successfull
						and it is authorized.
					',
 					'name' => 'status_authorized',
 					'xtype' => 'combobox',
 					'value' => '32',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Uncertain Status')->toString(),
 					'description' => 'You can specify the order status for new orders that
						have an uncertain authorisation status.
					',
 					'name' => 'status_uncertain',
 					'xtype' => 'combobox',
 					'value' => '31',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Cancelled Status')->toString(),
 					'description' => 'You can specify the order status when an order is
						cancelled.
					',
 					'name' => 'status_cancelled',
 					'xtype' => 'combobox',
 					'value' => '35',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Captured Status')->toString(),
 					'description' => 'You can specify the order status for orders that are
						captured either directly after the order or manually in the
						backend.
					',
 					'name' => 'status_captured',
 					'xtype' => 'combobox',
 					'value' => 'no_status_change',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorization Method')->toString(),
 					'description' => 'Select the authorization method to use for processing this payment method.',
 					'name' => 'authorizationMethod',
 					'xtype' => 'combobox',
 					'value' => 'PaymentPage',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'PaymentPage', 'text' => Customweb_I18n_Translation::__('Payment Page')->toString()),
 						1 => array('value' => 'IframeAuthorization', 'text' => Customweb_I18n_Translation::__('IFrame Authorization')->toString()),
 					),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Alias Manager')->toString(),
 					'description' => 'The alias manager allows the customer to select from a credit card previously stored. The sensitive data is stored by Pay-It-Easy.',
 					'name' => 'alias_manager',
 					'xtype' => 'combobox',
 					'value' => 'inactive',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'active', 'text' => Customweb_I18n_Translation::__('Active')->toString()),
 						1 => array('value' => 'inactive', 'text' => Customweb_I18n_Translation::__('Inactive')->toString()),
 					),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Minimal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or greater than the specified amount.')->toString(),
 					'name' => 'min_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Maximal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or less than the specified amount.')->toString(),
 					'name' => 'max_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('New Order Status')->toString(),
 					'description' => Customweb_I18n_Translation::__('You can decide on the order status new orders should have that have an uncertain authorization status.')->toString(),
 					'name' => 'order_status',
 					'xtype' => 'combobox',
 					'value' => '0',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getOrderStatusOptions(),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Payment Form Position')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide where the payment form should be displayed.')->toString(),
 					'name' => 'form_position',
 					'xtype' => 'combobox',
 					'value' => 'checkout',
 					'required' => 1,
 					'options' => array(array('value' => 'checkout', 'text' => Customweb_I18n_Translation::__('On checkout page')->toString()), array('value' => 'separate', 'text' => Customweb_I18n_Translation::__('On separate page')->toString())),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Zero Checkout')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide how you want to handle zero checkouts. Either use the default behavior (authorization with PSP) or skip directly to the success page.')->toString(),
 					'name' => 'zero_checkout',
 					'xtype' => 'combobox',
 					'value' => 'default',
 					'required' => 1,
 					'options' => array(array('value' => 'default', 'text' => Customweb_I18n_Translation::__('Default')->toString()), array('value' => 'skip', 'text' => Customweb_I18n_Translation::__('Skip')->toString())),
 				),
			);
		}

		if ($payment->getName() === 'payiteasycw_directdebitssepa') {
			$result = array(
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Capturing')->toString(),
 					'description' => 'Should the amount be captured automatically after the
						order (direct) or should the amount only be reserved (deferred)?
					',
 					'name' => 'capturing',
 					'xtype' => 'combobox',
 					'value' => 'direct',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'direct', 'text' => Customweb_I18n_Translation::__('Directly after order')->toString()),
 						1 => array('value' => 'deferred', 'text' => Customweb_I18n_Translation::__('Deferred')->toString()),
 					),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorized Status')->toString(),
 					'description' => 'This status is set, when the payment was successfull
						and it is authorized.
					',
 					'name' => 'status_authorized',
 					'xtype' => 'combobox',
 					'value' => '32',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Uncertain Status')->toString(),
 					'description' => 'You can specify the order status for new orders that
						have an uncertain authorisation status.
					',
 					'name' => 'status_uncertain',
 					'xtype' => 'combobox',
 					'value' => '31',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Cancelled Status')->toString(),
 					'description' => 'You can specify the order status when an order is
						cancelled.
					',
 					'name' => 'status_cancelled',
 					'xtype' => 'combobox',
 					'value' => '35',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Captured Status')->toString(),
 					'description' => 'You can specify the order status for orders that are
						captured either directly after the order or manually in the
						backend.
					',
 					'name' => 'status_captured',
 					'xtype' => 'combobox',
 					'value' => 'no_status_change',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Iframe Height')->toString(),
 					'description' => 'Define the height of the iframe element (only has an effect if iframe authorization is selected).
					',
 					'name' => 'iframe_height',
 					'xtype' => 'textfield',
 					'value' => '650',
 					'required' => 0,
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorization Method')->toString(),
 					'description' => 'Select the authorization method to use for processing this payment method.',
 					'name' => 'authorizationMethod',
 					'xtype' => 'combobox',
 					'value' => 'PaymentPage',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'PaymentPage', 'text' => Customweb_I18n_Translation::__('Payment Page')->toString()),
 						1 => array('value' => 'IframeAuthorization', 'text' => Customweb_I18n_Translation::__('IFrame Authorization')->toString()),
 					),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Minimal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or greater than the specified amount.')->toString(),
 					'name' => 'min_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Maximal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or less than the specified amount.')->toString(),
 					'name' => 'max_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('New Order Status')->toString(),
 					'description' => Customweb_I18n_Translation::__('You can decide on the order status new orders should have that have an uncertain authorization status.')->toString(),
 					'name' => 'order_status',
 					'xtype' => 'combobox',
 					'value' => '0',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getOrderStatusOptions(),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Payment Form Position')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide where the payment form should be displayed.')->toString(),
 					'name' => 'form_position',
 					'xtype' => 'combobox',
 					'value' => 'checkout',
 					'required' => 1,
 					'options' => array(array('value' => 'checkout', 'text' => Customweb_I18n_Translation::__('On checkout page')->toString()), array('value' => 'separate', 'text' => Customweb_I18n_Translation::__('On separate page')->toString())),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Zero Checkout')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide how you want to handle zero checkouts. Either use the default behavior (authorization with PSP) or skip directly to the success page.')->toString(),
 					'name' => 'zero_checkout',
 					'xtype' => 'combobox',
 					'value' => 'default',
 					'required' => 1,
 					'options' => array(array('value' => 'default', 'text' => Customweb_I18n_Translation::__('Default')->toString()), array('value' => 'skip', 'text' => Customweb_I18n_Translation::__('Skip')->toString())),
 				),
			);
		}

		if ($payment->getName() === 'payiteasycw_giropay') {
			$result = array(
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Capturing')->toString(),
 					'description' => 'Should the amount be captured automatically after the
						order (direct) or should the amount only be reserved (deferred)?
					',
 					'name' => 'capturing',
 					'xtype' => 'combobox',
 					'value' => 'direct',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'direct', 'text' => Customweb_I18n_Translation::__('Directly after order')->toString()),
 						1 => array('value' => 'deferred', 'text' => Customweb_I18n_Translation::__('Deferred')->toString()),
 					),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorized Status')->toString(),
 					'description' => 'This status is set, when the payment was successfull
						and it is authorized.
					',
 					'name' => 'status_authorized',
 					'xtype' => 'combobox',
 					'value' => '32',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Uncertain Status')->toString(),
 					'description' => 'You can specify the order status for new orders that
						have an uncertain authorisation status.
					',
 					'name' => 'status_uncertain',
 					'xtype' => 'combobox',
 					'value' => '31',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Cancelled Status')->toString(),
 					'description' => 'You can specify the order status when an order is
						cancelled.
					',
 					'name' => 'status_cancelled',
 					'xtype' => 'combobox',
 					'value' => '35',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Captured Status')->toString(),
 					'description' => 'You can specify the order status for orders that are
						captured either directly after the order or manually in the
						backend.
					',
 					'name' => 'status_captured',
 					'xtype' => 'combobox',
 					'value' => 'no_status_change',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Iframe Height')->toString(),
 					'description' => 'Define the height of the iframe element (only has an effect if iframe authorization is selected).
					',
 					'name' => 'iframe_height',
 					'xtype' => 'textfield',
 					'value' => '650',
 					'required' => 0,
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorization Method')->toString(),
 					'description' => 'Select the authorization method to use for processing this payment method.',
 					'name' => 'authorizationMethod',
 					'xtype' => 'combobox',
 					'value' => 'PaymentPage',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'PaymentPage', 'text' => Customweb_I18n_Translation::__('Payment Page')->toString()),
 						1 => array('value' => 'IframeAuthorization', 'text' => Customweb_I18n_Translation::__('IFrame Authorization')->toString()),
 					),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Minimal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or greater than the specified amount.')->toString(),
 					'name' => 'min_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Maximal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or less than the specified amount.')->toString(),
 					'name' => 'max_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('New Order Status')->toString(),
 					'description' => Customweb_I18n_Translation::__('You can decide on the order status new orders should have that have an uncertain authorization status.')->toString(),
 					'name' => 'order_status',
 					'xtype' => 'combobox',
 					'value' => '0',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getOrderStatusOptions(),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Payment Form Position')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide where the payment form should be displayed.')->toString(),
 					'name' => 'form_position',
 					'xtype' => 'combobox',
 					'value' => 'checkout',
 					'required' => 1,
 					'options' => array(array('value' => 'checkout', 'text' => Customweb_I18n_Translation::__('On checkout page')->toString()), array('value' => 'separate', 'text' => Customweb_I18n_Translation::__('On separate page')->toString())),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Zero Checkout')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide how you want to handle zero checkouts. Either use the default behavior (authorization with PSP) or skip directly to the success page.')->toString(),
 					'name' => 'zero_checkout',
 					'xtype' => 'combobox',
 					'value' => 'default',
 					'required' => 1,
 					'options' => array(array('value' => 'default', 'text' => Customweb_I18n_Translation::__('Default')->toString()), array('value' => 'skip', 'text' => Customweb_I18n_Translation::__('Skip')->toString())),
 				),
			);
		}

		if ($payment->getName() === 'payiteasycw_paypal') {
			$result = array(
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Capturing')->toString(),
 					'description' => 'Should the amount be captured automatically after the
						order (direct) or should the amount only be reserved (deferred)?
					',
 					'name' => 'capturing',
 					'xtype' => 'combobox',
 					'value' => 'direct',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'direct', 'text' => Customweb_I18n_Translation::__('Directly after order')->toString()),
 						1 => array('value' => 'deferred', 'text' => Customweb_I18n_Translation::__('Deferred')->toString()),
 					),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorized Status')->toString(),
 					'description' => 'This status is set, when the payment was successfull
						and it is authorized.
					',
 					'name' => 'status_authorized',
 					'xtype' => 'combobox',
 					'value' => '32',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Uncertain Status')->toString(),
 					'description' => 'You can specify the order status for new orders that
						have an uncertain authorisation status.
					',
 					'name' => 'status_uncertain',
 					'xtype' => 'combobox',
 					'value' => '31',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Cancelled Status')->toString(),
 					'description' => 'You can specify the order status when an order is
						cancelled.
					',
 					'name' => 'status_cancelled',
 					'xtype' => 'combobox',
 					'value' => '35',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Captured Status')->toString(),
 					'description' => 'You can specify the order status for orders that are
						captured either directly after the order or manually in the
						backend.
					',
 					'name' => 'status_captured',
 					'xtype' => 'combobox',
 					'value' => 'no_status_change',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getPaymentStatusOptions(array(
						0 => array('value' => 'no_status_change', 'text' => Customweb_I18n_Translation::__('Don\'t change order status')->toString()),
 					)),
 				),
				array(
					'validTypes' => array(
					),
 					'title' => Customweb_I18n_Translation::__('Authorization Method')->toString(),
 					'description' => 'Select the authorization method to use for processing this payment method.',
 					'name' => 'authorizationMethod',
 					'xtype' => 'combobox',
 					'value' => 'PaymentPage',
 					'required' => 1,
 					'options' => array(
						0 => array('value' => 'PaymentPage', 'text' => Customweb_I18n_Translation::__('Payment Page')->toString()),
 					),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Minimal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or greater than the specified amount.')->toString(),
 					'name' => 'min_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Maximal Order Total')->toString(),
 					'description' => Customweb_I18n_Translation::__('This payment method is only available in case the order total is equal to or less than the specified amount.')->toString(),
 					'name' => 'max_order_total',
 					'xtype' => 'textfield',
 					'value' => '',
 					'required' => 0,
 				),
				array(
					'title' => Customweb_I18n_Translation::__('New Order Status')->toString(),
 					'description' => Customweb_I18n_Translation::__('You can decide on the order status new orders should have that have an uncertain authorization status.')->toString(),
 					'name' => 'order_status',
 					'xtype' => 'combobox',
 					'value' => '0',
 					'required' => 1,
 					'options' => PayItEasyCw_Helpers_Util::getOrderStatusOptions(),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Payment Form Position')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide where the payment form should be displayed.')->toString(),
 					'name' => 'form_position',
 					'xtype' => 'combobox',
 					'value' => 'checkout',
 					'required' => 1,
 					'options' => array(array('value' => 'checkout', 'text' => Customweb_I18n_Translation::__('On checkout page')->toString()), array('value' => 'separate', 'text' => Customweb_I18n_Translation::__('On separate page')->toString())),
 				),
				array(
					'title' => Customweb_I18n_Translation::__('Zero Checkout')->toString(),
 					'description' => Customweb_I18n_Translation::__('Decide how you want to handle zero checkouts. Either use the default behavior (authorization with PSP) or skip directly to the success page.')->toString(),
 					'name' => 'zero_checkout',
 					'xtype' => 'combobox',
 					'value' => 'default',
 					'required' => 1,
 					'options' => array(array('value' => 'default', 'text' => Customweb_I18n_Translation::__('Default')->toString()), array('value' => 'skip', 'text' => Customweb_I18n_Translation::__('Skip')->toString())),
 				),
			);
		}


		return $result;
	}

	/**
	 * Return a specific form fields of a payment method.
	 *
	 * @param integer $paymentId
	 * @param string $name
	 * @return array|boolean
	 */
	protected static function getElement($paymentId, $name)
	{
		if (!isset(self::$elementCache[$paymentId][$name])) {
			$elements = self::getConfigForm($paymentId);
			foreach ($elements as $element) {
				if ($element['name'] == $name) {
					self::$elementCache[$paymentId][$name] = $element;
					break;
				}
			}
			if (!isset(self::$elementCache[$paymentId][$name])) {
				self::$elementCache[$paymentId][$name] = false;
			}
		}

		return self::$elementCache[$paymentId][$name];
	}

	/**
	 * Check validity of input value.
	 *
	 * @param integer $paymentId
	 * @param string $name
	 * @param mixed $value
	 * @return boolean
	 */
	public static function isValueValid($paymentId, $name, $value)
	{
		$element = self::getElement($paymentId, $name);
		if ($element === false) {
			return false;
		}
		if ($element['xtype'] != 'multiselect' && $element['required'] == 1 && empty($value)) {
			return false;
		}
		if (isset($element['options'])) {
			$options = array();
			foreach ($element['options'] as $option) {
				$options[] = $option['value'];
			}

			if (is_array($value)) {
				foreach ($value as $val) {
					if (!in_array($val, $options)) {
						return false;
					}
				}
				return true;
			}

			return in_array($value, $options);
		}

		return true;
	}

	/**
	 * Return default value of a specific field.
	 *
	 * @param integer $paymentId
	 * @param string $name
	 * @return mixed
	 */
	public static function getDefaultValue($paymentId, $name)
	{
		$element = self::getElement($paymentId, $name);
		if ($element === false) {
			return;
		}
		return $element['value'];
	}

	/**
	 * Return the configuration values of a payment method.
	 *
	 * @param integer $paymentId
	 * @param integer $shopId
	 * @return array
	 */
	public static function getConfigValues($paymentId, $shopId = null)
	{
		if ($shopId != null) {
			$filter = array(
				'paymentId' => $paymentId,
				'shopId' => $shopId
			);
		} else {
			$filter = array(
				'paymentId' => $paymentId
			);
		}
		$configs = Shopware()->Models()
			->getRepository('Shopware\CustomModels\PayItEasyCw\Payment\Config')
			->findBy($filter);

		$result = array();
		foreach ($configs AS $config) {
			$element = self::getElement($paymentId, $config->getName());
			if ($element !== null && $element['xtype'] === 'multiselect') {
				if ($value === '') {
					$value = array();
				}
				else {
					$value = explode(',', $config->getValue());
				}
			} else {
				$value = $config->getValue();
			}

			$result[$config->getShopId()][$config->getName()] = $value;
		}

		if ($shopId !== null) {
			return $result[$shopId];
		}

		return $result;
	}

	/**
	 * Return the value of a specific field.
	 *
	 * @param integer $paymentId
	 * @param string $name
	 * @param integer $shopId
	 * @return mixed
	 */
	public static function getConfigValue($paymentId, $name, $shopId)
	{
		$shop = Shopware()->Models()
			->getRepository('Shopware\Models\Shop\Shop')
			->find($shopId);

		if ($shop->getMain() !== null) {
			$shopId = $shop->getMain()->getId();
		}

		$config = Shopware()->Models()
			->find('Shopware\CustomModels\PayItEasyCw\Payment\Config', array(
				'paymentId' => $paymentId,
				'shopId' => $shopId,
				'name' => $name
			));

		if (!($config instanceof \Shopware\CustomModels\PayItEasyCw\Payment\Config)) {
			$value =  self::getDefaultValue($paymentId, $name);
		}
		else {
			$value = $config->getValue();
		}

		$element = self::getElement($paymentId, $name);
		if ($element !== null && $element['xtype'] === 'multiselect') {
			if ($value === '') {
				$value = array();
			}
			else {
				$value = explode(',', $value);
			}
		} elseif ($element !== null && $element['xtype'] === 'mediafield') {
			if (empty($value) || $value == $element['value']) {
				$value = PayItEasyCw_Helpers_Util::getAssetResolver()->resolveAssetStream($value);
			} else {
				$value = new Customweb_Core_Stream_Input_File(Shopware()->DocPath() . $value);
			}
		}

		return $value;
	}

	/**
	 * Return array of all main shops.
	 *
	 * @return array
	 */
	public static function getShops()
	{
		$shops = Shopware()->Models()
			->getRepository('Shopware\Models\Shop\Shop')
			->findBy(array(
				'mainId' => null
			));

		$result = array();
		foreach ($shops as $shop) {
			$result[] = array(
				'id' => $shop->getId(),
				'name' => $shop->getName()
			);
		}

		return $result;
	}
}
