<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This controller handles all actions relating transactions.
 * It reads transactions and processes them.
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Backend_PayiteasycwBaseTransaction extends Shopware_Controllers_Backend_ExtJs
{
	/**
	 * Get a list of all transactions of a specific order to be displayed in the backend.
	 */
	public function getTransactionsAction()
	{
		$transactionId = $this->Request()->getParam('transactionId');
		$orderId = $this->Request()->getParam('orderId');
		if (!empty($transactionId)) {
			$transactions = array($this->getTransaction());
		} elseif (!empty($orderId)) {
			$transactions = PayItEasyCw_Helpers_Util::loadTransactionsByOrder($orderId);
		} else {
			$transactions = PayItEasyCw_Helpers_Util::getEntityManager()->search('PayItEasyCw_Entities_Transaction');
		}

		$items = array();
		foreach ($transactions as $transaction) {
			$items[] = $this->formatTransaction($transaction);
		}

		$this->View()->assign(array(
			'success' => true,
			'data' => $items,
			'count' => count($items)
		));
	}

	/**
	 * Capture a transaction and return success or error message.
	 */
	public function captureAction()
	{
		try {
			$transaction = $this->getTransaction();
			$payment = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod());
			
			$captureLineItems = $this->getLineItemsToProcess($transaction->getTransactionObject()->getUncapturedLineItems());
			if (count($captureLineItems) > 0) {
				$close = false;
				if ($this->Request()->getParam('close') == 'on') {
					$close = true;
				}
				$payment->capture($transaction, $captureLineItems, $close);
			} else {
				$payment->capture($transaction);
			}

			$this->View()->assign(array(
				'success' => true,
				'message' => Customweb_I18n_Translation::__('The invoice has been captured successfully.')
			));
		} catch(Exception $e) {
			$this->View()->assign(array(
				'success' => false,
				'message' => $e->getMessage()
			));
		}
	}

	/**
	 * Refund a transaction and return success or error message.
	 */
	public function refundAction()
	{
		try {
			$transaction = $this->getTransaction();
			$payment = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod());
			
			$refundLineItems = $this->getLineItemsToProcess($transaction->getTransactionObject()->getNonRefundedLineItems());
			if (count($refundLineItems) > 0) {
				$close = false;
				if ($this->Request()->getParam('close') == 'on') {
					$close = true;
				}
				$payment->refund($transaction, $refundLineItems, $close);
			} else {
				$payment->refund($transaction);
			}

			$this->View()->assign(array(
				'success' => true,
				'message' => Customweb_I18n_Translation::__('The invoice has been refunded successfully.')
			));
		} catch(Exception $e) {
			$this->View()->assign(array(
				'success' => false,
				'message' => $e->getMessage()
			));
		}
	}

	/**
	 * Cancel a transaction and return success or error message.
	 */
	public function cancelAction()
	{
		try {
			$transaction = $this->getTransaction();
			$payment = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod());
			$payment->cancel($transaction);

			$this->View()->assign(array(
				'success' => true,
				'message' => Customweb_I18n_Translation::__('The invoice has been cancelled successfully.')
			));
		} catch(Exception $e) {
			$this->View()->assign(array(
				'success' => false,
				'message' => $e->getMessage()
			));
		}
	}

	/**
	 * Update a transaction and return success or error message.
	 */
	public function updateAction()
	{
		$transaction = $this->getTransaction();

		$updateHandler = PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_Update_IHandler');
		$updateProcessor = new Customweb_Payment_Update_PullProcessor($updateHandler, $transaction->getTransactionId());
		$updateProcessor->process();
			
		$log = $updateHandler->getLastLog();
		$this->View()->assign(array(
			'success' => $log['type'] != Customweb_Payment_Update_IHandler::LOG_TYPE_ERROR,
			'message' => $log['message']
		));
	}
	
	/**
	 * Get the current transaction.
	 * 
	 * @return PayItEasyCw_Entities_Transaction
	 */
	private function getTransaction()
	{
		return PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('transactionId'));
	}
	
	/**
	 * Format the transaction as array.
	 * 
	 * @param PayItEasyCw_Entities_Transaction $transaction
	 * @return array
	 */
	private function formatTransaction(PayItEasyCw_Entities_Transaction $transaction)
	{
		/* @var $transaction PayItEasyCw_Entities_Transaction */
		$historyItems = $transaction->getTransactionObject()->getHistoryItems();
		$history = array();
		foreach ($historyItems as $historyItem) {
			$history[] = array(
				'date' => $historyItem->getCreationDate(),
				'action' => $historyItem->getActionPerformed(),
				'message' => (string)$historyItem->getMessage()
			);
		}
	
		$captureItems = $transaction->getTransactionObject()->getCaptures();
		$captures = array();
		foreach ($captureItems as $captureItem) {
			$item = array();
			$item['labels'] = $this->formatLabels($captureItem->getCaptureLabels());
			$item['id'] = $item['labels']['capture_id']['value'];
			$item['amount'] = $item['labels']['capture_amount']['value'];
			$item['date'] = $item['labels']['capture_date']['value'];
			$item['status'] = (string)$item['labels']['capture_status']['value'];
			$captures[] = $item;
		}
	
		$refundItems = $transaction->getTransactionObject()->getRefunds();
		$refunds = array();
		foreach ($refundItems as $refundItem) {
			$item = array();
			$item['labels'] = $this->formatLabels($refundItem->getRefundLabels());
			$item['id'] = $item['labels']['refund_id']['value'];
			$item['amount'] = $item['labels']['refund_amount']['value'];
			$item['date'] = $item['labels']['refund_date']['value'];
			$item['status'] = (string)$item['labels']['refund_status']['value'];
			$refunds[] = $item;
		}
	
		$item = array(
			'transactionId' => $transaction->getTransactionId(),
			'paymentMethod' => $transaction->getTransactionObject()->getPaymentMethod()->getPaymentMethodDisplayName(),
			'createdOn' => $transaction->getCreatedOn(),
			'updatedOn' => $transaction->getUpdatedOn(),
			'authorizationType' => $transaction->getAuthorizationType(),
			'authorizationAmount' => $transaction->getTransactionObject()->getAuthorizationAmount(),
			'authorizationStatus' => $transaction->getTransactionObject()->getAuthorizationStatus(),
			'isAuthorized' => $transaction->getTransactionObject()->isAuthorized(),
			'labels' => $this->formatLabels($transaction->getTransactionObject()->getTransactionLabels()),
			
			'decimalPlaces' => (int)Customweb_Util_Currency::getDecimalPlaces($transaction->getTransactionObject()->getCurrencyCode()),
			'currencyCode' => strtoupper($transaction->getTransactionObject()->getCurrencyCode()),
	
			'capturePossible' => $transaction->getTransactionObject()->isCapturePossible(),
			'partialCapturePossible' => $transaction->getTransactionObject()->isPartialCapturePossible(),
			'captureClosable' => $transaction->getTransactionObject()->isCaptureClosable(),
			'capturableAmount' => round($transaction->getTransactionObject()->getCapturableAmount(), 2),
			'capturableItems' => $this->formatLineItems($transaction->getTransactionObject()->getUncapturedLineItems(), $transaction->getTransactionObject()->getCurrencyCode()),
	
			'refundPossible' => $transaction->getTransactionObject()->isRefundPossible(),
			'partialRefundPossible' => $transaction->getTransactionObject()->isPartialRefundPossible(),
			'refundClosable' => $transaction->getTransactionObject()->isRefundClosable(),
			'refundableAmount' => $transaction->getTransactionObject()->getRefundableAmount(),
			'refundableItems' => $this->formatLineItems($transaction->getTransactionObject()->getNonRefundedLineItems(), $transaction->getTransactionObject()->getCurrencyCode()),
	
			'cancelPossible' => $transaction->getTransactionObject()->isCancelPossible(),
	
			'updatable' => $transaction->getTransactionObject()->isUpdatable(),
	
			'history' => $history,
			'captures' => $captures,
			'refunds' => $refunds
		);
	
		return $item;
	}
	
	/**
	 * Format the transaction labels as a label/value array.
	 * 
	 * @param array $labels
	 * @return array
	 */
	private function formatLabels($labels)
	{
		$formatted = array();
		foreach ($labels as $key => $label) {
			$formatted[$key] = array(
				'label' => (string)$label['label'],
				'value' => Customweb_Core_Util_Xml::escape((string)$label['value'])
			);
		}
		return $formatted;
	}
	
	/**
	 * Format the line items as array.
	 * 
	 * @param Customweb_Payment_Authorization_IInvoiceItem[] $lineItems
	 * @return array
	 */
	private function formatLineItems($lineItems, $currency)
	{
		$result = array();
		foreach ($lineItems as $lineItem) {
			$result[] = array(
				'sku' => $lineItem->getSku(),
				'name' => $lineItem->getName(),
				'qty' => $lineItem->getQuantity(),
				'taxAmount' => Customweb_Util_Currency::roundAmount($lineItem->getTaxAmount(), $currency),
				'taxRate' => number_format($lineItem->getTaxRate(), 2),
				'amountExclTax' => Customweb_Util_Currency::roundAmount($lineItem->getAmountExcludingTax(), $currency),
				'amountInclTax' => Customweb_Util_Currency::roundAmount($lineItem->getAmountIncludingTax(), $currency),
				'type' => $lineItem->getType(),
			);
		}
		return $result;
	}
	
	/**
	 * Return the line items that are to be processed (captured or refunded).
	 * 
	 * @param Customweb_Payment_Authorization_IInvoiceItem[] $lineItems
	 * @return Customweb_Payment_Authorization_IInvoiceItem[]
	 */
	private function getLineItemsToProcess($lineItems)
	{
		$lineItemsToProcess = array();
		$quantities = $this->Request()->getParam('quantity');
		$exclAmounts = $this->Request()->getParam('amountExclTax');
		$inclAmounts = $this->Request()->getParam('amountInclTax');
		if (!empty($quantities)) {
			foreach ($quantities as $index => $quantity) {
				if (isset($inclAmounts[$index])) {
					$originalItem = $lineItems[$index];
					$isDiscount = ($originalItem->getType() == Customweb_Payment_Authorization_IInvoiceItem::TYPE_DISCOUNT);
					if (($isDiscount && floatval($inclAmounts[$index]) < 0) || (!$isDiscount && floatval($inclAmounts[$index]) > 0)) {
						$lineItemsToProcess[$index] = new Customweb_Payment_Authorization_DefaultInvoiceItem (
							$originalItem->getSku(), $originalItem->getName(), $originalItem->getTaxRate(), abs(floatval($inclAmounts[$index])), $quantity, $originalItem->getType()
						);
					}
				}
			}
		}
		return $lineItemsToProcess;
	}
}
