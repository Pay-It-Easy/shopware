<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Frontend_PayItEasyCwCheckout extends Enlight_Controller_Action
{
	/**
	 * Display the breakout page required by iframe authorization method.
	 */
	public function breakoutAction()
	{
		$transaction = PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('cstrxid'));

		$redirectionUrl = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod())->getBreakoutUrl($transaction->getTransactionObject()->getTransactionContext());

		$this->View()->loadTemplate('frontend/checkout/payiteasycw/Breakout.tpl');

		$this->View()->assign('breakoutUrl', $redirectionUrl);
	}

	/**
	 * Display the iframe/widget page required by iframe/widget authorization method.
	 */
	public function paymentAction()
	{
		$transaction = PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('cstrxid'));

		$alias = $this->Request()->getParam('alias');
		if ($alias != 'new' && !empty($alias) && $transaction->getTransactionObject()->getAlias() == null) {
			$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
			$payment = PayItEasyCw_Helpers_Util::getPayment($order->getPayment()->getId());
			$transactionContext = $payment->getNewTransactionContext($order, $alias);
			$transaction = $transactionContext->getTransaction();
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);
		}

		if ($transaction->getAuthorizationType() == Customweb_Payment_Authorization_Iframe_IAdapter::AUTHORIZATION_METHOD_NAME) {
			$targetUrl = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod())->getIframeUrl($transaction->getTransactionObject()->getTransactionContext(), PayItEasyCw_Components_Request::getInstance()->getParameters());
			$iframeHeight = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod())->getIframeHeight($transaction->getTransactionObject()->getTransactionContext(), PayItEasyCw_Components_Request::getInstance()->getParameters());
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

			if($transaction->getTransactionObject()->isAuthorizationFailed()) {
				$errorMessages = $transaction->getTransactionObject()->getErrorMessages();
				$messageToDisplay = nl2br(current($errorMessages));
				reset($errorMessages);

				$session = Shopware()->Session();
				$session['PayItEasyCwCheckoutError'] = $messageToDisplay;

				$redirectionUrl =  PayItEasyCw_Helpers_Util::getUrl(array(
						'controller'	=> 'checkout',
						'action'		=> 'confirm',
						'forceSecure'	=> true
				));

				header('Location: ' . $redirectionUrl);
				die();
			}


			$this->View()->loadTemplate('frontend/checkout/payiteasycw/Iframe.tpl');

			$this->View()->assign('targetUrl', $targetUrl);
			$this->View()->assign('iframeHeight', $iframeHeight);
		} elseif ($transaction->getAuthorizationType() == Customweb_Payment_Authorization_Widget_IAdapter::AUTHORIZATION_METHOD_NAME) {
			$widgetHtml = PayItEasyCw_Helpers_Util::getPayment($transaction->getPaymentMethod())->getWidgetHtml($transaction->getTransactionObject()->getTransactionContext(), PayItEasyCw_Components_Request::getInstance()->getParameters());
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

			if($transaction->getTransactionObject()->isAuthorizationFailed()) {
				$messageToDisplay = nl2br(current($transaction->getTransactionObject()->getErrorMessages()));
				reset($errorMessages);

				$session = Shopware()->Session();
				$session['PayItEasyCwCheckoutError'] = $messageToDisplay;

				$redirectionUrl =  PayItEasyCw_Helpers_Util::getUrl(array(
						'controller'	=> 'checkout',
						'action'		=> 'confirm',
						'forceSecure'	=> true
				));

				header('Location: ' . $redirectionUrl);
				die();
			}

			$this->View()->loadTemplate('frontend/checkout/payiteasycw/Widget.tpl');

			$this->View()->assign('widgetHtml', $widgetHtml);
		}

	}

	/**
	 * Before payment, save form data in session (order comment, newsletter subscription).
	 */
	public function saveFormAction()
	{
		$tempOrder = PayItEasyCw_Helpers_Util::getOrCreateTemporaryOrder();
		$wrapper = new PayItEasyCw_Components_PaymentMethodWrapper($tempOrder->getPayment());

		try {
			$wrapper->validate();
		} catch (Exception $e) {
			echo Zend_Json::encode(array(
				'error' => $e->getMessage()
			));
			die();
		}

		$alias = $this->Request()->getParam('alias');
		if (empty($alias)) {
			$alias = null;
		}

		if (PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			$orderHelper = new PayItEasyCw_Components_Order();
			$orderHelper->saveCheckoutForm($this->Request());
			$orderHelper->backupBasket();
			$orderNumber = $orderHelper->createOrder();
			$orderHelper->restoreBasket();
			$orderHelper->createTemporaryOrder();

			$order = Shopware()->Models()->getRepository('Shopware\Models\Order\Order')->findOneBy(array('number' => $orderNumber));
			$transactionContext = $wrapper->getNewTransactionContext($order, $alias);
			$transaction = $transactionContext->getTransaction();
			$transaction->setOrderId($order->getId());
			$transaction->setShopId($order->getShop()->getId());
			$transaction->setTemporaryOrderId(null);
			$transaction->setLastSetOrderStatusSettingKey(null);
			$transaction->setEmailData(PayItEasyCw_Components_Order::getEmailVariables());
			if ($transaction->getTransactionObject()->getTransactionContext() instanceof PayItEasyCw_Components_RecurringTransactionContext) {
				$wrapper->finishRecurring($transaction, $order);
			}
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

			$orderHelper = new PayItEasyCw_Components_Order($transaction);
			$orderHelper->updateOrder();
		} else {
			$transactionContext = $wrapper->getNewTransactionContext($tempOrder, $alias);
			$orderHelper = new PayItEasyCw_Components_Order($transactionContext->getTransaction());
			$orderHelper->saveCheckoutForm($this->Request());
		}

		$authorizationMethod = $wrapper->getAuthorizationMethodName($transactionContext->getOrderContext());
		if ($authorizationMethod == 'AjaxAuthorization') {
			$response = $wrapper->generateJavascriptForAjax($transactionContext);
		} else {
			$response = array(
				'formActionUrl' => $wrapper->generateFormActionUrl($transactionContext),
			);
		}
		$response['hiddenFields'] = $wrapper->generateHiddenFormParameters($transactionContext);
		echo Zend_Json::encode($response);

		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transactionContext->getTransaction());
		die();
	}

	/**
	 * Display the template used by payment page authorization method.
	 */
	public function templateAction()
	{
		$matches = array();
		preg_match('/^[^:]+:\/\/[^\/]+/i', PayItEasyCw_Helpers_Util::getUrl(array(
			'controller' => 'index',
			'forceSecure' => true
		)), $matches);
		$baseUrl = $matches[0];

		$html = $this->View()->fetch('frontend/checkout/payiteasycw/Template.tpl');
		$html = Customweb_Util_Html::replaceRelativeUrls($html, $baseUrl);

		echo $html;
		die();
	}

	/**
	 * Return the alias form elements required by the alias manager.
	 */
	public function getAliasDataAction()
	{
		$visibleFormFields = false;
		$errorMessage = false;

		$payment = PayItEasyCw_Helpers_Util::getPayment($this->Request()->getParam('paymentMethod'));
		if ($payment != null) {
			$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
			$orderContext = $payment->getOrderContext($order->getId());
			$paymentCustomerContext = PayItEasyCw_Helpers_Util::loadPaymentCustomerContextByCustomer($order->getCustomer()->getId());
			$aliasTransaction = PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('aliasId'))->getTransactionObject();
			$visibleFormFields = $payment->generateVisibleFormFields($orderContext, $paymentCustomerContext, $aliasTransaction);
		} else {
			$errorMessage = Customweb_I18n_Translation::__('Technical issue: This payment methods is not available at the moment.');
		}

		echo Zend_Json::encode(array(
			'visibleFormFields' => $visibleFormFields,
			'error' => $errorMessage
		));
		die();
	}
}