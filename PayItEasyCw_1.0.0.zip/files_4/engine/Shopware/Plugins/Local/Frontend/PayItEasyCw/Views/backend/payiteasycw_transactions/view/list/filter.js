//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/view/list/filter"}
Ext.define('Shopware.apps.PayiteasycwTransactions.view.list.Filter', {
    extend: 'Ext.panel.Panel',

    width: 300,
    alias: 'widget.payiteasycw-transactions-list-filter',
    cls: Ext.baseCSSPrefix + 'filter-options',
    autoScroll: true,

    initComponent: function () {
        var me = this;
        me.registerEvents();
        me.items = [
            me.createFilterContainer()
        ];
        me.title = '{s name=payiteasycw/361af81463eb61d4adbd3d51899d0a1b}Filter Options{/s}';
        me.callParent(arguments);
    },

    registerEvents: function() {
        this.addEvents(
            'acceptFilters',
            'resetFilters'
        );
    },

    createFilterContainer: function() {
        var me = this;

        return Ext.create('Ext.container.Container', {
            border: false,
            padding: 10,
            items: [
                me.createFilterForm(),
                me.createFilterButtons()
            ]
        });
    },

    createFilterForm: function() {
        var me = this;

        me.filterForm = Ext.create('Ext.form.Panel', {
            border: false,
            cls: Ext.baseCSSPrefix + 'filter-form',
            defaults:{
                anchor: '98%',
                labelWidth: 120,
                minWidth: 250,
                xtype: 'pagingcombo',
                style: 'box-shadow: none;',
                labelStyle: 'font-weight:700;'
            },
            items: [
                me.createFromField(),
                me.createToField(),
                me.createAuthorizationStatusField(),
                me.createShopField()
            ]
        });
        return me.filterForm;
    },

    createFromField: function() {
        var me = this;
        return Ext.create('Ext.form.field.Date', {
            name: 'from',
            fieldLabel: '{s name=payiteasycw/d98a07f84921b24ee30f86fd8cd85c3c}From{/s}',
            submitFormat: 'd.m.Y'
        });
    },

    createToField: function() {
        var me = this;
        return Ext.create('Ext.form.field.Date', {
            name: 'to',
            fieldLabel: '{s name=payiteasycw/01b6e20344b68835c5ed1ddedf20d531}To{/s}',
            submitFormat: 'd.m.Y'
        });
    },

    createAuthorizationStatusField: function() {
        var me = this;

        return Ext.create('Ext.form.field.ComboBox', {
            name: 'transactions.authorizationStatus',
            queryMode: 'local',
            store: Ext.create('Ext.data.Store', {
                fields:	['value', 'text'],
                data: [
                	{ value: 'pending', text:  '{s name=payiteasycw/7c6c2e5d48ab37a007cbf70d3ea25fa4}Pending{/s}' },
                	{ value: 'successful', text:  '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}' },
                	{ value: 'failed', text:  '{s name=payiteasycw/26934eb377001f66e37289a5c93fe284}Failed{/s}' }
                ]
    		}),
            valueField: 'value',
            displayField: 'text',
            emptyText: '{s name=payiteasycw/1cbdb2953d92c3e10c8e2deeda188cee}Show all{/s}',
            fieldLabel: '{s name=payiteasycw/9acb44549b41563697bb490144ec6258}Status{/s}'
        });
    },

    createShopField: function() {
        var me = this;

        return Ext.create('Ext.form.field.ComboBox', {
            name: 'transactions.shopId',
            store: Ext.create('Shopware.store.Shop', { pageSize: 7 }),
            valueField: 'id',
            pageSize: 7,
            queryMode: 'remote',
            displayField: 'name',
            emptyText: '{s name=payiteasycw/1cbdb2953d92c3e10c8e2deeda188cee}Show all{/s}',
            fieldLabel: '{s name=payiteasycw/fb54f3c5992b96d001bb16e8e92d968d}Shop{/s}'
        });
    },

    createFilterButtons: function() {
        var me = this;

        return Ext.create('Ext.container.Container', {
            style: 'margin-top: 10px;',
            items: [
                {
                    xtype: 'button',
                    cls: 'small secondary',
                    text: '{s name=payiteasycw/86266ee937d97f812a8e57d22b62ee29}Reset{/s}',
                    handler: function() {
                        me.fireEvent('resetFilters', me.filterForm);
                    }
                },
                {
                    xtype: 'button',
                    text: '{s name=payiteasycw/f4081916a1eac690d982fb9da667dd8c}Perform{/s}',
                    style: 'float: right;',
                    cls: 'primary small',
                    handler: function() {
                        me.fireEvent('acceptFilters', me.filterForm.getValues());
                    }
                }
            ]
        });
    },
});
//{/block}