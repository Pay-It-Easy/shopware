//{block name="backend/config/payiteasycw/view/element/mediafield"}
Ext.define('Shopware.apps.Config.view.element.Mediafield', {
    extend: 'Shopware.MediaManager.MediaSelection',
    alias: [
        'widget.config-element-mediafield'
    ]
});
//{/block}