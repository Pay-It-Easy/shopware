<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class extends actions called on the payment controller.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_ActionHandlers_Payment extends PayItEasyCw_Components_ActionHandlers_Abstract
{
	/**
	 * Extends template to load custom javascript files.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function indexAction(Enlight_Event_EventArgs $args)
	{
		$args->getSubject()
			->View()
			->extendsTemplate('backend/payment/payiteasycw/app.js');
	}

	/**
	 * Loads further javascript files.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function loadAction(Enlight_Event_EventArgs $args)
	{
		$args->getSubject()
			->View()
			->extendsTemplate('backend/payment/payiteasycw/model/payment.js');
	}

	/**
	 * Add some attributes to the payment records.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function getPaymentsAction(Enlight_Event_EventArgs $args)
	{
		$result = $args->getSubject()
			->View()
			->getAssign();
		$data = $result['data'];

		foreach ($data as $key => $payment) {
			$paymentModel = Shopware()->Models()
				->getRepository('Shopware\Models\Payment\Payment')
				->find($payment['id']);

			if ($paymentModel instanceof Shopware\Models\Payment\Payment) {
				$data[$key]['payiteasycw'] = ($paymentModel->getPluginId() == $this->_pluginId);

				if ($paymentModel->getPluginId() == $this->_pluginId) {
					$data[$key]['configForm'] = Zend_Json::encode(PayItEasyCw_Helpers_Payment_Config::getConfigForm($payment['id']));
					$data[$key]['configValues'] = Zend_Json::encode(PayItEasyCw_Helpers_Payment_Config::getConfigValues($payment['id']));
					$data[$key]['configFormShops'] = Zend_Json::encode(PayItEasyCw_Helpers_Payment_Config::getShops());
				}
			}
		}

		$args->getSubject()
			->View()
			->clearAssign();
		$args->getSubject()
			->View()
			->assign(array(
				'success' => true,
				'data' => $data
			));
	}

	/**
	 * Save custom payment configuration after updating payment method.
	 *
	 * @param Enlight_Event_EventArgs $args
	 * @return void
	 */
	protected function updatePaymentsAction(Enlight_Event_EventArgs $args)
	{
		$paymentId = $args->getRequest()
			->getParam('id', null);
		$data = $args->getRequest()
			->getParams();
		$configValues = Zend_Json::decode($data['configValues']);

		foreach ($configValues as $key => $value) {
			$tmp = explode('__', $key, 2);
			$shopId = $tmp[0];
			$name = $tmp[1];
			
			if (is_array($value)) {
				$value = array_filter($value);
			}

			if (!PayItEasyCw_Helpers_Payment_Config::isValueValid($paymentId, $name, $value)) {
				$value = PayItEasyCw_Helpers_Payment_Config::getDefaultValue($paymentId, $name);
			}

			if (is_array($value)) {
				$value = implode(',', $value);
			}

			$config = Shopware()->Models()
				->find('Shopware\CustomModels\PayItEasyCw\Payment\Config', array(
					'paymentId' => $paymentId,
					'shopId' => $shopId,
					'name' => $name
				));
			if (!($config instanceof \Shopware\CustomModels\PayItEasyCw\Payment\Config)) {
				if ($value == PayItEasyCw_Helpers_Payment_Config::getDefaultValue($paymentId, $name)) {
					continue;
				}
				$config = new \Shopware\CustomModels\PayItEasyCw\Payment\Config();
				$config->setPaymentId($paymentId);
				$config->setName($name);
				$config->setShopId($shopId);
			}

			$config->setValue($value);

			if ($value == PayItEasyCw_Helpers_Payment_Config::getDefaultValue($paymentId, $name)) {
				Shopware()->Models()
					->remove($config);
			} else {
				Shopware()->Models()
					->persist($config);
			}
		}

		Shopware()->Models()
			->flush();
	}
}
