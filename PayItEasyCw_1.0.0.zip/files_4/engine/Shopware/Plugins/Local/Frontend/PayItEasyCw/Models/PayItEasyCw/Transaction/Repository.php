<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

namespace Shopware\CustomModels\PayItEasyCw\Transaction;

use Shopware\Components\Model\ModelRepository;

class Repository extends ModelRepository
{
    public function getBackendTransactionsQuery($filters = null, $orderBy = null, $offset = null, $limit = null)
    {
        $builder = $this->getBackendTransactionsQueryBuilder($filters, $orderBy);
        if ($limit !== null) {
            $builder->setFirstResult($offset)
                    ->setMaxResults($limit);
        }
        return $builder->getQuery();
    }

    public function getBackendTransactionsQueryBuilder($filters = null, $orderBy = null)
    {
        $builder = $this->getEntityManager()->createQueryBuilder();
        $builder->select(array(
                'transactions',
                'shop',
        		'payment'
            ));

        $builder->from('Shopware\CustomModels\PayItEasyCw\Transaction\Transaction', 'transactions')
                ->leftJoin('transactions.shop', 'shop')
        		->leftJoin('transactions.payment', 'payment');

        if (!empty($filters)) {
            $builder = $this->filterListQuery($builder, $filters);
        }

        if (!empty($orderBy)) {
            $builder->addOrderBy($orderBy);
        }
        return $builder;
    }

    public function filterListQuery(\Doctrine\ORM\QueryBuilder $builder, $filters=null)
    {
        $expr = Shopware()->Models()->getExpressionBuilder();

        if (!empty($filters)) {
            foreach ($filters as $filter) {
                if (empty($filter['property']) || $filter['value'] === null || $filter['value'] === '') {
                    continue;
                }
                switch ($filter['property']) {
                    case "free":
                        $builder->andWhere(
                            $expr->orX(
                                $expr->like('transactions.transactionId', '?1'),
                                $expr->like('transactions.orderId', '?1'),
                                $expr->like('transactions.authorizationType', '?1'),
                                $expr->like('transactions.authorizationAmount', '?1'),
                                $expr->like('transactions.authorizationStatus', '?1'),
                                $expr->like('transactions.currency', '?1'),
                                $expr->like('transactions.paymentMachineName', '?2'),
                                $expr->like('shop.name', '?2'),
                                $expr->like('payment.name','?2')
                            )
                        );
                        $builder->setParameter(1,       $filter['value'] . '%');
                        $builder->setParameter(2, '%' . $filter['value'] . '%');
                        break;
                    case "from":
                        $tmp = new \DateTime($filter['value']);
                        $builder->andWhere($expr->gte('transactions.createdOn', $tmp->format('Ymd')));
                        break;
                    case "to":
                        $tmp = new \Zend_Date($filter['value']);
                        $tmp->setHour('23');
                        $tmp->setMinute('59');
                        $tmp->setSecond('59');
                        $builder->andWhere('transactions.createdOn <= :transactionTimeTo');
                        $builder->setParameter('transactionTimeTo', $tmp->get('yyyy-MM-dd HH:mm:ss'));
                        break;
                    default:
                        $builder->andWhere($expr->eq($filter['property'], "'" . $filter['value'] . "'"));
                }
            }
        }

        return $builder;
    }
}
