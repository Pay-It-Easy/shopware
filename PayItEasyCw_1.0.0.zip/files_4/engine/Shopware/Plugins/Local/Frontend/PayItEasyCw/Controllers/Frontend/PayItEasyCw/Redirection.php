<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Frontend_PayItEasyCwRedirection extends Enlight_Controller_Action
{
	public function indexAction()
	{
		$session = Shopware()->Session();
		if($this->Request()->getParam('sNewsletter')!==null) {
			$session['sNewsletter'] = $this->Request()->getParam('sNewsletter') ? true : false;
		}

		if($this->Request()->getParam('sComment')!==null) {
			$session['sComment'] = trim(strip_tags($this->Request()->getParam('sComment')));
		}

		$transaction = PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('cstrxid'));

		$alias = $this->Request()->getParam('alias');
		if ($alias != 'new' && !empty($alias) && $transaction->getTransactionObject()->getAlias() == null) {
			$order = PayItEasyCw_Helpers_Util::getTemporaryOrder();
			$payment = PayItEasyCw_Helpers_Util::getPayment($order->getPayment()->getId());
			$transactionContext = $payment->getNewTransactionContext($order, $alias);
			$transaction = $transactionContext->getTransaction();
		}

		$authorizationAdapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapter($transaction->getTransactionObject()->getAuthorizationMethod());

		if (!($authorizationAdapter instanceof Customweb_Payment_Authorization_PaymentPage_IAdapter)) {
			throw new Exception("Only supported for payment page authorization.");
		}

		$headerRedirection = $authorizationAdapter->isHeaderRedirectionSupported($transaction->getTransactionObject(), PayItEasyCw_Components_Request::getInstance()->getParameters());

		if ($headerRedirection) {
			$url = $authorizationAdapter->getRedirectionUrl($transaction->getTransactionObject(), PayItEasyCw_Components_Request::getInstance()->getParameters());

			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

			header('Location: ' . $url);
			die();
		} else {
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

			$this->View()->loadTemplate('frontend/checkout/payiteasycw/Redirection.tpl');

			$this->View()->assign('paymentMethodName', $transaction->getTransactionObject()->getPaymentMethod()->getPaymentMethodDisplayName());
			$this->View()->assign('formTargetUrl', $authorizationAdapter->getFormActionUrl($transaction->getTransactionObject(), PayItEasyCw_Components_Request::getInstance()->getParameters()));
			$this->View()->assign('hiddenFormFields', Customweb_Util_Html::buildHiddenInputFields($authorizationAdapter->getParameters($transaction->getTransactionObject(), PayItEasyCw_Components_Request::getInstance()->getParameters())));
		}
	}
}