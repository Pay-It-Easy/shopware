<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Api_PayiteasycwTransactions extends Shopware_Controllers_Api_Rest
{
	/**
	 * @var Shopware\Components\Api\Resource\Transaction
	 */
	protected $resource = null;

	public function init()
	{
		Shopware()->Loader()
			->registerNamespace('PayItEasyCw_Components', dirname(__FILE__) . '/../../Components/');
		
		$this->resource = \Shopware\Components\Api\Manager::getResource('PayiteasycwTransaction');
	}

	/**
	 * Get list of users
	 *
	 * GET /api/payiteasycwtransactions/
	 */
	public function indexAction()
	{
		$limit  = $this->Request()->getParam('limit', 25);
		$offset = $this->Request()->getParam('start', 0);
		$sort   = $this->Request()->getParam('sort', array());
		$filter = $this->Request()->getParam('filter', array());

		$result = $this->resource->getList($offset, $limit, $filter, $sort);

		$this->View()->assign($result);
		$this->View()->assign('success', true);
	}

	/**
	 * Get one user
	 *
	 * GET /api/payiteasycwtransactions/{id}
	 */
	public function getAction()
	{
		$prefix = 'payiteasycw-';
		$id = $this->Request()->getParam('id');
		$usePaymentId = (boolean) $this->Request()->getParam('usePaymentId', 0);

		if($usePaymentId){
			$transaction = $this->resource->getOneByPaymentId($id);
		}else{
			if (substr($id, 0, strlen($prefix)) == $prefix) {
				$id = substr($id, strlen($prefix));
			}
			$transaction = $this->resource->getOne($id);
		}

		$this->View()->assign('data', $transaction);
		$this->View()->assign('success', true);
	}
}