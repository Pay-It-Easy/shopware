/**
 * This model represents a order transaction history entry.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/model/transaction_history"}
Ext.define('Shopware.apps.PayiteasycwBase.model.TransactionHistory', {
    extend: 'Ext.data.Model',
 
    fields: [
        //{block name="backend/payiteasycw_base/model/transaction_history/fields"}{/block}
        { name: 'date', type: 'date' },
        { name: 'action', type: 'string' },
        { name: 'message', type: 'string' },
    ]
});
//{/block}