//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/view/main/window"}
Ext.define('Shopware.apps.PayiteasycwTransactions.view.main.Window', {
    extend: 'Enlight.app.Window',

    cls: Ext.baseCSSPrefix + 'payiteasycw-transactions-list-main-window',

    alias: 'widget.payiteasycw-transactions-list-main-window',

    border: false,
    autoShow: true,
    layout: 'border',
    width: 1200,
    height: '90%',
    maximizable: true,
    minimizable: true,
    stateful: true,
    stateId: 'shopware-payiteasycw-transactions-main-window',
    title: 'Pay-It-Easy {s name=payiteasycw/365596fe002a5a2df99091f3c9a24081}Transaction List{/s}',

    initComponent: function () {
      var me = this;

      me.items = [
            Ext.create('Shopware.apps.PayiteasycwTransactions.view.list.List', {
            	region: 'center',
                flex: 2,
                transactionStore: me.transactionStore
            }), Ext.create('Shopware.apps.PayiteasycwTransactions.view.list.Navigation', {
                region: 'west'
            })
      ];

      me.callParent(arguments);
  }

});
//{/block}
