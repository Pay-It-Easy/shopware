//{block name="backend/payiteasycw_base/app"}
	Ext.define('Shopware.apps.PayiteasycwBase', {
	    extend:'Enlight.app.SubApplication',
	 
	    name:'Shopware.apps.PayiteasycwBase',
	 
	    bulkLoad: true,
	    
	    loadPath: '{url controller="PayiteasycwBase" action=load}',
	 
	    controllers: [
	        'Main',
	        'Transaction'
        ],
	 
	    stores: [
	        'Transaction'
	    ],
	    
	    models: [
	        'Transaction',
	        'TransactionCapture',
	        'TransactionHistory',
	        'TransactionRefund'
	    ],
	 
	    views: [
            'transaction.Window',
            'transaction.Transaction',
            'transaction.Overview',
            'transaction.Captures',
            'transaction.Refunds',
            'transaction.History',
            'transaction.captures.Detail',
            'transaction.captures.Form',
            'transaction.captures.Grid',
            'transaction.refunds.Detail',
            'transaction.refunds.Form',
            'transaction.refunds.Grid'
	    ],
	 
	    launch: function() {
	        var me = this,
	            mainController = me.getController('Main');
	 
	        return mainController.mainWindow;
	    }
	});
//{/block}