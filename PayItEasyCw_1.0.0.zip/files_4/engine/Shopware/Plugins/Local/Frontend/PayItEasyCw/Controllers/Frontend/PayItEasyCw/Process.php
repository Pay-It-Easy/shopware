<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Frontend_PayItEasyCwProcess extends Shopware_Controllers_Frontend_Checkout {

	public function processAction(){
		$dispatcher = PayItEasyCw_Helpers_Util::getEndpointDispatcher();
		$response = $dispatcher->invokeControllerAction(PayItEasyCw_Components_Request::getInstance(), 'process', 'index');
		$wrapper = new Customweb_Core_Http_Response($response);
		$wrapper->send();
		die();
	}

	public function authorizeAction(){
		$transaction = PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('cstrxid'));
		Shopware()->Front()->Request()->setParam('cstrxid', $transaction->getTransactionId());
		
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapter($transaction->getAuthorizationType());
		$response = $adapter->processAuthorization($transaction->getTransactionObject(), 
				PayItEasyCw_Components_Request::getInstance()->getParameters());
		
		PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_ITransactionHandler')->persistTransactionObject(
				$transaction->getTransactionObject());
		
		$wrapper = new Customweb_Core_Http_Response($response);
		$wrapper->send();
		die();
	}

	public function successAction(){
		$redirectionUrl = PayItEasyCw_Helpers_Util::waitForNotification($this->Request()->getParam('cstrxid'));
		
		header('Location: ' . $redirectionUrl);
		die();
	}

	public function failAction(){
		$transaction = PayItEasyCw_Helpers_Util::loadTransaction($this->Request()->getParam('cstrxid'));
		
		if (PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			$deleteFailedOrders = PayItEasyCw_Helpers_Util::getConfigValue('delete_failed_orders') == "yes";
			if ($deleteFailedOrders) {
				Shopware()->Models()->clear();
				Shopware()->Models()->remove($transaction->getOrder(false));
				Shopware()->Models()->flush();
			}
			else {
				$query = sprintf('UPDATE s_order SET cleared = 35, status = 4 WHERE id = ' . (int) $transaction->getOrderId());
				Shopware()->Db()->query($query);
			}
		}
		
		$errorMessages = $transaction->getTransactionObject()->getErrorMessages();
		$messageToDisplay = nl2br(end($errorMessages));
		reset($errorMessages);
		
		$session = Shopware()->Session();
		if (empty($messageToDisplay)) {
			$messageToDisplay = Customweb_I18n_Translation::__("There has been a problem during the processing of your payment.");
		}
		$session['PayItEasyCwCheckoutError'] = $messageToDisplay;
		
		$redirectionUrl = PayItEasyCw_Helpers_Util::getUrl(
				array(
					'controller' => 'checkout',
					'action' => 'confirm',
					'forceSecure' => true 
				));
		
		header('Location: ' . $redirectionUrl);
		die();
	}
}