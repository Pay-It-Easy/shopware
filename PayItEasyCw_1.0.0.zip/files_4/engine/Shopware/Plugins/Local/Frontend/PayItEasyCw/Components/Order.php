<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_Order
{
	private static $emailVariables = null;

	private static $forceSendEmail = false;

	private static $currentTransaction = null;

	/**
	 *
	 * @var PayItEasyCw_Entities_Transaction
	 */
	private $transaction = null;

	private $sessionData = null;

	private $sessionBackup = null;

	private $shopBackup = null;

	private $basket = array();

	public function __construct(PayItEasyCw_Entities_Transaction $transaction = null)
	{
		if ($transaction != null) {
			$this->transaction = $transaction;
			$this->sessionData = $transaction->getSessionData();
		} else {
			$this->sessionData = array(
				'session' => $_SESSION,
				'shopId' => Shopware()->Shop()->getId(),
				'currency' => Shopware()->Shop()->getCurrency()->toArray(),
				'id' => session_id()
			);
		}
	}

	public static function setEmailVariables($variables)
	{
		self::$emailVariables = $variables;
	}

	public static function getEmailVariables()
	{
		return self::$emailVariables;
	}

	public static function isForceSendEmail() {
		return self::$forceSendEmail;
	}

	public static function getCurrentTransaction() {
		return self::$currentTransaction;
	}

	public function sendOrderEmail()
	{
		if ($this->transaction != null) {
			self::$forceSendEmail = true;
			self::$currentTransaction = $this->transaction;
			$emailData = $this->transaction->getEmailData();
			$module = Shopware()->Modules()->Order();
			$sUserDataBackup = $module->sUserData;
			$module->sUserData = $emailData['sUserData'];
			try {
				$module->sendMail($emailData['variables']);
			} catch (Exception $e) {}
			$module->sUserData = $sUserDataBackup;
			self::$forceSendEmail = false;
			self::$currentTransaction = null;
		}
	}

	public function updateOrder()
	{
		$query = sprintf('UPDATE s_order SET transactionID = \'payiteasycw-' . (int)$this->transaction->getTransactionId() . '\' WHERE id = ' . (int)$this->transaction->getOrderId());
		Shopware()->Db()->query($query);
	}

	public function saveCheckoutForm($request)
	{
		$session = Shopware()->Session();

		if($request->getParam('sNewsletter')!==null) {
			$session['sNewsletter'] = $request->getParam('sNewsletter') ? true : false;
			$this->sessionData['session']['Shopware']['sNewsletter'] = $request->getParam('sNewsletter') ? true : false;
		}

		if($request->getParam('sComment')!==null) {
			$session['sComment'] = trim(strip_tags($request->getParam('sComment')));
			$this->sessionData['session']['Shopware']['sComment'] = trim(strip_tags($request->getParam('sComment')));
		}

		if ($this->transaction != null) {
			$this->transaction->setSessionData($this->sessionData);
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($this->transaction);
		}
	}

	public function createOrder()
	{
		if ($this->sessionData !== null && ($this->transaction == null || ($this->transaction->getTemporaryOrderId() != null
			&& $this->transaction->getTemporaryOrderId() != ''))) {
			$this->loadSession();
			$orderNumber = $this->saveOrder();
			$this->restoreSession();
			return $orderNumber;
		}
	}

	public function createTemporaryOrder()
	{
		if ($this->sessionData !== null) {
			$this->loadSession();
			$this->saveTemporaryOrder();
			$this->restoreSession();
		}
	}

	public function deleteTemporaryOrder()
	{
		if ($this->sessionData !== null) {
			$this->loadSession();

			// By not using getOrderObject() we do not load the whole object. Hence we are not
			// going to load the session. This prevents the issue of duplicating the
			// current shop in the database. We do not need the whole order object, since we
			// go only to call sDeleteTemporaryOrder() which does not need all session properties.

			$this->getOrderModule()->sDeleteTemporaryOrder();
			$this->restoreSession();
		}
	}

	public function deleteBasket()
	{
		Shopware()->Db()->query("DELETE FROM s_order_basket WHERE sessionID=?",array($this->sessionData['id']));
	}

	public function backupBasket()
	{
		$basket = Shopware()->Db()->query("SELECT * FROM s_order_basket WHERE sessionID=?",array($this->sessionData['id']));
		$this->basket = array();
		while ($item = $basket->fetch()) {
			$this->basket[] = $item;
		}
	}

	public function restoreBasket()
	{
		foreach ($this->basket as $item) {
			$params = array();
			$values = array();
			foreach ($item as $key => $value) {
				if ($key == 'id') continue;
				$params[] = "{$key} = :{$key}";
				$values[$key] = $value;
			}
			Shopware()->Db()->query("INSERT INTO s_order_basket SET " . implode(', ', $params), $values);
		}
	}

	private function saveTemporaryOrder()
	{
		$order = $this->getOrderObject();
		$order->sDeleteTemporaryOrder();
		$order->sCreateTemporaryOrder();
	}

	private function saveOrder()
	{
		return $this->getOrderObject()->sSaveOrder();
	}

	private function getOrderObject()
	{
		$session = Shopware()->Session();

		$view = array('sUserData' => $this->getUserData());
		$view = array_merge($view, $session['sOrderVariables']->getArrayCopy());
		$view['sUserData']["additional"]["user"]["paymentID"] = $view['sPayment']['id'];

		$order = $this->getOrderModule();

		$sessionData = $this->sessionData;
		$order->sSYSTEM->sSESSION_ID = $sessionData['id'];
		$order->sSYSTEM->_SESSION = $sessionData['session'];
		$order->sSYSTEM->sCurrency = $sessionData['currency'];
		$order->sSYSTEM->sLanguage = $sessionData['shopId'];

		$order->sSYSTEM->sMODULES['sAdmin']->sSYSTEM->sLanguage = $sessionData['shopId'];

		$order->sUserData = $view['sUserData'];
		$order->sComment = isset($session['sComment']) ? $session['sComment'] : '';
		$order->sBasketData = $view['sBasket'];
		$order->sAmount = $view['sBasket']['sAmount'];
		$order->sAmountWithTax = !empty($view['sBasket']['AmountWithTaxNumeric']) ? $view['sBasket']['AmountWithTaxNumeric'] : $view['sBasket']['AmountNumeric'];
		$order->sAmountNet = $view['sBasket']['AmountNetNumeric'];
		$order->sShippingcosts = $view['sBasket']['sShippingcosts'];
		$order->sShippingcostsNumeric = $view['sBasket']['sShippingcostsWithTax'];
		$order->sShippingcostsNumericNet = $view['sBasket']['sShippingcostsNet'];
		$order->bookingId = Shopware()->System()->_POST['sBooking'];
		$order->dispatchId = $session['sDispatch'];
		$order->sNet = !$view['sUserData']['additional']['charge_vat'];

		return $order;
	}

	private function getOrderModule()
	{
		$dbResourceBackup = Shopware()->Db();
		Shopware()->Bootstrap()->registerResource('Db', new PayItEasyCw_Components_DbResourceProxy(Shopware()->Db()));

		Shopware()->Modules()->Order();
		$name = 'sOrder';
		Shopware()->Hooks()->setAlias($name, $name);
		$proxy = Shopware()->Hooks()->getProxy($name);
		$module = new $proxy;
		$module->sSYSTEM = Shopware()->Modules()->Order()->sSYSTEM;

		Shopware()->Bootstrap()->registerResource('Db', $dbResourceBackup);

		return $module;
	}

	private function getUserData()
	{
		$system = Shopware()->System();
		Shopware_Plugins_Frontend_PayItEasyCw_Bootstrap::$paymentValidationDisabled = true;
		$userData = Shopware()->Modules()->Admin()->sGetUserData();
		Shopware_Plugins_Frontend_PayItEasyCw_Bootstrap::$paymentValidationDisabled = false;
		if (!empty($userData['additional']['countryShipping'])) {
			$sTaxFree = false;
			if (!empty($userData['additional']['countryShipping']['taxfree'])) {
				$sTaxFree = true;
			} elseif (
					!empty($userData['additional']['countryShipping']['taxfree_ustid'])
					&& !empty($userData['billingaddress']['ustid'])
					&& $userData['additional']['country']['id'] == $userData['additional']['countryShipping']['id']
			) {
				$sTaxFree = true;
			}

			$system->sUSERGROUPDATA = Shopware()->Db()->fetchRow("
                SELECT * FROM s_core_customergroups
                WHERE groupkey = ?
            ", array($system->sUSERGROUP));

			if (!empty($sTaxFree)) {
				$system->sUSERGROUPDATA['tax'] = 0;
				$system->sCONFIG['sARTICLESOUTPUTNETTO'] = 1; //Old template
				Shopware()->Session()->sUserGroupData = $system->sUSERGROUPDATA;
				$userData['additional']['charge_vat'] = false;
				$userData['additional']['show_net'] = false;
				Shopware()->Session()->sOutputNet = true;
			} else {
				$userData['additional']['charge_vat'] = true;
				$userData['additional']['show_net'] = !empty($system->sUSERGROUPDATA['tax']);
				Shopware()->Session()->sOutputNet = empty($system->sUSERGROUPDATA['tax']);
			}
		}

		return $userData;
	}

	private function loadSession()
	{
		if ($this->transaction != null) {
			$this->sessionBackup = $_SESSION;
			$sessionData = $this->sessionData;

			$_SESSION = $sessionData['session'];
			$_SESSION['sessionId'] = $sessionData['id'];

			Shopware()->System()->sSESSION_ID = $sessionData['id'];
			Shopware()->System()->_SESSION = $_SESSION;
			Shopware()->System()->sLanguage = $sessionData['shopId'];

			$this->shopBackup = Shopware()->Shop();
			$shop = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop')->getActiveById($sessionData['shopId']);
			if ($shop instanceof Shopware\Models\Shop\Shop) {
				$shop->registerResources(Shopware()->Bootstrap());
			}

			Shopware()->System()->sCurrency = $sessionData['currency'];

			Shopware()->System()->_POST['sBooking'] = 'payiteasycw-' . $this->transaction->getTransactionId();
			Shopware()->Front()->Request()->setParam('cstrxid', $this->transaction->getTransactionId());
		}
	}

	private function restoreSession()
	{
		if ($this->transaction != null) {
			$_SESSION = $this->sessionBackup;
			$this->shopBackup->registerResources(Shopware()->Bootstrap());
		}
	}
}