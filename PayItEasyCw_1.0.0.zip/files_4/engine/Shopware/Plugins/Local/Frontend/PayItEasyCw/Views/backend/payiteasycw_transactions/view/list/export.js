//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/view/list/export"}
Ext.define('Shopware.apps.PayiteasycwTransactions.view.list.Export', {
    extend: 'Ext.panel.Panel',

    width: 300,
    alias: 'widget.payiteasycw-transactions-list-export',
    cls: Ext.baseCSSPrefix + 'export-options',
    autoScroll: true,

    initComponent: function() {
        var me = this;
        me.registerEvents();
        me.items = [
            me.createExportContainer()
        ];
        me.title = '{s name=payiteasycw/2de1ac2c0e88e541a954cb271f1c03be}Export Options{/s}';
        me.callParent(arguments);
    },

    registerEvents: function() {
        this.addEvents(
            'export'
        );
    },
    
    createExportContainer: function() {
        var me = this;

        return Ext.create('Ext.container.Container', {
            border: false,
            padding: 10,
            items: [
                me.createExportForm(),
                me.createExportButtons()
            ]
        });
    },
    
    createExportForm: function() {
        var me = this;

        me.exportForm = Ext.create('Ext.form.Panel', {
            border: false,
            cls: Ext.baseCSSPrefix + 'export-form',
            standardSubmit: true,
            target: 'iframe',
            defaults:{
                anchor: '98%',
                labelWidth: 120,
                minWidth: 250,
                xtype: 'pagingcombo',
                style: 'box-shadow: none;',
                labelStyle: 'font-weight:700;'
            },
            items: [
                me.createFromField(),
                me.createToField(),
                me.createAuthorizationStatusField(),
                me.createShopField(),
                me.createFormatField(),
            ]
        });
        return me.exportForm;
    },
    
    createFromField: function() {
        var me = this;
        return Ext.create('Ext.form.field.Date', {
            name: 'from',
            fieldLabel: '{s name=payiteasycw/d98a07f84921b24ee30f86fd8cd85c3c}From{/s}',
            submitFormat: 'd.m.Y'
        });
    },

    createToField: function() {
        var me = this;
        return Ext.create('Ext.form.field.Date', {
            name: 'to',
            fieldLabel: '{s name=payiteasycw/01b6e20344b68835c5ed1ddedf20d531}To{/s}',
            submitFormat: 'd.m.Y'
        });
    },

    createAuthorizationStatusField: function() {
        var me = this;

        return Ext.create('Ext.form.field.ComboBox', {
            name: 'authorizationStatus',
            queryMode: 'local',
            store: Ext.create('Ext.data.Store', {
                fields:	['value', 'text'],
                data: [
                	{ value: 'pending', text:  '{s name=payiteasycw/7c6c2e5d48ab37a007cbf70d3ea25fa4}Pending{/s}' },
                	{ value: 'successful', text:  '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}' },
                	{ value: 'failed', text:  '{s name=payiteasycw/26934eb377001f66e37289a5c93fe284}Failed{/s}' }
                ]
    		}),
            valueField: 'value',
            displayField: 'text',
            emptyText: '{s name=payiteasycw/1cbdb2953d92c3e10c8e2deeda188cee}Show all{/s}',
            fieldLabel: '{s name=payiteasycw/9acb44549b41563697bb490144ec6258}Status{/s}'
        });
    },

    createShopField: function() {
        var me = this;

        return Ext.create('Ext.form.field.ComboBox', {
            name: 'shopId',
            store: Ext.create('Shopware.store.Shop', { pageSize: 7 }),
            valueField: 'id',
            pageSize: 7,
            queryMode: 'remote',
            displayField: 'name',
            emptyText: '{s name=payiteasycw/1cbdb2953d92c3e10c8e2deeda188cee}Show all{/s}',
            fieldLabel: '{s name=payiteasycw/fb54f3c5992b96d001bb16e8e92d968d}Shop{/s}'
        });
    },
    
    createFormatField: function() {
        var me = this;

        me.formatField = Ext.create('Ext.form.field.ComboBox', {
            name: 'format',
            queryMode: 'local',
            store: Ext.create('Ext.data.Store', {
                fields:	['value', 'text'],
                data: [
                	{ value: 'csv', text:  '{s name=payiteasycw/628cb5675ff524f3e719b7aa2e88fe3f}CSV{/s}' },
                	{ value: 'excel', text:  '{s name=payiteasycw/bf57c906fa7d2bb66d07372e41585d96}Excel{/s}' },
                	{ value: 'xml', text:  '{s name=payiteasycw/0f635d0e0f3874fff8b581c132e6c7a7}XML{/s}' }
                ]
    		}),
    		listeners: {
                'afterrender': function () {
                    this.setValue(this.store.getAt('0').get('value'));
                }
            },
    		forceSelection: true,
            allowBlank: false,
            editable: false,
            valueField: 'value',
            displayField: 'text',
            fieldLabel: '{s name=payiteasycw/1ddcb92ade31c8fbd370001f9b29a7d9}Format{/s}'
        });
        return me.formatField;
    },
    
    createExportButtons: function() {
        var me = this;

        return Ext.create('Ext.container.Container', {
            style: 'margin-top: 10px;',
            items: [
				{
				    xtype: 'button',
				    cls: 'small secondary',
				    text: '{s name=payiteasycw/86266ee937d97f812a8e57d22b62ee29}Reset{/s}',
				    handler: function() {
				    	me.exportForm.getForm().reset();
				    	me.formatField.setValue(me.formatField.store.getAt('0').get('value'));
				    }
				},
                {
                    xtype: 'button',
                    text: '{s name=payiteasycw/b2507468f95156358fa490fd543ad2f0}Export{/s}',
                    style: 'float: right;',
                    cls: 'primary small',
                    handler: function() {
                        var form = me.exportForm.getForm();
                        if (!form.isValid()) {
                            return;
                        }

                        form.submit({
                            method: 'GET',
                            url: '{url module=backend controller=PayiteasycwTransactions action=export}'
                        });
                    }
                }
            ]
        });
    },
});
// {/block}
