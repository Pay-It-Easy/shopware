<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_InvoiceItems
{
	public static function collectInvoiceItemsByOrder(Shopware\Models\Order\Order $order)
	{
		$items = array();

		$details = $order->getDetails();
		foreach ($details as $detail) {
			switch ($detail->getMode()) {
				case 0:
				case 1:
					$type = Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_PRODUCT;
					break;
				case 2:
				case 3:
				case 10:
					$type = Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_DISCOUNT;
					break;
				default:
					$type = Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_PRODUCT;
					break;
			}

			$invoiceAmount = round(abs($detail->getPrice()) * $detail->getQuantity(), 2);
			if ($order->getNet() && !$order->getTaxFree()) {
				$invoiceAmount = $invoiceAmount / 100 * (100 + $detail->getTaxRate());
			}
			$items[] = new Customweb_Payment_Authorization_DefaultInvoiceItem($detail->getArticleNumber(), $detail->getArticleName(), $detail->getTaxRate(), $invoiceAmount, $detail->getQuantity(), $type);
		}

		if ($order->getInvoiceShipping() > 0) {
			$tax = ($order->getInvoiceShipping() - $order->getInvoiceShippingNet());
			$taxRate = self::correctTaxRate($tax / $order->getInvoiceShippingNet() * 100);

			try {
				$shippingMethod = $order->getDispatch()->getName();
			} catch (Exception $e) {
				$shippingMethod = Customweb_I18n_Translation::__('Shipping');
			}
			$items[] = new Customweb_Payment_Authorization_DefaultInvoiceItem('shipping', $shippingMethod, $taxRate, $order->getInvoiceShipping(), 1, Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_SHIPPING);
		}

		return Customweb_Util_Invoice::cleanupLineItems($items, $order->getInvoiceAmount(), $order->getCurrency());
	}

	public static function collectInvoiceItemsByBasket(array $basket)
	{
		$items = array();

		$details = $basket['content'];
		foreach ($details as $detail) {
			switch ($detail['modus']) {
				case 0:
				case 1:
					$type = Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_PRODUCT;
					break;
				case 2:
				case 3:
				case 10:
					$type = Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_DISCOUNT;
					break;
				default:
					$type = Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_PRODUCT;
					break;
			}

			$invoiceAmount = round(abs(str_replace(',', '.', $detail['price'])) * $detail['quantity'], 2);
			$items[] = new Customweb_Payment_Authorization_DefaultInvoiceItem($detail['ordernumber'], $detail['articlename'], $detail['tax_rate'], $invoiceAmount, $detail['quantity'], $type);
		}

		$shippingCosts = floatval($basket['sShippingcostsWithTax']);
		if ($shippingCosts > 0) {
			$taxRate = floatval($basket['sShippingcostsTax']);
			$shippingMethod = Customweb_I18n_Translation::__('Shipping');
			$items[] = new Customweb_Payment_Authorization_DefaultInvoiceItem('shipping', $shippingMethod, $taxRate, $shippingCosts, 1, Customweb_Payment_Authorization_DefaultInvoiceItem::TYPE_SHIPPING);
		}

		$currencyId = Shopware()->Session()->sBasketCurrency;
		if (empty($currencyId)) {
			$currencyId = Shopware()->Shop()->getCurrency()->getId();
		}
		$currency = Shopware()->Models()->find('Shopware\Models\Shop\Currency', $currencyId);
		return Customweb_Util_Invoice::cleanupLineItems($items, $basket['sAmount'], $currency->getCurrency());
	}

	private static function correctTaxRate($rate)
	{
		if ($rate == 0) {
			return 0;
		}
		$matchingTaxRate = null;
		$minDistance = null;
		$taxes = Shopware()->Models()->getRepository('Shopware\Models\Tax\Tax')->findAll();
		foreach ($taxes as $tax) {
			$taxRate = $tax->getTax();
			$distance = abs($taxRate - $rate);
			if ($minDistance == null || $distance < $minDistance) {
				$matchingTaxRate = $taxRate;
				$minDistance = $distance;
			}
		}
		$taxRules = Shopware()->Models()->getRepository('Shopware\Models\Tax\Rule')->findAll();
		foreach ($taxRules as $taxRule) {
			$taxRate = $taxRule->getTax();
			$distance = abs($taxRate - $rate);
			if ($minDistance == null || $distance < $minDistance) {
				$matchingTaxRate = $taxRate;
				$minDistance = $distance;
			}
		}
		return $matchingTaxRate;
	}
}