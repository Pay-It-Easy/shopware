<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class represents an address.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_Request extends Customweb_Core_Http_ContextRequest
{

	/**
	 * @var array
	 */
	private static $post = array();
	
	/**
	 * @var array
	 */
	private static $get = array();
	
	/**
	 * @var PayItEasyCw_Components_Request
	 */
	private static $instance = null;
	
	/**
	 * Store $_POST and $_GET data.
	 */
	public static function storeData()
	{
		self::$post = $_POST;
		self::$get = $_GET;
	}
	
	/**
	 * @return PayItEasyCw_Components_Request
	 */
	public static function getInstance() {
		if (self::$instance === null) {
			self::$instance = new PayItEasyCw_Components_Request();
		}
		return self::$instance;
	}
	
	public function getParsedQuery() {
		return self::$get;
	}
	
	
	public function getParsedBody() {
		return self::$post;
	}
	
	public function getParameters() {
		return array_merge(self::$get, self::$post);
	}
}