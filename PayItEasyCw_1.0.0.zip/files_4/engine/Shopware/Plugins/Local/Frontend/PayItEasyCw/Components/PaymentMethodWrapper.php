<?php
/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */
use Shopware\Models\Payment\Payment;
use Shopware\Models\Order\Order;

/**
 * This class wraps a payment method to add custom behaviour.
 *
 * @see Customweb_Payment_Authorization_IPaymentMethod
 * @author Simon Schurter
 */
class PayItEasyCw_Components_PaymentMethodWrapper implements Customweb_Payment_Authorization_IPaymentMethod {
	/**
	 *
	 * @var integer
	 */
	private $paymentId;

	/**
	 *
	 * @var string
	 */
	private $paymentMethodName = "";

	/**
	 *
	 * @var string
	 */
	private $paymentMethodDisplayName = "";

	/**
	 *
	 * @var Shopware\Models\Payment\Payment
	 */
	private $paymentMethod = null;

	/**
	 * Create a new payment wrapper for the specified payment method.
	 *
	 * @param Payment $paymentMethod
	 */
	public function __construct(Payment $paymentMethod){
		$this->paymentId = $paymentMethod->getId();
		$this->paymentMethod = $paymentMethod;
		$this->paymentMethodDisplayName = $paymentMethod->getDescription();
		$this->paymentMethodName = substr($paymentMethod->getName(), strlen('payiteasycw_'));
	}

	public function getPaymentMethodName(){
		return $this->paymentMethodName;
	}

	public function getPaymentMethodDisplayName(){
		return $this->paymentMethodDisplayName;
	}

	public function getPaymentMethod(){
		return $this->paymentMethod;
	}

	public function getPaymentMethodConfigurationValue($key, $languageCode = null){
		$languageCode = (string) $languageCode;

		if ($languageCode == null) {
			try {
				$shopId = Shopware()->Shop()->getId();
			}
			catch (Exception $e) {
				$builder = Shopware()->Models()->createQueryBuilder();
				$builder->select('u.id')->from('Shopware\Models\Shop\Shop', 'u')->where('u.active = 1 AND u.default = 1');
				$single = $builder->getQuery()->getSingleResult();
				$shopId = $single['id'];
			}
		}
		elseif (is_numeric($languageCode)) {
			$shopId = $languageCode;
		}
		else {
			$builder = Shopware()->Models()->createQueryBuilder();
			$builder->select('u.id')->from('Shopware\Models\Shop\Locale', 'u')->where('u.locale = ?1')->setParameter(1, $languageCode);
			$single = $builder->getQuery()->getSingleResult();
			$localeId = $single['id'];

			$builder = Shopware()->Models()->createQueryBuilder();
			$builder->select('u.id')->from('Shopware\Models\Shop\Shop', 'u')->where('u.locale = ?1')->setParameter(1, $localeId);
			$single = $builder->getQuery()->getSingleResult();
			$shopId = $single['id'];
		}
		return PayItEasyCw_Helpers_Payment_Config::getConfigValue($this->paymentId, $key, $shopId);
	}

	public function existsPaymentMethodConfigurationValue($key, $languageCode = null){
		return ($this->getPaymentMethodConfigurationValue($key, $languageCode) != null);
	}

	public function getOrderContext($orderId){
		return new PayItEasyCw_Components_OrderContext($orderId, $this->paymentId);
	}

	public function getTransactionContext(PayItEasyCw_Entities_Transaction $transaction, Order $order, $aliasTransactionId = NULL){
		return new PayItEasyCw_Components_TransactionContext($transaction, $order, $this->paymentMethod, $aliasTransactionId);
	}

	public function createTransaction($order){
		$transaction = new PayItEasyCw_Entities_Transaction();
		$transaction->setTemporaryOrderId($order->getId())->setCustomerId($order->getCustomer()->getId())->setPaymentMethod($this->paymentId);
		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

		return $transaction;
	}

	public function getFailedTransaction($failedTransactionId){
		$failedTransaction = PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_Transaction',
				$failedTransactionId);
		if (!($failedTransaction instanceof PayItEasyCw_Entities_Transaction)) {
			return null;
		}
		if ($failedTransaction->getCustomerId() !== $order->getCustomer()->getId()) {
			throw new Exception("Access to this transaction is not allowed for you.");
		}
		return $failedTransaction;
	}

	public function getNewTransactionContext(Order $order, $aliasTransactionId = NULL, $failedTransactionId = NULL){
		PayItEasyCw_Components_ConfigurationAdapter::setShop($order->getLanguageSubShop()->getId());

		$transaction = $this->createTransaction($order);
		$transactionContext = $this->getTransactionContext($transaction, $order, $aliasTransactionId);
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($transactionContext->getOrderContext());

		$failedTransactionObject = NULL;
		if ($failedTransactionId !== NULL) {
			$failedTransactionObject = $this->getFailedTransaction($failedTransactionId)->getTransactionObject();
		}

		$transactionObject = $adapter->createTransaction($transactionContext, $failedTransactionObject);
		$transaction->setTransactionObject($transactionObject);
		$transaction->setSessionData(
				array(
					'session' => $_SESSION,
					'shopId' => Shopware()->Shop()->getId(),
					'currency' => Shopware()->Shop()->getCurrency()->toArray(),
					'id' => session_id()
				));

		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

		return $this->getTransactionContext($transaction, $order, $aliasTransactionId);
	}

	public function generateHiddenFormParameters(PayItEasyCw_Components_TransactionContext $transactionContext){
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($transactionContext->getOrderContext());
		if (method_exists($adapter, 'getHiddenFormFields')) {
			return $adapter->getHiddenFormFields($transactionContext->getTransaction()->getTransactionObject());
		}
		return array();
	}

	public function generateVisibleFormFields(PayItEasyCw_Components_OrderContext $orderContext, PayItEasyCw_Entities_PaymentCustomerContext $paymentCustomerContext, $aliasTransaction = NULL, $failedTransactionId = null){
		
		$arguments = array(
			'failedTransactionId' => $failedTransactionId,
 			'aliasTransaction' => $aliasTransaction,
 			'orderContext' => $orderContext,
 			'paymentCustomerContext' => $paymentCustomerContext,
 		);
		return Customweb_Licensing_PayItEasyCw_License::run('966vibrso73nb589', $this, $arguments);
	}

	public function call_441177176pcr0orq() {
		$arguments = func_get_args();
		$method = $arguments[0];
		$call = $arguments[1];
		$parameters = array_slice($arguments, 2);
		if ($call == 's') {
			return call_user_func_array(array(get_class($this), $method), $parameters);
		}
		else {
			return call_user_func_array(array($this, $method), $parameters);
		}
		
		
	}


	public function generateFormActionUrl(PayItEasyCw_Components_TransactionContext $transactionContext){
		
		$arguments = array(
			'transactionContext' => $transactionContext,
 		);
		return Customweb_Licensing_PayItEasyCw_License::run('soh99ptqffk5b523', $this, $arguments);
	}

	public function call_vqai423bmtr5n9gs() {
		$arguments = func_get_args();
		$method = $arguments[0];
		$call = $arguments[1];
		$parameters = array_slice($arguments, 2);
		if ($call == 's') {
			return call_user_func_array(array(get_class($this), $method), $parameters);
		}
		else {
			return call_user_func_array(array($this, $method), $parameters);
		}
		
		
	}


	public function generateAliasSelect(PayItEasyCw_Components_OrderContext $orderContext){
		
		$arguments = array(
			'orderContext' => $orderContext,
 		);
		return Customweb_Licensing_PayItEasyCw_License::run('4vski2ie8olr8blo', $this, $arguments);
	}

	public function call_66quarsdmn5iajjs() {
		$arguments = func_get_args();
		$method = $arguments[0];
		$call = $arguments[1];
		$parameters = array_slice($arguments, 2);
		if ($call == 's') {
			return call_user_func_array(array(get_class($this), $method), $parameters);
		}
		else {
			return call_user_func_array(array($this, $method), $parameters);
		}
		
		
	}
	public function generateJavascriptForAjax(PayItEasyCw_Components_TransactionContext $transactionContext){
		$transaction = $transactionContext->getTransaction();
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($transactionContext->getOrderContext());

		if ($adapter instanceof Customweb_Payment_Authorization_Ajax_IAdapter) {
			$fileUrl = $adapter->getAjaxFileUrl($transaction->getTransactionObject());
			$function = $adapter->getJavaScriptCallbackFunction($transaction->getTransactionObject());

			PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

			$data = array(
				'ajaxScriptUrl' => (string) $fileUrl,
				'ajaxSubmitCallback' => $function
			);
		}
		else {
			$data = array(
				'error' => Customweb_I18n_Translation::__('Ajax authorization not supported.')
			);
		}

		return $data;
	}

	public function getAuthorizationMethodName(PayItEasyCw_Components_OrderContext $orderContext){
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($orderContext);
		return $adapter->getAuthorizationMethodName();
	}

	public function loadAliasForCustomer(PayItEasyCw_Components_OrderContext $orderContext){
		/* @var $handler Customweb_Payment_Alias_Handler */
		$handler = PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_Alias_Handler');
		return $handler->getAliasTransactions($orderContext);
	}

	public function getIframeUrl(PayItEasyCw_Components_TransactionContext $transactionContext, $parameters){
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($transactionContext->getOrderContext());
		return $adapter->getIframeUrl($transactionContext->getTransaction()->getTransactionObject(), $parameters);
	}

	public function getIframeHeight(PayItEasyCw_Components_TransactionContext $transactionContext, $parameters){
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($transactionContext->getOrderContext());
		return $adapter->getIframeHeight($transactionContext->getTransaction()->getTransactionObject(), $parameters);
	}

	public function getWidgetHtml(PayItEasyCw_Components_TransactionContext $transactionContext, $parameters){
		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($transactionContext->getOrderContext());
		return $adapter->getWidgetHTML($transactionContext->getTransaction()->getTransactionObject(), $parameters);
	}

	public function getBreakoutUrl(PayItEasyCw_Components_TransactionContext $transactionContext){
		if ($transactionContext->getTransaction()->getTransactionObject()->isAuthorizationFailed()) {
			return Customweb_Util_Url::appendParameters($transactionContext->getFailedUrl(), $transactionContext->getCustomParameters());
		}
		else {
			return Customweb_Util_Url::appendParameters($transactionContext->getSuccessUrl(), $transactionContext->getCustomParameters());
		}
	}

	public function authorizeTransaction(PayItEasyCw_Entities_Transaction $transaction){
		$orderHelper = new PayItEasyCw_Components_Order($transaction);
		if (!PayItEasyCw_Helpers_Util::isCreateOrderBefore()) {
			$orderHelper->createOrder();
		}
		else {
			$orderHelper->sendOrderEmail();
			$orderHelper->deleteTemporaryOrder();
			$orderHelper->deleteBasket();
		}

		$transaction->setSessionData(null);
		$transaction->setEmailData(null);
	}

	protected function getOrderStatus($statusId){
		return Shopware()->Models()->find('Shopware\Models\Order\Status', $statusId);
	}

	/**
	 * The transaction is captured with the specified amount.
	 *
	 * @param Transaction $transaction
	 * @param Customweb_Payment_Authorization_IInvoiceItem[] $items
	 * @param boolean $close
	 */
	public function capture(PayItEasyCw_Entities_Transaction $transaction, $items = null, $close = true){
		
		PayItEasyCw_Components_ConfigurationAdapter::setShop($transaction->getShopId());
		$adapter = PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_BackendOperation_Adapter_Service_ICapture');
		if ($transaction->getTransactionObject()->isCapturePossible()) {
			if ($transaction->getTransactionObject()->isPartialCapturePossible() && $items != null) {
				$adapter->partialCapture($transaction->getTransactionObject(), $items, $close);
			}
			else {
				$adapter->capture($transaction->getTransactionObject());
			}
		}
		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

		if (!$transaction->getTransactionObject()->isCaptured()) {
			throw new Exception(
					'The invoice could not be captured and processed. Reason: ' . end($transaction->getTransactionObject()->getErrorMessages()));
		}
		
	}

	/**
	 * Refund money
	 *
	 * @param Transaction $transaction
	 * @param Customweb_Payment_Authorization_IInvoiceItem[] $items
	 * @param boolean $close
	 */
	public function refund(PayItEasyCw_Entities_Transaction $transaction, $items = null, $close = true){
		
		PayItEasyCw_Components_ConfigurationAdapter::setShop($transaction->getShopId());
		$adapter = PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_BackendOperation_Adapter_Service_IRefund');
		if ($transaction->getTransactionObject()->isRefundPossible()) {
			if ($transaction->getTransactionObject()->isPartialRefundPossible() && $items != null) {
				$adapter->partialRefund($transaction->getTransactionObject(), $items, $close);
			}
			else {
				$adapter->refund($transaction->getTransactionObject());
			}
		}
		else {
			throw new Exception('No refund possible.');
		}
		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);
		
	}

	/**
	 * Cancel payment
	 *
	 * @param Transaction $transaction
	 */
	public function cancel(PayItEasyCw_Entities_Transaction $transaction){
		
		PayItEasyCw_Components_ConfigurationAdapter::setShop($transaction->getShopId());
		$adapter = PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_BackendOperation_Adapter_Service_ICancel');
		if ($transaction->getTransactionObject()->isCancelPossible()) {
			$adapter->cancel($transaction->getTransactionObject());
		}
		PayItEasyCw_Helpers_Util::getEntityManager()->persist($transaction);

		if (!$transaction->getTransactionObject()->isCancelled()) {
			throw new Exception('Canceling of this payment not possible. Reason: ' . end($transaction->getTransactionObject()->getErrorMessages()));
		}
		
	}

	
	public function finishRecurring(PayItEasyCw_Entities_Transaction $transaction, Order $order){
		$query = sprintf(
				'UPDATE s_order SET transactionID = \'payiteasycw-' . $transaction->getTransactionId() . '\' WHERE id = ' . (int) $order->getId());
		Shopware()->Db()->query($query);
	}

	protected function preValidate(){
		$order = PayItEasyCw_Helpers_Util::getOrCreateTemporaryOrder();
		if (!($order instanceof Shopware\Models\Order\Order)) {
			return;
		}

		PayItEasyCw_Components_ConfigurationAdapter::setShop($order->getLanguageSubShop()->getId());

		$orderContext = $this->getOrderContext($order->getId());
		$paymentContext = PayItEasyCw_Helpers_Util::loadPaymentCustomerContextByCustomer($order->getCustomer()->getId());

		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($orderContext);
		try {
			$adapter->preValidate($orderContext, $paymentContext);
		}
		catch (Exception $e) {
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($paymentContext);
			throw $e;
		}

		PayItEasyCw_Helpers_Util::getEntityManager()->persist($paymentContext);
	}

	/**
	 * Validate payment method
	 *
	 * @param int $paymentId
	 * @throws Exception
	 */
	public function validate(){
		$session = Shopware()->Session();
		if (!empty(Shopware()->Config()->PremiumShippingNoOrder) && (empty($session['sDispatch']) || empty($session['sCountry']))) {
			throw new Exception(Customweb_I18n_Translation::__('Please select a shipping method.'));
		}

		$order = PayItEasyCw_Helpers_Util::getOrCreateTemporaryOrder();
		if (!($order instanceof Shopware\Models\Order\Order)) {
			return;
		}

		PayItEasyCw_Components_ConfigurationAdapter::setShop($order->getLanguageSubShop()->getId());

		$orderContext = $this->getOrderContext($order->getId());
		$paymentContext = PayItEasyCw_Helpers_Util::loadPaymentCustomerContextByCustomer($order->getCustomer()->getId());

		$adapter = PayItEasyCw_Helpers_Util::getAuthorizationAdapterByContext($orderContext);
		try {
			$adapter->validate($orderContext, $paymentContext, PayItEasyCw_Components_Request::getInstance()->getParameters());
		}
		catch (Exception $e) {
			PayItEasyCw_Helpers_Util::getEntityManager()->persist($paymentContext);
			throw $e;
		}

		PayItEasyCw_Helpers_Util::getEntityManager()->persist($paymentContext);
	}

	/**
	 * Validate payment method before showing the list
	 *
	 * @param int $paymentId
	 * @param int $amount
	 * @return boolean
	 */
	public function validateBefore($amount){
		$minOrderTotal = $this->getPaymentMethodConfigurationValue('min_order_total');
		if (!empty($minOrderTotal) && is_numeric($minOrderTotal) && $amount < $minOrderTotal) {
			return false;
		}

		$maxOrderTotal = $this->getPaymentMethodConfigurationValue('max_order_total');
		if (!empty($maxOrderTotal) && is_numeric($maxOrderTotal) && $amount > $maxOrderTotal) {
			return false;
		}

		try {
			Shopware_Plugins_Frontend_PayItEasyCw_Bootstrap::$paymentValidationDisabled = true;
			$this->preValidate();
			Shopware_Plugins_Frontend_PayItEasyCw_Bootstrap::$paymentValidationDisabled = false;
		}
		catch (Exception $e) {
			Shopware_Plugins_Frontend_PayItEasyCw_Bootstrap::$paymentValidationDisabled = false;
			return false;
		}

		return true;
	}

	/**
	 * Validate payment method after selection
	 *
	 * @param int $paymentId
	 */
	public function validateAfter(){
		
		$arguments = null;
		return Customweb_Licensing_PayItEasyCw_License::run('t5pi8damttotvevo', $this, $arguments);
	}

	public function call_bc1qnop2hqass234() {
		$arguments = func_get_args();
		$method = $arguments[0];
		$call = $arguments[1];
		$parameters = array_slice($arguments, 2);
		if ($call == 's') {
			return call_user_func_array(array(get_class($this), $method), $parameters);
		}
		else {
			return call_user_func_array(array($this, $method), $parameters);
		}
		
		
	}
}
