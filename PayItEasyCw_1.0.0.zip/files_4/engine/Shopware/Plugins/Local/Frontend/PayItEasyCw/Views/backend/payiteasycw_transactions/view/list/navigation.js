//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/view/list/navigation"}
Ext.define('Shopware.apps.PayiteasycwTransactions.view.list.Navigation', {
    extend:'Ext.container.Container',

    layout:'accordion',
    cls:Ext.baseCSSPrefix + 'transaction-list-navigation',
    width:300,
    collapsed:false,
    collapsible:true,

    initComponent:function() {
        var me = this;

        me.items = me.getPanels();
        me.callParent(arguments);
    },

    getPanels: function() {
        var me = this;

        return [
            Ext.create('Shopware.apps.PayiteasycwTransactions.view.list.Filter', {}),
            Ext.create('Shopware.apps.PayiteasycwTransactions.view.list.Export', {})
        ];
    },
});
//{/block}