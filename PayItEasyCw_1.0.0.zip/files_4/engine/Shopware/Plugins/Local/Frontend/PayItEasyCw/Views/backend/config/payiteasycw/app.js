/**
 * Load required files.
 * 
 * @author Simon Schurter
 */
//{block name="backend/config/application" append}
	//{include file="backend/config/payiteasycw/view/element/mediafield.js"}    
//{/block}