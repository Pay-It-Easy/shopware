//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_base/controller/transaction"}
Ext.define('Shopware.apps.PayiteasycwBase.controller.Transaction', {
    extend:'Ext.app.Controller',

    init:function () {
        var me = this;

        me.control({
        	
            
            'payiteasycw-base-transaction-captures payiteasycw-base-transaction-captures-form': {
            	captureTransaction: me.onCaptureTransaction,
            	cancelTransaction: me.onCancelTransaction,
            	updateFields: me.onUpdateFields
            },
            
            
            'payiteasycw-base-transaction-refunds payiteasycw-base-transaction-refunds-form': {
            	refundTransaction: me.onRefundTransaction,
            	updateFields: me.onUpdateFields
            }
            
        });

        me.callParent(arguments);
    },
    
    
    
    
    onCaptureTransaction: function(values, record, view) {
    	var me = this,
			store = me.subApplication.getStore('Shopware.apps.PayiteasycwBase.store.Transaction'),
			window = view.up('window');
    	
    	if (record.get('capturePossible')) {
    		window.setLoading(true);
	    	Ext.Ajax.request({
	    		url: '{url controller="PayiteasycwBaseTransaction" action="capture"}',
	    		params: values,
	    		success: function(response) {
	    			var data = Ext.decode(response.responseText);
	    			var title = '{s name=payiteasycw/cb5e100e5a9a3e7f6d1fd97512215282}Error{/s}';
	    			if (data.success) {
	                    store.load({
	                    	params: {
	                    		transactionId: record.get('transactionId')
	                    	},
	                    	callback:function (records) {
	                    		window.updateRecord(records[0]);
	                    		window.setLoading(false);
	                    	}
	                    });
	    				title = '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}';
	    			} else {
	    				window.updateRecord(record);
	    				window.setLoading(false);
	    			}
	                Shopware.Notification.createGrowlMessage(title, data.message, '{s name=payiteasycw/f4d5b76a2418eba4baeabc1ed9142b54}Transaction{/s}');
	    		}
	    	});
    	}
    },
    
    
    
    onRefundTransaction: function(values, record, view) {
    	var me = this,
			store = me.subApplication.getStore('Shopware.apps.PayiteasycwBase.store.Transaction'),
			window = view.up('window');
    	
    	if (record.get('refundPossible')) {
    		window.setLoading(true);
	    	Ext.Ajax.request({
	    		url: '{url controller="PayiteasycwBaseTransaction" action="refund"}',
	    		params: values,
	    		success: function(response) {
	    			var data = Ext.decode(response.responseText);
	    			var title = '{s name=payiteasycw/cb5e100e5a9a3e7f6d1fd97512215282}Error{/s}';
	    			if (data.success) {
	                    store.load({
	                    	params: {
	                    		transactionId: record.get('transactionId')
	                    	},
	                    	callback:function (records) {
	                    		window.updateRecord(records[0]);
	                    		window.setLoading(false);
	                    	}
	                    });
	    				title = '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}';
	    			} else {
	    				window.updateRecord(record);
	    				window.setLoading(false);
	    			}
	                Shopware.Notification.createGrowlMessage(title, data.message, '{s name=payiteasycw/f4d5b76a2418eba4baeabc1ed9142b54}Transaction{/s}');
	    		}
	    	});
    	}
    },
    
    
    
    onCancelTransaction: function(values, record, view) {
    	var me = this,
			store = me.subApplication.getStore('Shopware.apps.PayiteasycwBase.store.Transaction'),
			window = view.up('window');
    	
    	if (record.get('cancelPossible')) {
    		window.setLoading(true);
	    	Ext.Ajax.request({
	    		url: '{url controller="PayiteasycwBaseTransaction" action="cancel"}',
	    		params: values,
	    		success: function(response) {
	    			var data = Ext.decode(response.responseText);
	    			var title = '{s name=payiteasycw/cb5e100e5a9a3e7f6d1fd97512215282}Error{/s}';
	    			if (data.success) {
	                    store.load({
	                    	params: {
	                    		transactionId: record.get('transactionId')
	                    	},
	                    	callback:function (records) {
	                    		window.updateRecord(records[0]);
	                    		window.setLoading(false);
	                    	}
	                    });
	    				title = '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}';
	    			} else {
	    				window.updateRecord(record);
	    				window.setLoading(false);
	    			}
	                Shopware.Notification.createGrowlMessage(title, data.message, '{s name=payiteasycw/f4d5b76a2418eba4baeabc1ed9142b54}Transaction{/s}');
	    		}
	    	});
    	}
    },
    
    
    onUpdateFields: function(element, record, view) {
    	var me = this;
    	
    	var decimalPlaces = record.get('decimalPlaces');
    	
    	var taxRateField = view.getComponent('form-taxRate-' + element.row).down();
    	var quantityField = view.getComponent('form-qty-' + element.row).down();
    	var amountExclTaxField = view.getComponent('form-amountExclTax-' + element.row).down();
    	var amountInclTaxField = view.getComponent('form-amountInclTax-' + element.row).down();
    	var totalAmountField = view.getComponent('form-totalAmount').down();
    
		var taxRate = parseFloat(taxRateField.getValue());

		var quantityBefore = parseFloat(quantityField.valueBeforeChange);
		var quantityValue = quantityField.getValue();
		if (quantityValue == '' || isNaN(quantityValue)) {
			var quantity = quantityBefore;
		} else {
			var quantity = parseFloat(quantityValue);
		}
		
		var priceExcludingBefore = parseFloat(amountExclTaxField.valueBeforeChange);
		var priceExcludingValue = amountExclTaxField.getValue();
		if (priceExcludingValue == '' || isNaN(priceExcludingValue)) {
			var priceExcluding = priceExcludingBefore;
		} else {
			var priceExcluding = parseFloat(priceExcludingValue);
		}

		var priceIncludingBefore = parseFloat(amountInclTaxField.valueBeforeChange);
		var priceIncludingValue = amountInclTaxField.getValue();
		if (priceIncludingValue == '' || isNaN(priceIncludingValue)) {
			var priceIncluding = priceIncludingBefore;
		} else {
			var priceIncluding = parseFloat(priceIncludingValue);
		}
		
		if (element == quantityField) {
			if (quantityBefore == 0) {
				quantityBefore = parseFloat(quantityField.valueOriginal);
				priceExcludingBefore = parseFloat(amountExclTaxField.valueOriginal);
			}
			var pricePerItemExcluding = parseFloat(priceExcludingBefore / quantityBefore);
			priceExcluding = quantity * pricePerItemExcluding;
			priceIncluding = (taxRate / 100 + 1) * priceExcluding;
		}
		else if (element == amountExclTaxField) {
			priceIncluding = (taxRate / 100 + 1) * priceExcluding;
		}
		else if (element == amountInclTaxField) {
			priceExcluding = priceIncluding / (taxRate / 100 + 1);
		}
		
		quantity = quantity.toFixed(0);
		priceExcluding = priceExcluding.toFixed(decimalPlaces);
		priceIncluding = priceIncluding.toFixed(decimalPlaces);
			
		quantityField.setValue(quantity);
		amountExclTaxField.setValue(priceExcluding);
		amountInclTaxField.setValue(priceIncluding);
		
		quantityField.valueBeforeChange = quantity;
		amountExclTaxField.valueBeforeChange = priceExcluding;
		amountInclTaxField.valueBeforeChange = priceIncluding;
		
		// Update total
		var totalAmount = 0;
		for (var row = 0; row < element.totalRows; row++) {
			totalAmount += parseFloat(view.getComponent('form-amountInclTax-' + row).down().getValue());
		}
		
		totalAmountField.setValue(totalAmount.toFixed(decimalPlaces));
    }
});
//{/block}