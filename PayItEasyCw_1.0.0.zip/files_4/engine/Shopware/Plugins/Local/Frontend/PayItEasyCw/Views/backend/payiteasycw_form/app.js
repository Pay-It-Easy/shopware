//{block name="backend/payiteasycw_form/app"}
Ext.define('Shopware.apps.PayiteasycwForm', {
    extend:'Enlight.app.SubApplication',
 
    name:'Shopware.apps.PayiteasycwForm',
 
    bulkLoad: true,
    
    loadPath: '{url controller="PayiteasycwForm" action=load}',
 
    controllers: ['Form', 'Main'],
 
    stores: ['Form'],
    
    models: ['Form'],
 
    views: ['main.Window', 'form.Tree', 'form.Panel'],
 
    launch: function() {
        var me = this,
            mainController = me.getController('Main');
 
        return mainController.mainWindow;
    }
});
//{/block}