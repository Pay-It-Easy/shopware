<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Backend_PayiteasycwForm extends Shopware_Controllers_Backend_ExtJs
{
	public function preDispatch()
	{
		if (in_array($this->Request()->getActionName(), array('loadForm', 'saveForm'))) {
			//$this->Front()->Plugins()->Json()->setRenderer();
		}
		else {
			parent::preDispatch();
		}
	}
	
    public function indexAction()
    {
        $this->View()->loadTemplate("backend/payiteasycw_form/app.js");
    }
 
    public function getFormsAction()
    {
    	$results = array();
    	try {
	    	$forms = $this->getFormAdapter()->getForms();
	    	foreach ($forms as $form) {
	    		$results[] = array(
	    			'id' => $form->getMachineName(),
	    			'text' => (string)$form->getTitle(),
	    			'formUrl' => PayItEasyCw_Helpers_Util::getUrl(array(
	    				'controller' => 'PayiteasycwForm',
	    				'action' => 'loadForm',
	    				'formName' => $form->getMachineName(),
	    				'shop' => '_shop_'
	    			)),
	    			'leaf' => true
	    		);
	    	}
    	} catch (Exception $e) {}
	    $this->View()->assign(array('success'=>true, 'data'=>$results));
    }
    
    public function getShopsAction()
    {
		$results = array();
		$repository = Shopware()->Models()->getRepository('Shopware\Models\Shop\Shop');
		$shops = $repository->findAll();
		foreach ($shops as $shop) {
			$results[] = array(
				'id' => $shop->getId(),
				'name' => $shop->getName()
			);
		}
    	$this->View()->assign(array('success'=>true, 'data'=>$results));
    }
    
    public function loadFormAction()
    {
    	PayItEasyCw_Components_ConfigurationAdapter::setShop($this->Request()->getParam('shop'));
    	$form = $this->getActiveForm();
    	if ($form->isProcessable()) {
    		$form = new Customweb_Form($form);
    		$form->setTargetUrl(PayItEasyCw_Helpers_Util::getUrl(array(
    			'controller' => 'PayiteasycwForm',
    			'action' => 'saveForm',
    			'formName' => $form->getMachineName(),
    			'shop' => $this->Request()->getParam('shop')
    		)));
    		$form->setRequestMethod(Customweb_Form::REQUEST_METHOD_POST);
    	}
    	$this->View()->loadTemplate('backend/payiteasycw_form/form.tpl');
    	$renderer = new PayItEasyCw_Components_BackendFormRenderer();
    	$this->View()->assign('formHtml', $renderer->renderForm($form));
    }
    
    public function saveFormAction()
    {
    	PayItEasyCw_Components_ConfigurationAdapter::setShop($this->Request()->getParam('shop'));
   		$form = $this->getActiveForm();

		$params = PayItEasyCw_Components_Request::getInstance()->getParameters();
		if (!isset($params['button'])) {
			throw new Exception("No button returned.");
		}
		$pressedButton = null;
		foreach ($params['button'] as $buttonName => $value) {
			foreach ($form->getButtons() as $button) {
				if ($button->getMachineName() == $buttonName) {
					$pressedButton = $button;
				}
			}
		}
		if ($pressedButton === null) {
			throw new Exception("Could not find pressed button.");
		}
		$this->getFormAdapter()->processForm($form, $pressedButton, $params);
		
		$this->forward('loadForm');
    }
    
    protected function getActiveForm()
    {
    	$formName = $this->Request()->getParam('formName');
    	foreach ($this->getFormAdapter()->getForms() as $form) {
    		if ($form->getMachineName() == $formName) {
    			return $form;
    		}
    	}
    	throw new Exception(Customweb_Core_String::_('There is no form with the name \'!formName\'.')->format(array('!formName' => $formName)));
    }
    
    /**
     * @return Customweb_Payment_BackendOperation_Form_IAdapter
     */
    protected function getFormAdapter()
    {
    	$container = PayItEasyCw_Helpers_Util::createContainer();
    	return $container->getBean('Customweb_Payment_BackendOperation_Form_IAdapter');
    }
}
 