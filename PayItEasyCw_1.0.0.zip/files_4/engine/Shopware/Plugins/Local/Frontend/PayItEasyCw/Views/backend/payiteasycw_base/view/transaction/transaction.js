/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/transaction"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.Transaction', {
    extend: 'Ext.tab.Panel',
    
    alias: 'widget.payiteasycw-base-transaction-transaction',

    height: '50%',
    
    autoScroll: true,
    
    border: 0,
    
    bodyBorder: false,
    
    activeTab: 0,
            
    initComponent: function() {
        var me = this;
          
        me.callParent(arguments);
        
        if (me.record) {
        	me.createItems();
        }
    },
    
    setRecord: function(record) {
    	var me = this;
    	
    	me.removeAll();
		if (record) {
			me.record = record;
			me.createItems();
		}
    },
    
    updateRecord: function(record) {
    	var me = this,
			activeIndex = me.items.findIndex('id', me.getActiveTab().getId());
	
		me.setRecord(record);
		if (record) {
			me.setActiveTab(activeIndex);
		}
    },
    
    createItems: function(){
    	var me = this;
    	
    	var infoTab = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.Overview', {
    		title: '{s name=payiteasycw/bb3ccd5881d651448ded1dac904054ac}Information{/s}',
    		record: me.record
    	});
    	me.add(infoTab);
    	
    	var historyTab = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.History', {
    		title: '{s name=payiteasycw/3cd15f8f2940aff879df34df4e5c2cd1}History{/s}',
    		record: me.record
    	});
    	if (me.record.getHistory().getCount()) {
    		me.add(historyTab);
    	}
    	
    	
    	var captureTab = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.Captures', {
    		title: '{s name=payiteasycw/8856ffdd044d57cd4124a6be5dcea329}Captures{/s}',
    		record: me.record
    	});
    	if (me.record.get('capturePossible') || me.record.get('cancelPossible') || me.record.getCaptures().getCount()) {
    		me.add(captureTab);
    	}
	    
    	
	    
    	var refundTab = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.Refunds', {
    		title: '{s name=payiteasycw/0084ff716402199f733f841f5937d3ae}Refunds{/s}',
    		record: me.record
    	});
	    if (me.record.get('refundPossible') || me.record.getRefunds().getCount()) {
	    	me.add(refundTab);
	    }
    	
    	
    	me.doLayout();
    	me.setActiveTab(0);
    }
});
//{/block}