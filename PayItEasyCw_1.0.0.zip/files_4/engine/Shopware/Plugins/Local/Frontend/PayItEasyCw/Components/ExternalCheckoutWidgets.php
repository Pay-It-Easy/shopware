<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_ExternalCheckoutWidgets
{
	public static function getWidgets()
	{
		$widgets = array();
	
		
		/* @var $context PayItEasyCw_Entities_ExternalCheckoutContext */
		$context = PayItEasyCw_Helpers_Util::loadExternalCheckoutContext();
		if ($context === null || $context->getState() != Customweb_Payment_ExternalCheckout_IContext::STATE_PENDING) {
			$context = new PayItEasyCw_Entities_ExternalCheckoutContext();
			$context = PayItEasyCw_Helpers_Util::getEntityManager()->persist($context);
		}
	
		$providerService = PayItEasyCw_Helpers_Util::createContainer()->getBean('Customweb_Payment_ExternalCheckout_IProviderService');
		if (!($providerService instanceof Customweb_Payment_ExternalCheckout_IProviderService)) {
			throw new Customweb_Core_Exception_CastException('Customweb_Payment_ExternalCheckout_IProviderService');
		}
	
		$context->setState(Customweb_Payment_ExternalCheckout_IContext::STATE_PENDING);
		$context->update();
	
		$checkouts = $providerService->getCheckouts($context);
	
		foreach ($checkouts as $checkout) {
			$widgets[] = array(
				'html' => $providerService->getWidgetHtml($checkout, $context),
				'checkoutName' => $checkout->getMachineName(),
				'sortOrder' => $checkout->getSortOrder()
			);
		}
	
		PayItEasyCw_Helpers_Util::getEntityManager()->persist($context);

		Shopware()->Session()->PayItEasyCwExternalCheckoutContextId = $context->getContextId();
		

		return $widgets;
	}
	
	public static function getAllWidgets()
	{
		if (Shopware()->Config()->customwebExternalCheckoutWidgetCollected == null)  {
			Shopware()->Config()->customwebExternalCheckoutWidgetCollected = true;
			
			$widgets = array();
			$widgets = Enlight()->Events()->filter(
				'Customweb_ExternalCheckout_Widget_Collect',
				$widgets,
				array()
			);
			
			usort($widgets, function($a, $b){
				if ($a['sortOrder'] == $b['sortOrder']) {
					return 0;
				} else {
					return $a['sortOrder'] < $b['sortOrder'] ? -1 : 1;
				}
			});
			
			return $widgets;
		} else {
			return array();
		}
	}
}