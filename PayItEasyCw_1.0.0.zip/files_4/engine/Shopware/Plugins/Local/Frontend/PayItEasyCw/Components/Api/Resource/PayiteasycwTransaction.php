<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 */

namespace Shopware\Components\Api\Resource;

use Shopware\Components\Api\Exception as ApiException;

/**
 * @author Simon Schurter
 */
class PayiteasycwTransaction extends Resource
{
	/**
	 * @param $paymentId
	 * @return int
	 * @throws \Shopware\Components\Api\Exception\NotFoundException
	 * @throws \Shopware\Components\Api\Exception\ParameterMissingException
	 */
	public function getIdFromPaymentId($paymentId)
	{
		if (empty($paymentId)) {
			throw new ApiException\ParameterMissingException();
		}

		$transaction = null;
		$transactions = \PayItEasyCw_Helpers_Util::getEntityManager()->searchByFilterName('PayItEasyCw_Entities_Transaction', 'loadByPaymentId', array('>paymentId' => $paymentId));
		if (!empty($transactions)) {
			$transaction = end($transactions);
		}

		if (!($transaction instanceof \PayItEasyCw_Entities_Transaction)) {
			throw new ApiException\NotFoundException("Transaction by payment id {$paymentId} not found");
		}

		return $transactionModel->getTransactionId();
	}

	/**
	 * @param string $number
	 * @return array
	 * @throws \Shopware\Components\Api\Exception\ParameterMissingException
	 * @throws \Shopware\Components\Api\Exception\NotFoundException
	 */
	public function getOneByPaymentId($paymentId)
	{
		$id = $this->getIdFromPaymentId($paymentId);
		return $this->getOne($id);
	}

	/**
	 * @param int $id
	 * @return array
	 * @throws \Shopware\Components\Api\Exception\ParameterMissingException
	 * @throws \Shopware\Components\Api\Exception\NotFoundException
	 */
	public function getOne($id)
	{
		$this->checkPrivilege('read');

		if (empty($id)) {
			throw new ApiException\ParameterMissingException();
		}
		
		$transaction = \PayItEasyCw_Helpers_Util::getEntityManager()->fetch('PayItEasyCw_Entities_Transaction', $id);
		if (!($transaction instanceof \PayItEasyCw_Entities_Transaction) || $transaction->getTransactionId() == null) {
			throw new ApiException\NotFoundException("Transaction by id {$id} not found");
		}

		return $this->prepareObject($transaction);
	}

	/**
	 * @param int $offset
	 * @param int $limit
	 * @param array $criteria
	 * @param array $orderBy
	 * @return array
	 */
	public function getList($offset = 0, $limit = 25, array $criteria = array(), array $orderBy = array())
	{
		$this->checkPrivilege('read');
		
		$parameters = array();
		
		$filter = $this->parseFilter($criteria);
		$parameters = array_merge($parameters, $filter['parameters']);
		
		if (empty($orderBy)) {
			$sort = array(
				'query' => 'transactionId ASC'
			);
		} else {
			$sort = $this->parseOrderBy($orderBy);
			$parameters = array_merge($parameters, $sort['parameters']);
		}
		
		$transactions = \PayItEasyCw_Helpers_Util::getEntityManager()->search('PayItEasyCw_Entities_Transaction',
			$filter['query'],
			$sort['query'] . ' LIMIT ' . (int)$offset . ', ' . (int)$limit,
			$parameters
		);

		$transactionsArray = array();
		foreach ($transactions as $transaction) {
			$transactionsArray[] = $this->prepareObject($transaction);
		}

		return array('data' => $transactionsArray, 'total' => count($transactionsArray));
	}
	
	protected function prepareObject(\PayItEasyCw_Entities_Transaction $transaction)
	{
		$transactionArray = $transaction->toArray();
		if ($transaction->getTransactionObject() instanceof \Customweb_Payment_Authorization_ITransaction) {
			$transactionArray['data'] = $transaction->getTransactionObject()->getTransactionData();
		}
		unset($transactionArray['transactionObject']);
		unset($transactionArray['sessionData']);
		return $transactionArray;
	}
	
	protected function parseOrderBy(array $orderBy = array())
	{
		$index = 0;
		$parameters = array();
		$query = array();
		foreach ($orderBy as $order) {
			if (!isset($order['property']) || !preg_match('#^[a-zA-Z0-9_.]+$#', $order['property'])) {
				continue;
			}
	
			if (isset($order['direction']) && $order['direction'] == 'DESC') {
				$direction = 'DESC';
			} else {
				$direction = 'ASC';
			}
	
			$parameters['>order' . $index] = $order['property'];
			$query[] = '>order' . $index . ' ' . $direction;
			$index++;
		}
		return array(
			'parameters' => $parameters,
			'query' => implode(', ', $query)
		);
	}
	
	protected function parseFilter(array $criteria = array())
	{
		$index = 0;
		$parameters = array();
		$query = array();
		foreach ($criteria as $property => $value) {
			if (!preg_match('#^[a-z][a-z0-9_.]+$#i', $property)) {
				continue;
			}
				
			$parameters['>filter' . $index] = $property;
			$parameters['>expr' . $index] = $value;
			$query[] = '>filter' . $index . ' = >expr' . $index;
		}
		return array(
			'parameters' => $parameters,
			'query' => implode(', ', $query)
		);
	}
}