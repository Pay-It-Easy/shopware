//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_transactions/controller/filter"}
Ext.define('Shopware.apps.PayiteasycwTransactions.controller.Filter', {
    extend: 'Ext.app.Controller',

    init: function () {
        var me = this;

        me.control({
            'payiteasycw-transactions-list-main-window payiteasycw-transactions-list': {
                searchTransactions: me.onSearchTransactions
            },
            'payiteasycw-transactions-list-main-window payiteasycw-transactions-list-filter': {
                acceptFilters: me.onAcceptFilters,
                resetFilters: me.onResetFilters
            }
        });
        me.callParent(arguments);
    },

    onSearchTransactions: function(value) {
        var me = this,
            store = me.subApplication.getStore('Transaction');

        if (store.filters.containsKey('free')) {
            store.filters.removeAtKey('free');
        }
        store.filters.add('free', Ext.create('Ext.util.Filter', { property: 'free', value: Ext.String.trim(value) }));

        store.currentPage = 1;

        store.filter();
    },

    onAcceptFilters: function(values) {
        var me = this,
            store = me.subApplication.getStore('Transaction'),
            filters= [];

        Ext.Object.each(values, function(key, value) {
            var tmpValue = Ext.String.trim(value + '');
	        if (tmpValue.length > 0) {
	            filters.push(Ext.create('Ext.util.Filter',{ property: key, value: value }));
	        }
        });

        if (store.filters.containsKey('free')) {
            filters.push(store.filters.getByKey('free'));
        }

        store.currentPage = 1;

        if (filters.length > 0) {
            store.filters.clear();
            store.filter(filters);
        } else {
            if (store.filters.length > 0) {
                store.clearFilter();
            }
        }
    },

    onResetFilters: function(form) {
        var me = this,
            freeFilter = null,
            store = me.subApplication.getStore('Transaction');

        if (!form) {
            return;
        }
        form.getForm().reset();

        if (store.filters.length === 0) {
            return;
        }

        if (store.filters.containsKey('free')) {
            freeFilter = store.filters.getByKey('free');
        }
        store.filters.clear();

        if (freeFilter) {
            store.filter(freeFilter);
        } else {
            store.load();
        }
    },
});
//{/block}
