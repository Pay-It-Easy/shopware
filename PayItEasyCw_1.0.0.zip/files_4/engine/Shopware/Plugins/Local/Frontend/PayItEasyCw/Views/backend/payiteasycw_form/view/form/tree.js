//{namespace name=backend/payiteasycw/main}

//{block name="backend/payiteasycw_form/view/form/tree"}
Ext.define('Shopware.apps.PayiteasycwForm.view.form.Tree', {
    extend : 'Ext.tree.Panel',
    alias : 'widget.payiteasycw-main-tree',
    autoShow : true,
    region: 'west',
    name:  'tree',
    flex: 0.3,
    rootVisible: false,
    useArrows: false,
    lines: false,
    title: '{s name=payiteasycw/ac68b62abfd6a9fe26e8ac4236c8ce0c}Forms{/s}',
    store: 'Form',

    initComponent: function(){
        var me = this;
        me.callParent(arguments);
    }
});
//{/block}