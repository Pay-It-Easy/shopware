/**
 * This store is used to load order transactions.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/store/transaction"}
Ext.define('Shopware.apps.PayiteasycwBase.store.Transaction', {
    extend: 'Ext.data.Store',
 
    autoLoad: false,
    
    sorters: [{
		property : 'transactionId',
		direction: 'DESC'
	}],
 
    model: 'Shopware.apps.PayiteasycwBase.model.Transaction'
});
//{/block}