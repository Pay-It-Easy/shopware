<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @author Simon Schurter
 */
class Shopware_Controllers_Backend_PayiteasycwTransactions extends Shopware_Controllers_Backend_ExtJs {
	/**
	 *
	 * @var \Shopware\CustomModels\PayItEasyCw\Transaction\Repository
	 */
	private static $repository = null;

	protected function getRepository(){
		if (self::$repository === null) {
			self::$repository = Shopware()->Models()->getRepository('Shopware\CustomModels\PayItEasyCw\Transaction\Transaction');
		}
		return self::$repository;
	}

	public function indexAction(){
		$this->View()->loadTemplate("backend/payiteasycw_transactions/app.js");
	}

	public function exportAction(){
		$this->Front()->Plugins()->Json()->setRenderer(false);
		
		$format = strtolower($this->Request()->getParam('format', 'csv'));
		
		/**
		 *
		 * @var \Shopware\CustomModels\PayItEasyCw\Transaction\Repository
		 */
		$repository = $this->getRepository();
		
		$builder = $repository->createQueryBuilder('transactions');
		
		$filters = array();
		$filterFields = array(
			'authorizationStatus' => 'transactions.authorizationStatus',
			'shopId' => 'shop.id',
			'from' => 'from',
			'to' => 'to' 
		);
		foreach ($filterFields as $param => $filterField) {
			$filterValue = $this->Request()->getParam($param);
			if (!empty($filterValue)) {
				$filters[] = array(
					'property' => $filterField,
					'value' => $filterValue 
				);
			}
		}
		$builder = $repository->filterListQuery($builder, $filters);
		
		if ($format == 'xml') {
			$selectFields = array(
				'transactions',
				'shop',
				'payment',
				'customer' 
			);
		}
		
		if ($format == 'csv' || $format == 'excel') {
			$selectFields = array(
				'transactions.transactionId as transactionID',
				'transactions.orderId as orderID',
				'transactions.authorizationAmount as authorization_amount',
				'transactions.currency as transaction_currency',
				'transactions.authorizationStatus as authorization_status',
				'transactions.createdOn as transaction_createdOn',
				'transactions.paymentMethod as paymentID',
				
				'shop.id as subshopID',
				
				'payment.description as payment_description',
				
				'customer.id as customerId',
				'customer.email as customerEmail' 
			);
		}
		
		$builder->select($selectFields);
		
		$builder->leftJoin('transactions.shop', 'shop')->leftJoin('transactions.payment', 'payment')->leftJoin('transactions.customer', 'customer');
		
		$builder->addOrderBy('transactions.createdOn');
		
		$query = $builder->getQuery();
		$result = $query->getArrayResult();
		
		array_walk_recursive($result, function (&$value){
			if ($value instanceof DateTime) {
				$value = $value->format('Y-m-d H:i:s');
			}
		});
		
		if ($format == 'excel') {
			$this->Response()->setHeader('Content-Type', 'application/vnd.ms-excel;charset=UTF-8');
			$this->Response()->setHeader('Content-Disposition', 'attachment; filename="export.transactions.' . date("Y.m.d") . '.xls"');
			$this->Response()->setHeader('Content-Transfer-Encoding', 'binary');
			
			$excel = new Shopware_Components_Convert_Excel();
			$excel->setTitle('Transactions Export');
			$excel->addRow(array_keys(reset($result)));
			$excel->addArray($result);
			echo $excel->getAll();
		}
		
		if ($format == 'csv') {
			$this->Response()->setHeader('Content-Type', 'text/x-comma-separated-values;charset=utf-8');
			$this->Response()->setHeader('Content-Disposition', 'attachment; filename="export.transactions.' . date("Y.m.d") . '.csv"');
			$this->Response()->setHeader('Content-Transfer-Encoding', 'binary');
			
			$convert = new Shopware_Components_Convert_Csv();
			$convert->sSettings['newline'] = "\r\n";
			echo "\xEF\xBB\xBF"; // UTF-8 BOM
			echo $convert->encode($result);
		}
		
		if ($format == 'xml') {
			foreach ($result as &$item) {
				unset($item['transactionObject']);
				unset($item['sessionData']);
				unset($item['lastSetOrderStatusSettingKey']);
				unset($item['executeUpdateOn']);
				unset($item['updatable']);
				unset($item['temporaryOrderId']);
				if (isset($item['payment']['additionalDescription'])) {
					unset($item['payment']['additionalDescription']);
				}
				if (isset($item['customer']['encoderName'])) {
					unset($item['customer']['encoderName']);
				}
				if (isset($item['customer']['hashPassword'])) {
					unset($item['customer']['hashPassword']);
				}
				if (isset($item['customer']['confirmationKey'])) {
					unset($item['customer']['confirmationKey']);
				}
				if (isset($item['customer']['sessionId'])) {
					unset($item['customer']['sessionId']);
				}
				if (isset($item['customer']['failedLogins'])) {
					unset($item['customer']['failedLogins']);
				}
				if (isset($item['customer']['lockedUntil'])) {
					unset($item['customer']['lockedUntil']);
				}
			}
			
			$transactions = array(
				"shopware" => array(
					"transactions" => array(
						"transaction" => $result 
					) 
				) 
			);
			$convert = new Shopware_Components_Convert_Xml();
			
			$this->Response()->setHeader('Content-Type', 'text/xml;charset=utf-8');
			$this->Response()->setHeader('Content-Disposition', 'attachment; filename="export.transactions.' . date("Y.m.d") . '.xml"');
			$this->Response()->setHeader('Content-Transfer-Encoding', 'binary');
			
			echo $convert->encode($transactions);
		}
	}

	public function getListAction(){
		$limit = $this->Request()->getParam('limit', 20);
		$offset = $this->Request()->getParam('start', 0);
		$sort = $this->Request()->getParam('sort', null);
		$filter = $this->Request()->getParam('filter', null);
		$transactionId = $this->Request()->getParam('transactionId');
		
		if (!is_null($transactionId)) {
			$transactionIdFilter = array(
				'property' => 'transactions.transactionId',
				'value' => $transactionId 
			);
			if (!is_array($filter)) {
				$filter = array();
			}
			array_push($filter, $transactionIdFilter);
		}
		$list = $this->getList($filter, $sort, $offset, $limit);
		$this->View()->assign($list);
	}

	protected function getList($filter, $sort, $offset, $limit){
		try {
			if (empty($sort)) {
				$sort = array(
					array(
						'property' => 'transactions.createdOn',
						'direction' => 'DESC' 
					) 
				);
			}
			else {
				$sort[0]['property'] = 'transactions.' . $sort[0]['property'];
			}
			$query = $this->getRepository()->getBackendTransactionsQuery($filter, $sort, $offset, $limit);
			$query->setHydrationMode(\Doctrine\ORM\AbstractQuery::HYDRATE_ARRAY);
			$paginator = $this->getPaginator($query);
			$total = $paginator->count();
			$transactions = $paginator->getIterator()->getArrayCopy();
			
			foreach ($transactions as &$transaction) {
				unset($transaction['transactionObject']);
				unset($transaction['sessionData']);
			}
			
			return array(
				'success' => true,
				'data' => $transactions,
				'total' => $total 
			);
		}
		catch (\Doctrine\ORM\ORMException $e) {
			return array(
				'success' => false,
				'data' => array(),
				'message' => $e->getMessage() 
			);
		}
	}

	public function getModelManager(){
		try {
			return parent::getModelManager();
		}
		catch (Exception $e) {
			return Shopware()->Models();
		}
	}

	protected function getPaginator($query){
		if (method_exists($this->getModelManager(), 'createPaginator')) {
			return $this->getModelManager()->createPaginator($query);
		}
		else {
			return new \Doctrine\ORM\Tools\Pagination\Paginator($query);
		}
	}
}
 