//{block name="backend/payiteasycw_transactions/app"}
	Ext.define('Shopware.apps.PayiteasycwTransactions', {
	    extend: 'Enlight.app.SubApplication',
	 
	    name: 'Shopware.apps.PayiteasycwTransactions',
	 
	    bulkLoad: true,
	    
	    loadPath: '{url controller="PayiteasycwTransactions" action=load}',
	 
	    controllers: [
	         'Main',
	         'List',
	         'Filter'
	    ],
	 
	    stores: [
             'Transaction'
        ],
	    
	    models: [
             'Transaction'
        ],
	 
	    views: [
            'main.Window',
            'list.List',
            'list.Filter'
        ],
	 
	    launch: function() {
	        var me = this,
	            mainController = me.getController('Main');
	 
	        return mainController.mainWindow;
	    }
	});
//{/block}