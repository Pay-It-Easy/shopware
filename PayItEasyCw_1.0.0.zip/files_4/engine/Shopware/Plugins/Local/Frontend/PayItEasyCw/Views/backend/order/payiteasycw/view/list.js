//{namespace name=backend/payiteasycw/main}

//{block name="backend/order/payiteasycw/view/list"}
Ext.define('Shopware.apps.Order.Payiteasycw.view.List', {
    extend:'Ext.grid.Panel',

    alias:'widget.payiteasycw-order-transaction-list',

    autoScroll:true,

    initComponent:function () {
        var me = this;
        
        me.columns = me.getColumns();
        me.pagingbar = me.getPagingBar();
        me.dockedItems = [ me.pagingbar ];
        me.getSelectionModel().on('selectionchange', function(row, selection, options) {
        	row.view.up().next().setRecord(selection[0]);
        });
        me.callParent(arguments);
    },

    getPagingBar: function() {
        var pagingbar =  Ext.create('Ext.toolbar.Paging', {
            store: this.store,
            dock: 'bottom',
            displayInfo: true
        });
 
        return pagingbar;
    },

    getColumns:function () {
        var me = this;

        var columns = [
            {
                header: '{s name=payiteasycw/5fc732311905cb27e82d67f4f6511f7f}Date{/s}',
                dataIndex: 'createdOn',
                flex:1,
                renderer: me.dateColumn
            },
            {
                header: '{s name=payiteasycw/f847de525f37118f39327768ffb8714c}Transaction Id{/s}',
                dataIndex: 'transactionId',
                flex:1
            },
            {
                header: '{s name=payiteasycw/e9f40e1f1d1658681dad2dac4ae0971e}Amount{/s}',
                dataIndex: 'authorizationAmount',
                flex:1,
                renderer: me.amountColumn
            },
            {
                header: '{s name=payiteasycw/6ba408e34a2570d54dcc2b1c81a9a136}Payment Method{/s}',
                dataIndex: 'paymentMethod',
                flex:2,
            },
            {
                header: '{s name=payiteasycw/9acb44549b41563697bb490144ec6258}Status{/s}',
                dataIndex: 'authorizationStatus',
                flex:1,
                renderer: me.statusColumn
            }
        ];

        return columns;
    },

    /**
     * Formats the date column
     *
     * @param [string] - The date value
     * @return [string] - The passed value, formatted with Ext.util.Format.date()
     */
    dateColumn:function (value, metaData, record) {
        if ( value === Ext.undefined ) {
            return value;
        }

        return Ext.util.Format.date(value) + ' ' + Ext.util.Format.date(value, 'H:i');
    },

    /**
     * Formats the amount column
     * @param [string] - The amount value
     * @return [string] - The passed value, formatted with Ext.util.Format.currency()
     */
    amountColumn:function (value, metaData, record) {
        if ( value === Ext.undefined ) {
            return value;
        }
        return Ext.util.Format.currency(value);
    },
    
    /**
     * Formats the authorization status column
     *
     * @param [string] - The authorization status value
     * @return [string] - The formatted value
     */
    statusColumn: function(value, metaData, record) {
    	switch (value) {
    		case 'pending':
    			return '{s name=payiteasycw/7c6c2e5d48ab37a007cbf70d3ea25fa4}Pending{/s}';
    		case 'successful':
    			return '{s name=payiteasycw/802024b279b2158800d75b4725bc77ba}Successful{/s}';
    		case 'failed':
    			return '{s name=payiteasycw/26934eb377001f66e37289a5c93fe284}Failed{/s}';
    		default:
    			return value;
    	}
     }
});
//{/block}

