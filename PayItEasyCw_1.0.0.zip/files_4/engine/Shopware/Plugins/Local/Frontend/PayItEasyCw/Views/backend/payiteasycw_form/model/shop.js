//{block name="backend/payiteasycw_form/model/shop"}
Ext.define('Shopware.apps.PayiteasycwForm.model.Shop', {
    extend : 'Ext.data.Model',

    alias : 'model.shop',

    fields : [
        { name : 'id',       		type: 'int' },
        { name : 'name',       		type: 'string' },
    ],

    proxy : {
        type : 'ajax',
        api : {
            read : '{url controller="PayiteasycwForm" action=getShops}',
        },
        reader : {
            type : 'json',
            root: 'data'
        }
    }
});
//{/block}