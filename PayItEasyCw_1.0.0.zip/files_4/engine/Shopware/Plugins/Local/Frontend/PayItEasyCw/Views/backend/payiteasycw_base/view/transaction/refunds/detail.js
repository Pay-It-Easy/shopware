/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/captures/refunds"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.refunds.Detail', {
    extend: 'Ext.form.Panel',
    
	layout:			'anchor',
    
    defaults: {
    	anchor:		'100%',
    	xtype:		'displayfield',
        labelWidth:	155,
        fieldStyle:	'margin-top: 5px;'
    },
    
    initComponent: function() {
        var me = this;
 
        me.callParent(arguments);
    },
    
    updateRecord: function(record) {
    	var me = this;
    	
    	me.removeAll();
    	
    	if (record) {
    		me.record = record;
    	    	    	
    		me.createItems();
    	}
    },
    
    createItems: function(){
    	var me = this;
    	
    	var item = Ext.create('Ext.container.Container', {
    		columnWidth:	0.5,
    	    layout:			'anchor',
    	    padding:		'10px 20px',
    	    defaults: {
    	    	anchor:		'100%',
    	    	xtype:		'displayfield',
    	        labelWidth:	155,
    	        fieldStyle:	'margin-top: 5px;'
    	    },
    	    items:			me.createFields()
    	});
    	me.add(item);
    },
    
    createFields: function() {
        var me = this,
        	field,
        	fields = [],
        	labels = me.record.get('labels');
        for (var key in labels) {
        	fields.push({ value: labels[key]['value'], fieldLabel: labels[key]['label'], helpText: labels[key]['description'] });
        }
        return fields;
    }
});
//{/block}