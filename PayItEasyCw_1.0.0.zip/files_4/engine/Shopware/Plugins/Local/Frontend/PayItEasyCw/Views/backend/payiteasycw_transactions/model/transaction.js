/**
 * This model represents a order transaction.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_transactions/model/transaction"}
Ext.define('Shopware.apps.PayiteasycwTransactions.model.Transaction', {
    extend: 'Ext.data.Model',
 
    fields: [
        //{block name="backend/payiteasycw_transactions/model/transaction/fields"}{/block}
        { name: 'transactionId', type: 'int' },
        { name: 'transactionExternalId', type: 'string' },
        { name: 'orderId', type: 'int' },
        { name: 'temporaryOrderId', type: 'int' },
        { name: 'aliasForDisplay', type: 'string' },
        { name: 'aliasActive', type: 'string' },
        { name: 'paymentMachineName', type: 'string' },
        { name: 'paymentMethod', type: 'string' },
        { name: 'paymentId', type: 'string' },
        { name: 'authorizationType', type: 'string' },
        { name: 'customerId', type: 'string' },
        { name: 'createdOn', type: 'date' },
        { name: 'updatedOn', type: 'date' },
        { name: 'updatable', type: 'string' },
        { name: 'executeUpdateOn', type: 'date' },
        { name: 'authorizationAmount', type: 'float' },
        { name: 'authorizationStatus', type: 'string' },
        { name: 'paid', type: 'string' },
        { name: 'currency', type: 'string' },
        { name: 'lastSetOrderStatusSettingKey', type: 'string' },
    ],
    
    associations:[
          { type: 'hasMany', model: 'Shopware.apps.Base.model.Customer', name: 'getCustomer', associationKey: 'customer' },
          { type: 'hasMany', model: 'Shopware.apps.Base.model.Shop', name: 'getShop', associationKey: 'shop' },
          { type: 'hasMany', model: 'Shopware.apps.Base.model.Payment', name: 'getPayment', associationKey: 'payment' },
    ],
 
    /**
     * Configure the data communication
     * 
     * @object
     */
    proxy: {
        type: 'ajax',
 
        /**
         * Configure the url mapping for the different store operations
         * 
         * @object
         */
        api: {
            read: '{url controller="PayiteasycwTransactions" action="getList"}'
        },
 
        reader: {
            type:			'json',
            root:			'data',
            totalProperty:	'total'
        }
    }
});
//{/block}