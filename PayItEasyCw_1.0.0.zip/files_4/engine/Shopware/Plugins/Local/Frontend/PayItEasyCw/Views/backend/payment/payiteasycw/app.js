/**
 * Load required files.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payment/app" append}
	//{include file="backend/payment/payiteasycw/controller/config.js"}    
//{/block}