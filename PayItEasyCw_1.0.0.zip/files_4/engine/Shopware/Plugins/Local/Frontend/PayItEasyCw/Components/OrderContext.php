<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class represents a order context.
 *
 * @see Customweb_Payment_Authorization_IOrderContext
 * @author Simon Schurter
 */
class PayItEasyCw_Components_OrderContext extends Customweb_Payment_Authorization_OrderContext_AbstractDeprecated
{
	/**
	 * @var PayItEasyCw_Components_OrderContext[]
	 */
	private static $cache = array();

	/**
	 * @var string
	 */
	private $checkoutId = null;

	/**
	 * @var PayItEasyCw_Components_AddressContext
	 */
	private $billingAddress = null;

	/**
	 * @var PayItEasyCw_Components_AddressContext
	 */
	private $shippingAddress = null;

	/**
	 * @var boolean
	 */
	private $isRecurring = false;

	/**
	 * @var float
	 */
	private $invoiceAmount = 0;

	/**
	 * @var string
	 */
	private $currencyCode = null;

	/**
	 * @var array
	 */
	private $invoiceItems = array();

	/**
	 * @var null|string
	 */
	private $shippingMethod = null;

	/**
	 * @var int
	 */
	private $paymentMethodId = null;

	/**
	 * @var string
	 */
	private $language = null;

	/**
	 * @var string
	 */
	private $customerEmailAddress = null;

	/**
	 * @var int
	 */
	private $customerId = null;

	/**
	 * @deprecated
	 * @var int
	 */
	private $orderId = null;

	/**
	 * Create order context.
	 *
	 * @param int $orderId
	 */
	public function __construct($orderId, $paymentId = null)
	{
		$this->collectOrderData($orderId, $paymentId);
	}

	/**
	 * Used for old order contexts to work properly.
	 */
	public function __wakeup()
	{
		if ($this->orderId !== null) {
			$this->collectOrderData($this->orderId);
		}
	}

	/**
	 * @param int $orderId
	 * @throws Exception
	 */
	protected function collectOrderData($orderId, $paymentId = null)
	{
		if (!isset(self::$cache[$orderId])) {
			$order = Shopware()->Models()->find('Shopware\Models\Order\Order', $orderId);
			if (!($order instanceof Shopware\Models\Order\Order)) {
				return;
			}

			$this->collectAddresses($order);
			$this->isRecurring = PayItEasyCw_Helpers_Util::isOrderRecurring($orderId);
			$this->invoiceAmount = $order->getInvoiceAmount();
			$this->currencyCode = $order->getCurrency();
			$this->collectInvoiceItems($order);
			$this->collectShippingMethod($order);
			$this->paymentMethodId = $paymentId !== null ? $paymentId : $order->getPayment()->getId();
			$this->collectLanguage($order);
			$this->collectCustomerEmailAddress($order);
			$this->customerId = $order->getCustomer()->getId();
			$this->orderId = null;
			self::$cache[$orderId] = $this;
		} else {
			$this->billingAddress = self::$cache[$orderId]->billingAddress;
			$this->shippingAddress = self::$cache[$orderId]->shippingAddress;
			$this->isRecurring = self::$cache[$orderId]->isRecurring;
			$this->invoiceAmount = self::$cache[$orderId]->invoiceAmount;
			$this->currencyCode = self::$cache[$orderId]->currencyCode;
			$this->invoiceItems = self::$cache[$orderId]->invoiceItems;
			$this->shippingMethod = self::$cache[$orderId]->shippingMethod;
			$this->paymentMethodId = $paymentId !== null ? $paymentId : self::$cache[$orderId]->paymentMethodId;
			$this->language = self::$cache[$orderId]->language;
			$this->customerEmailAddress = self::$cache[$orderId]->customerEmailAddress;
			$this->customerId = self::$cache[$orderId]->customerId;
		}

		if (!isset($_SESSION['payiteasycw_checkout_id'])) {
			$_SESSION['payiteasycw_checkout_id'] = Customweb_Core_Util_Rand::getUuid();
		}
		$this->checkoutId = $_SESSION['payiteasycw_checkout_id'];
	}

	/**
	 * @param Shopware\Models\Order\Order $order
	 */
	protected function collectShippingMethod(Shopware\Models\Order\Order $order)
	{
		try {
			$this->shippingMethod = $order->getDispatch()->getName();
		} catch (Exception $e) {}
	}

	/**
	 * @param Shopware\Models\Order\Order $order
	 */
	protected function collectLanguage(Shopware\Models\Order\Order $order)
	{
		$id = $order->getLanguageIso();
		$shop = Shopware()->Models()->find('Shopware\Models\Shop\Shop', $id);
		$locale = $shop->getLocale();
		$this->language = $locale->getLocale();
	}

	/**
	 * @param Shopware\Models\Order\Order $order
	 */
	protected function collectCustomerEmailAddress(Shopware\Models\Order\Order $order)
	{
		// Fix to prevent an error when saving order
		$builder = Shopware()->Models()->createQueryBuilder();
		$builder
			->select('u.email')
			->from('Shopware\Models\Customer\Customer', 'u')
			->where('u.id = ?1')
			->setParameter(1, $order->getCustomer()->getId());
		$single = $builder->getQuery()->getSingleResult();
		$this->customerEmailAddress = $single['email'];
	}

	/**
	 * @param Shopware\Models\Order\Order $order
	 */
	protected function collectInvoiceItems(Shopware\Models\Order\Order $order)
	{
		$this->invoiceItems = PayItEasyCw_Components_InvoiceItems::collectInvoiceItemsByOrder($order);
	}

	/**
	 * @param Shopware\Models\Order\Order $order
	 */
	protected function collectAddresses(Shopware\Models\Order\Order $order)
	{
		$billingAddresses = array();
		if ($order->getBilling() instanceof Shopware\Models\Order\Billing) {
			$billingAddresses[] = $order->getBilling();
		}
		$billingAddresses[] = $order->getCustomer()->getBilling();

		$shippingAddresses = array();
		if ($order->getShipping() instanceof Shopware\Models\Order\Shipping) {
			$shippingAddresses[] = $order->getShipping();
		}
		if ($order->getCustomer()->getShipping() instanceof Shopware\Models\Customer\Shipping) {
			$shippingAddresses[] = $order->getCustomer()->getShipping();
		}
		$shippingAddresses[] = $order->getCustomer()->getBilling();

		$this->billingAddress = new PayItEasyCw_Components_AddressContext($billingAddresses);
		$this->shippingAddress = new PayItEasyCw_Components_AddressContext($shippingAddresses);
	}

	/**
	 * @return PayItEasyCw_Components_AddressContext
	 */
	protected function getBilling()
	{
		return $this->billingAddress;
	}

	/**
	 * @return PayItEasyCw_Components_AddressContext
	 */
	protected function getShipping()
	{
		return $this->shippingAddress;
	}

	/**
	 * @param float $invoiceAmount
	 * @return PayItEasyCw_Components_OrderContext
	 */
	protected function setInvoiceAmount($invoiceAmount)
	{
		$this->invoiceAmount = $invoiceAmount;
		return $this;
	}

	/**
	 * @param array $invoiceItems
	 * @return PayItEasyCw_Components_OrderContext
	 */
	protected function setInvoiceItems($invoiceItems)
	{
		$this->invoiceItems = $invoiceItems;
		return $this;
	}

	/**
	 * Is the order recurring?
	 *
	 * @return boolean
	 */
	public function isRecurring()
	{
		return $this->isRecurring;
	}

	public function getCheckoutId()
	{
		return $this->checkoutId;
	}

	public function getOrderAmountInDecimals()
	{
		return $this->invoiceAmount;
	}

	public function getCurrencyCode()
	{
		return $this->currencyCode;
	}

	public function getInvoiceItems()
	{
		return $this->invoiceItems;
	}

	public function getShippingMethod()
	{
		return $this->shippingMethod;
	}

	public function getPaymentMethod()
	{
		$payment = Shopware()->Models()->find('Shopware\Models\Payment\Payment', $this->paymentMethodId);
		return new PayItEasyCw_Components_PaymentMethodWrapper($payment);
	}

	public function getLanguage()
	{
		return new Customweb_Core_Language($this->language);
	}

	public function getCustomerEMailAddress()
	{
		return $this->customerEmailAddress;
	}

	public function getBillingFirstName()
	{
		return $this->getBilling()->getFirstName();
	}

	public function getBillingLastName()
	{
		return $this->getBilling()->getLastName();
	}

	public function getBillingStreet()
	{
		return $this->getBilling()->getStreet();
	}

	public function getBillingCity()
	{
		return $this->getBilling()->getCity();
	}

	public function getBillingPostCode()
	{
		return $this->getBilling()->getZipCode();
	}

	public function getBillingCountryIsoCode()
	{
		return $this->getBilling()->getCountry();
	}

	public function getBillingSalutation()
	{
		return $this->getBilling()->getSalutation();
	}

	public function getBillingDateOfBirth()
	{
		return null;
	}

	public function getBillingCommercialRegisterNumber()
	{
		return null;
	}

	public function getBillingCompanyName()
	{
		return $this->getBilling()->getCompany();
	}

	public function getBillingSalesTaxNumber()
	{
		return null;
	}

	public function getBillingSocialSecurityNumber()
	{
		return null;
	}

	public function getShippingFirstName()
	{
		return $this->getShipping()->getFirstName();
	}

	public function getShippingLastName()
	{
		return $this->getShipping()->getLastName();
	}

	public function getShippingStreet()
	{
		return $this->getShipping()->getStreet();
	}

	public function getShippingCity()
	{
		return $this->getShipping()->getCity();
	}

	public function getShippingPostCode()
	{
		return $this->getShipping()->getZipCode();
	}

	public function getShippingCountryIsoCode()
	{
		return $this->getShipping()->getCountry();
	}

	public function getShippingCompanyName()
	{
		return $this->getShipping()->getCompany();
	}

	public function getShippingSalutation()
	{
		return $this->getShipping()->getSalutation();
	}

	public function getCustomerId()
	{
		return $this->customerId;
	}

	public function isNewCustomer()
	{
		return 'unknown';
	}

	public function getCustomerRegistrationDate()
	{
		return null;
	}

	public function getBillingEMailAddress()
	{
		return $this->getCustomerEMailAddress();
	}

	public function getBillingGender()
	{
		if ($this->getBillingSalutation() == 'mr') {
			return 'male';
		} elseif ($this->getBillingSalutation() == 'ms') {
			return 'female';
		} else {
			return null;
		}
	}

	public function getBillingState()
	{
		return $this->getBilling()->getState();
	}

	public function getBillingPhoneNumber()
	{
		return $this->getBilling()->getPhone();
	}

	public function getBillingMobilePhoneNumber()
	{
		return null;
	}

	public function getShippingEMailAddress()
	{
		return $this->getCustomerEMailAddress();
	}

	public function getShippingGender()
	{
		if ($this->getShippingSalutation() == 'mr') {
			return 'male';
		} elseif ($this->getShippingSalutation() == 'ms') {
			return 'female';
		} else {
			return null;
		}
	}

	public function getShippingState()
	{
		return $this->getShipping()->getState();
	}

	public function getShippingPhoneNumber()
	{
		return null;
	}

	public function getShippingMobilePhoneNumber()
	{
		return null;
	}

	public function getShippingDateOfBirth()
	{
		return null;
	}

	public function getShippingCommercialRegisterNumber()
	{
		return null;
	}

	public function getShippingSalesTaxNumber()
	{
		return null;
	}

	public function getShippingSocialSecurityNumber()
	{
		return null;
	}

	public function getOrderParameters()
	{
		return array();
	}
}
