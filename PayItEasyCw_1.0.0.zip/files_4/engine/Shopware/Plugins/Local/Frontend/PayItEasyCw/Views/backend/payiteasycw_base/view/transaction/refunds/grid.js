/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/captures/refunds"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.refunds.Grid', {
    extend: 'Ext.grid.Panel',
    
    initComponent: function() {
        var me = this;
 
        me.columns = me.getColumns();
        
        me.store = me.record.getRefunds();
        me.store.sort([{
    		property : 'id',
    		direction: 'DESC'
    	}]);
        
        me.getSelectionModel().on('selectionchange', function(row, selection, options) {
        	row.view.up().next().updateRecord(selection[0]);
        });
 
        me.callParent(arguments);
    },
    
    getColumns: function() {
    	var me = this;
    	    	
    	var columns = [{
		    header: '#',
		    dataIndex: 'id',
		    width: 100
		}, {
            header: '{s name=payiteasycw/e9f40e1f1d1658681dad2dac4ae0971e}Amount{/s}',
            dataIndex: 'amount',
            renderer: function(value) {
    	        if ( value === Ext.undefined ) {
    	            return value;
    	        }
    	        return Ext.util.Format.currency(value);
    	    },
            width: 100
		}, {
		    header: '{s name=payiteasycw/5fc732311905cb27e82d67f4f6511f7f}Date{/s}',
		    dataIndex: 'date',
		    xtype:'datecolumn',
		    format:'d.m.Y H:i:s',
		    width: 120
    	}, {
            header: '{s name=payiteasycw/9acb44549b41563697bb490144ec6258}Status{/s}',
            dataIndex: 'status',
            flex: 1
    	}];
    	
    	return columns;
    }
});
//{/block}