ALTER TABLE `payiteasycw_transaction` ADD `versionNumber` int NOT NULL;
ALTER TABLE `payiteasycw_transaction` ADD `liveTransaction` char(1);
ALTER TABLE `payiteasycw_customer_context` ADD `versionNumber` int NOT NULL;
ALTER TABLE `payiteasycw_external_checkout_context` ADD `versionNumber` int NOT NULL;