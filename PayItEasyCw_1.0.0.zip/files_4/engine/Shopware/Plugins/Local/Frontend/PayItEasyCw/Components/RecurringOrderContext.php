<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class represents a recurring order context.
 *
 * @see Customweb_Payment_Authorization_IOrderContext
 * @author Simon Schurter
 */
class PayItEasyCw_Components_RecurringOrderContext extends PayItEasyCw_Components_OrderContext
{
	/**
	 * Create order context.
	 *
	 * @param int $orderId
	 */
	public function __construct($orderId, $paymentId = null)
	{
		parent::__construct($orderId, $paymentId);

		$vars = Shopware()->Session()->sOrderVariables;
		$this->setInvoiceAmount($vars->sAmountWithTax);
	}

	/**
	 * @param Shopware\Models\Order\Order $order
	 */
	protected function collectInvoiceItems(Shopware\Models\Order\Order $order)
	{
		$this->setInvoiceItems(PayItEasyCw_Components_InvoiceItems::collectInvoiceItemsByBasket(Shopware()->Session()->sOrderVariables->sBasket));
	}
}