if(typeof window.Customweb == 'undefined'){
	window.Customweb = {};
}

if(typeof Customweb.PayItEasyCw == 'undefined'){
	Customweb.PayItEasyCw = {};
}

Customweb.PayItEasyCw.Checkout = {
	init: function(processingLabel, orderUrl, visibleFieldsUrl, paymentMethod, authorizationMethod) {
		this.processingLabel = processingLabel;
		this.orderUrl = orderUrl;
		this.visibleFieldsUrl = visibleFieldsUrl;
		this.paymentMethod = paymentMethod;
		this.authorizationMethod = authorizationMethod;
		
		this.attachListeners();
		
		this.getFormElement().show();
		$('#payiteasycw-javascript-required').hide();
		
		return this;
	},
	
	/**
	 * The method name of the currently selected method.
	 * 
	 * @return boolean|string
	 */
	paymentMethod: false,
	
	/**
	 * The current authorization method name.
	 * 
	 * @return boolean|string
	 */
	authorizationMethod: false,
	
	/**
	 * Enforce skipping the form validation.
	 * 
	 * @return boolean
	 */
	skipValidation: false,

	/**
	 * Removes on the payment list selection page all form field names to prevent the sending of the directly to the server.
	 * 
	 * @return void
	 */
	removeFormFieldNames: function() {
		this.getFormElement().find('*[name]').each(function (element) {
			$(this).attr('data-field-name', $(this).attr('name'));
			$(this).removeAttr('name');
		});
	},
	
	/**
	 * This method returns the form fields loaded by JavaScript. These fields should not be
	 * send to the shopping cart.
	 * 
	 * @return List<Object>
	 */
	getDynamicFormValues: function(removeHidden) {
		var output = {};
		this.getFormElement().find('*[data-field-name]').each($.proxy(function (key, element) {
			var name = $(element).attr('data-field-name');
			if (removeHidden && $(element).attr('type') == 'hidden' && !$(element).attr('originalelement')) {
				return;
			}
			if (name != 'alias') {
				output[name] = $(element).val();
			}
		}, this));
		return output;
	},
	
	renderDataAsHiddenFields: function(data) {
		var me = this,
			output = '';
		$.each(data, function(key, value) {
			if ($.isArray(value)) {
				for (var i = 0; i < value.length; i++) {
					output += me.renderHiddenField(key + '[]', value[i]);
				}
			} else {
				output += me.renderHiddenField(key, value);
			}
		});
		return output;
	},
	
	renderHiddenField: function(key, value) {
		if (typeof value == 'string') {
			value = value.replace(/"/g, "&quot;");
		}
		return '<input type="hidden" name="' + key + '" value="' + value + '" />';
	},
	
	/**
	 * This method validates the payment form. In case it is invalid the method returns 
	 * false otherwise it returns true.
	 * 
	 * @return boolean
	 */
	validatePaymentForm: function() {
		if (this.skipValidation) {
			return true;
		}
		return Customweb.PayItEasyCw.Validation.validate(this.getFormElement().attr('id'));
	},
	
	attachListeners: function() {
		$('*').unbind('.payiteasycw');
		this.attachFormSubmitHandler();
		this.attachAliasSelectHandler();
		this.removeFormFieldNames();
	},
	
	attachFormSubmitHandler: function() {
		this.getFormElement().bind('submit.payiteasycw', $.proxy(function(event) {
			var rs = this.handleFormSubmitEvent();
			if (rs === false) {
				event.preventBubble = true;
			}
			return rs;
		}, this));
	},
	
	attachAliasSelectHandler: function() {
		$('#aliasField select[name=alias]').attr('id', 'aliasSelect');
		this.getAliasSelectElement().bind('change.payiteasycw', $.proxy(function(){
			this.loadAliasData();
		}, this));
	},
	
	handleFormSubmitEvent: function() {
		this.cleanUpErrorMessages();
		
		if (!this.validatePaymentForm()) {
			return false;
		}
		
		this.setLoadingIndicator(true);
		this.blockUI();
		
		$.ajax({
			type: 'POST',
			url: this.orderUrl,
			data: this.createDataForAjaxCall(),
			success: $.proxy(function(response){
				this.handleAjaxResponse(response);
			}, this)
		});
		
		return false;
	},
	
	createDataForAjaxCall: function() {
		if (this.authorizationMethod == 'AjaxAuthorization' || this.authorizationMethod == 'HiddenAuthorization') {
			parameters = {
				'sNewsletter': $('[data-field-name=sNewsletter]').val(),
				'sComment': $('[data-field-name=sComment]').val(),
			};
		} else {
			parameters = this.getDynamicFormValues();
		}
		if (this.getAliasSelectElement().size()) {
			parameters['alias'] = this.getAliasSelectElement().val();
		}
		return parameters;
	},
	
	handleAjaxResponse: function(response) {
		try {
			var objects = $.parseJSON(response);
		}
		catch(e) {
			this.handleAjaxFailure('An unknown error occurred.');
			return false;
		}
		
		if (objects.error) {
			this.handleAjaxFailure(objects.error);
			return false;
		} else if (objects.redirect) {
			document.location = objects.redirect;
		} else {
			this.startPayment(objects);
		}
	},
	
	handleAjaxFailure: function(errorMessage) {
		var html = '<div class="error bold center alert alert-danger payiteasycw-error">' + errorMessage + "</div>";
		this.getErrorElement().append(html);
		$(window).scrollTop(0);
		this.unblockUI();
		this.setLoadingIndicator(false);
	},
	
	startPayment: function(response) {
		if (this.authorizationMethod == 'AjaxAuthorization') {
			$.getScript(response.ajaxScriptUrl, $.proxy(function(){
				eval("var callbackFunction = " + response.ajaxSubmitCallback);
				callbackFunction($.extend(this.getDynamicFormValues(true), response.hiddenFields));
			}, this));
		} else {
			this.sendDataAsForm(response.formActionUrl, $.extend(this.getDynamicFormValues(true), response.hiddenFields));
		}
	},
	
	sendDataAsForm: function(url, values) {
		var newForm = '<form id="payiteasycw_redirect_form" action="' + url + '" method="POST">';
		newForm += this.renderDataAsHiddenFields(values);
		newForm += '</form>';
		$('body').append(newForm);
		$('#payiteasycw_redirect_form').submit();
	},
	
	loadAliasData: function() {
		this.setLoadingIndicator(true);
		this.blockUI();
		$.getJSON(this.visibleFieldsUrl, {
			aliasId: this.getAliasSelectElement().val(),
			paymentMethod: this.paymentMethod
		}, $.proxy(function(response){
			this.setLoadingIndicator(false);
			this.unblockUI();
			
			if (response.error) {
				this.handleAjaxFailure(objects.error);
				return false;
			}
			
			$('#visibleFormFields').html(response.visibleFormFields.fields);
			$('#visibleFormValidation').html(response.visibleFormFields.validation);
			this.removeFormFieldNames();
			this.aliasId = this.getAliasSelectElement().val();
		}, this));
	},

	setLoadingIndicator: function(flag) {
		if (flag) {
			this.getSubmitElement().hide();
			$('#payiteasycw-loader').remove();
			this.getSubmitElement().after('<div class="ajax_loader payiteasycw-loader" id="payiteasycw-loader">' + this.processingLabel + '</div>');
		} else {
			this.getSubmitElement().show();
			$('#payiteasycw-loader').remove();
		}
	},
	
	/**
	 * This method returns an element which should be blocked during AJAX calls.
	 * 
	 * @return Object
	 */
	getBlockingElement: function() {
		var blockingElement = this.getFormElement();
		if (typeof blockingElement === 'undefined' || blockingElement.length <= 0) {
			return $('body');
		}
		else {
			return blockingElement;
		}
	},
	
	/**
	 * This method blocks the user from entering other data. This method should be called
	 * before any AJAX call is executed.
	 * 
	 * @return void
	 */
	blockUI: function() {
		var element = this.getBlockingElement();
		var height = element.outerHeight();
		var width = element.outerWidth();
		var offset = element.position();
		element.append('<div class="payiteasycw-ajax-overlay"></div>');
		element.find('.payiteasycw-ajax-overlay').height(height).width(width).css({zIndex: 10000, top: offset.top, left: offset.left, position:'absolute'});
	},
	
	/**
	 * This method unblocks the user interface and allows the user do do any user action.
	 * 
	 * @return void
	 */
	unblockUI: function() {
		this.getBlockingElement().find('.payiteasycw-ajax-overlay').remove();
	},
	
	cleanUpErrorMessages: function() {
		$('.payiteasycw-error').remove();
	},
	
	getSubmitElement: function() {
		return $('#basketButton');
	},
	
	getErrorElement: function() {
		return $('#payiteasycw-errors');
	},
	
	getFormElement: function() {
		return $('#payiteasycw-payment-form');
	},
	
	getAliasSelectElement: function() {
		return $('#aliasSelect');
	}
};