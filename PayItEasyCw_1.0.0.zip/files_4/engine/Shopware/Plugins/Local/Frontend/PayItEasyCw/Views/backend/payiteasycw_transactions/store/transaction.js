/**
 * This store is used to load order transactions.
 * 
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_transactions/store/transaction"}
Ext.define('Shopware.apps.PayiteasycwTransactions.store.Transaction', {
    extend: 'Ext.data.Store',
 
    autoLoad: false,
    
    remoteSort: true,
    
    remoteFilter: true,
    
    pageSize: 20,
    
    sorters: [{
		property : 'transactionId',
		direction: 'DESC'
	}],
 
    model: 'Shopware.apps.PayiteasycwTransactions.model.Transaction'
});
//{/block}