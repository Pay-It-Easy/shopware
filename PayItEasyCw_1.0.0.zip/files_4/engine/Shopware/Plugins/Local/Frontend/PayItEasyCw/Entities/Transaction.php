<?php

/**
 *  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * @Entity(tableName = 'payiteasycw_transaction')
 *
 * @Filter(name = 'loadByOrderId', where = 'orderId = >orderId', orderBy = 'createdOn ASC')
 * @Filter(name = 'loadByTemporaryOrderId', where = 'temporaryOrderId = >orderId', orderBy = 'createdOn ASC')
 */
class PayItEasyCw_Entities_Transaction extends Customweb_Payment_Entity_AbstractTransaction {
	private $sessionData;
	private $emailData;
	private $paymentMethod;
	private $temporaryOrderId;
	private $shopId;
	private $order;

	/**
	 * @Column(type = 'object')
	 */
	public function getSessionData(){
		return $this->sessionData;
	}

	public function setSessionData($sessionData){
		$this->sessionData = $sessionData;
		return $this;
	}

	/**
	 * @Column(type = 'object')
	 */
	public function getEmailData(){
		return $this->emailData;
	}

	public function setEmailData($emailData){
		$this->emailData = $emailData;
		return $this;
	}

	/**
	 * @Column(type = 'varchar')
	 */
	public function getPaymentMethod(){
		return $this->paymentMethod;
	}

	public function setPaymentMethod($paymentMethod){
		$this->paymentMethod = $paymentMethod;
		return $this;
	}

	/**
	 * @Column(type = 'varchar')
	 */
	public function getTemporaryOrderId(){
		return $this->temporaryOrderId;
	}

	public function setTemporaryOrderId($temporaryOrderId){
		$this->temporaryOrderId = $temporaryOrderId;
		return $this;
	}

	/**
	 * @Column(type = 'integer')
	 */
	public function getShopId(){
		return $this->shopId;
	}

	public function setShopId($shopId){
		$this->shopId = $shopId;
		return $this;
	}

	public function getOrder($cached = true){
		if ($this->order == null || !$cached) {
			if ($this->getOrderId() == null) {
				return;
			}
			$order = Shopware()->Models()->find('Shopware\Models\Order\Order', $this->getOrderId());
			if (!($order instanceof Shopware\Models\Order\Order)) {
				return;
			}
			$this->order = $order;
		}
		return $this->order;
	}

	public function toArray(){
		$array = array();
		$reflection = new ReflectionClass($this);
		foreach ($reflection->getMethods() as $method) {
			$methodName = $method->getName();
			if (strpos($methodName, 'get') === 0) {
				$keyName = lcfirst(substr($methodName, 3));
				$array[$keyName] = $this->$methodName();
			}
			elseif (strpos($methodName, 'is') === 0) {
				$keyName = lcfirst(substr($methodName, 2));
				$array[$keyName] = $this->$methodName();
			}
		}
		return $array;
	}

	public function onBeforeSave(Customweb_Database_Entity_IManager $entityManager){
		if($this->isSkipOnSafeMethods()){
			return;
		}
		parent::onBeforeSave($entityManager);

		$order = $this->getOrder(false);
		if ($order !== null && $this->getShopId() == null) {
			$this->setShopId($order->getShop()->getId());
		}
	}

	public function onAfterSave(Customweb_Database_Entity_IManager $entityManager){
		if($this->isSkipOnSafeMethods()){
			$this->setSkipOnSaveMethods(false);
			return;
		}
		parent::onAfterSave($entityManager);

		$order = $this->getOrder(false);
		if ($this->getTransactionObject() !== null && $order !== null && $this->getTransactionObject()->isCaptured() &&
				 $order->getClearedDate() == null) {
			$query = sprintf('UPDATE s_order SET cleareddate = \'' . date('Y-m-d H:i:s') . '\' WHERE id = ' . (int) $order->getId());
			Shopware()->Db()->query($query);
			$this->order = null;
		}
	}

	protected function updateOrderStatus(Customweb_Database_Entity_IManager $entityManager, $orderStatus, $orderStatusSettingKey){
		$order = $this->getOrder();
		if ($order == null) {
			return;
		}
		$paymentStatus = $orderStatus;
		$orderStatus = $this->getTransactionObject()->getPaymentMethod()->getPaymentMethodConfigurationValue('order_status',
				$order->getShop()->getId());
		$query = sprintf(
				'UPDATE s_order SET cleared = ' . (int) $paymentStatus . ', status = ' . (int) $orderStatus . ', transactionID = \'payiteasycw-' .
						 (int) $this->getTransactionId() . '\' WHERE id = ' . (int) $this->getOrderId());
		Shopware()->Db()->query($query);
		$this->order = null;
	}

	protected function authorize(Customweb_Database_Entity_IManager $entityManager){
		PayItEasyCw_Helpers_Util::getStorage()->lock('authorization', $this->getTransactionId(), Customweb_Storage_IBackend::EXCLUSIVE_LOCK);
		$this->getTransactionObject()->getPaymentMethod()->authorizeTransaction($this);
		PayItEasyCw_Helpers_Util::getStorage()->unlock('authorization', $this->getTransactionId());
	}
}