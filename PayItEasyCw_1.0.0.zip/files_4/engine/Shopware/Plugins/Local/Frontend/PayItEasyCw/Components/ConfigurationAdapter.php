<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class represents a configuration adapter.
 *
 * @author Simon Schurter
 *
 * @Bean
 */
class PayItEasyCw_Components_ConfigurationAdapter implements Customweb_Payment_IConfigurationAdapter
{
	private static $shopId = null;
	
	private static $config = null;
	
	public static function setShop($shopId)
	{
		self::$shopId = $shopId;
		self::$config = clone Shopware()->Config();
		self::$config->setShop(self::getShop());
	}
	
	public static function getShop()
	{
		if (self::$shopId !== null) {
			$shop = Shopware()->Models()->find('Shopware\Models\Shop\Shop', self::$shopId);
		} else {
			try {
				$shop = Shopware()->Shop();
			} catch (Exception $e) {
				$shop = Shopware()->Models()
					->getRepository('Shopware\Models\Shop\Shop')
					->findOneBy(array(
						'active' => 1,
						'default' => 1
					));
			}
		}
		return $shop;
	}
	
	private function getConfig()
	{
		if (self::$config == null) {
			return Shopware()->Config();
		} else {
			return self::$config;
		}
	}
	
	public function getConfigurationValue($key, $language = null)
	{
		$value = $this->getConfig()->getByNamespace('payiteasycw', $key);
		
		$fileTypeDefaultValue = $this->getFileTypeDefaultValue($key);
		if ($fileTypeDefaultValue !== false) {
			if (empty($value) || $value == $fileTypeDefaultValue) {
				$value = PayItEasyCw_Helpers_Util::getAssetResolver()->resolveAssetStream($value);
			} else {
				$value = new Customweb_Core_Stream_Input_File(Shopware()->DocPath() . $value);
			}
		} elseif ($value instanceof Enlight_Config) {
			return $value->toArray();
		}
		
		return $value;
	}
	
	private function getFileTypeDefaultValue($key)
	{
		$fileTypes = array(
		);
		if (isset($fileTypes[$key])) {
			return $fileTypes[$key];
		}
		return false;
	}

	public function getDefaultTemplateUrl()
	{
		return PayItEasyCw_Helpers_Util::getUrl(array(
			'module' => 'frontend',
			'controller' => 'PayItEasyCwCheckout',
			'action' => 'template',
			'forceSecure' => true
		));
	}

	public function existsConfiguration($key, $language = null)
	{
		return isset(Shopware()->Plugins()
			->Frontend()
			->PayItEasyCw()
			->Config()
			->$key);
	}

	public function getLanguages($currentStore = false)
	{
		$languages = array();
		$shops = Shopware()->Models()
			->getRepository('Shopware\Models\Shop\Shop')
			->findAll();
		foreach ($shops as $shop) {
			$locale = $shop->getLocale();
			$language = $locale->getLocale();
			$languages[] = new Customweb_Core_Language($language);
		}
		return $languages;
	}

	public function getStoreHierarchy()
	{
		$hierarchy = array();
		$currentShop = self::getShop();
		$mainShop = $currentShop->getMain();
		if ($mainShop != null) {
			$hierarchy[$mainShop->getId()] = $mainShop->getName();
		}
		$hierarchy[$currentShop->getId()] = $currentShop->getName();
		return $hierarchy;
	}

	public function useDefaultValue(Customweb_Form_IElement $element, array $formData)
	{
		$controlName = implode('_', $element->getControl()->getControlNameAsArray());
		return (isset($formData['default'][$controlName]) && $formData['default'][$controlName] == 'default');
	}

	public function getOrderStatus()
	{
		$orderStates = array();
		$states = PayItEasyCw_Helpers_Util::getOrderStatusOptions();
		foreach ($states as $state) {
			$orderStates[$state['value']] = $state['text'];
		}
		return $orderStates;
	}

}
