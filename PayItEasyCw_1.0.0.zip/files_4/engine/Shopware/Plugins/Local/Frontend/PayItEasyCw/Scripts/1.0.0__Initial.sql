CREATE TABLE IF NOT EXISTS `payiteasycw_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `alias_for_display` varchar(255) DEFAULT NULL,
  `alias_active` tinyint(1) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `transaction_object` longtext NOT NULL,
  `authorization_type` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `updatable` tinyint(1) NOT NULL,
  `session_data` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `payiteasycw_storage` (
  `key_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key_space` varchar(165) DEFAULT NULL,
  `key_name` varchar(165) DEFAULT NULL,
  `key_value` longtext,
  PRIMARY KEY (`key_id`),
  UNIQUE KEY `keyName_keySpace` (`key_space`,`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

CREATE TABLE IF NOT EXISTS `payiteasycw_customer_context` (
  `user_id` int(11) NOT NULL,
  `customer_context` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;