<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class is used to render form elements to html.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_BackendFormRenderer extends Customweb_Form_Renderer
{
	private $currentForm = null;
	
	public function renderForm(Customweb_IForm $form)
	{
		$this->currentForm = $form;
	
		$output = '<form class="shopware-form payiteasycw-form ' . $this->getFormCssClass() . '" action="' . $form->getTargetUrl() . '" method="' . $form->getRequestMethod() . '"
				target="' . $form->getTargetWindow() . '" id="' . $form->getId() . '" name="' . $form->getMachineName() . '">';
	
		$output .= '<div id="' . $form->getId() . '-body" class="payiteasycw-panel-body x-panel-body x-panel-body-default x-panel-body-default x-layout-fit">';
	
		$output .= $this->renderElementGroups($form->getElementGroups());
	
		$token = $this->getFormToken($form);
		if ($token !== null) {
			$output .= '<input type="hidden" name="' . self::FORM_TOKEN_FIELD_NAME . '" value="' . $token . '" />';
		}
	
		$output .= '</div>';
	
		$output .= $this->renderButtons($form->getButtons());
	
		$output .= '</form>';
	
		if ($this->isAddJs()) {
			$output .= '<script type="text/javascript">' . "\n";
			$output .= $this->renderElementsJavaScript($form->getElements());
			$output .= "\n</script>";
		}
		return $output;
	}
	
	public function renderElementGroupPrefix(Customweb_Form_IElementGroup $elementGroup)
	{
		return '<fieldset class="payiteasycw-fieldset x-fieldset">';
	}
	
	public function renderElementGroupTitle(Customweb_Form_IElementGroup $elementGroup)
	{
		$output = '';
		$title = $elementGroup->getTitle();
		if (! empty($title)) {
			$cssClass = $this->getCssClassPrefix() . $this->getElementGroupTitleCssClass();
			$output .= '<legend class="x-fieldset-header ' . $cssClass . '">' . $title . '</legend>';
		}
		return $output;
	}
	
	public function renderElementsJavaScript(array $elements)
	{
		$js = '';
		$js .= 'var payiteasycwLayout = function () {
			var body = document.getElementById(\'' . $this->currentForm->getId() . '-body\');
			var toolbar = document.getElementById(\'' . $this->currentForm->getId() . '-toolbar\');
			if (toolbar) {
				body.style.height = window.innerHeight - toolbar.offsetHeight;
			} else {
				body.style.height = window.innerHeight;
			}
		};';
	
		return "\n" . $js . parent::renderElementsJavaScript($elements);
	}
	
	protected function renderOnLoadJs(array $initializers)
	{
		$initializers[] = 'payiteasycwLayout';
		return parent::renderOnLoadJs($initializers);
	}
	
	public function renderElementPrefix(Customweb_Form_IElement $element)
	{
		$classes = $this->getCssClassPrefix() . $this->getElementCssClass();
		$classes .= ' ' . $this->getCssClassPrefix() . $element->getElementIntention()->getCssClass();
	
		$errorMessage = $element->getErrorMessage();
		if (! empty($errorMessage)) {
			$classes .= ' ' . $this->getCssClassPrefix() . $this->getElementErrorCssClass();
		}
	
		$output = '<table class="payiteasycw-form-item x-field x-form-item x-field-default x-anchor-form-item ' . $classes . '" id="' . $element->getElementId() . '"><tbody><tr>';
		if ($element instanceof Customweb_Form_WideElement) {
			$output .= '<td class="payiteasycw-form-item-body x-form-item-body x-form-cb-wrap" colspan="2">';
		}
		return $output;
	}
	
	public function renderElementPostfix(Customweb_Form_IElement $element)
	{
		return '</td></tr></tbody></table>';
	}
	
	protected function renderRequiredTag(Customweb_Form_IElement $element)
	{
		return '';
	}
	
	protected function renderLabel($referenceTo, $label, $class)
	{
		$for = '';
		if (!empty($referenceTo)) {
			$for = ' for="' . $referenceTo . '" ';
		}
		$output .= '<td class="payiteasycw-form-label-cell x-field-label-cell">';
		$output .= '<label ' . $for . ' class="payiteasycw-form-item-label x-form-item-label x-form-item-label-left ' . $class . '">' . $label . '</label>';
		$output .= '</td>';
		$output .= '<td class="payiteasycw-form-item-body x-form-item-body x-form-cb-wrap">';
		return $output;
	}
	
	public function renderElementAdditional(Customweb_Form_IElement $element)
	{
		if (PayItEasyCw_Components_ConfigurationAdapter::getShop()->getMain() != null) {
			$output .= $this->renderElementScope($element);
		}
	
		$description = $element->getDescription();
		if (!empty($description)) {
			$output .= $this->renderElementDescription($element);
		}
	
		$errorMessage = $element->getErrorMessage();
		if (!empty($errorMessage)) {
			$output .= $this->renderElementErrorMessage($element);
		}
	
		return $output;
	}
	
	protected function renderElementDescription(Customweb_Form_IElement $element)
	{
		$output = '</td></tr><tr><td></td><td>';
		$output .= '<div class="x-form-support-text ' . $this->getCssClassPrefix() . $this->getDescriptionCssClass() . '">' . $element->getDescription() . '</div>';
		$output .= '</td><td>';
		return $output;
	}
	
	protected function renderElementScope(Customweb_Form_IElement $element)
	{
		$output = '</td><td class="payiteasycw-scope-cell">';
		$output .= '<div class="' . $this->getCssClassPrefix() . $this->getElementScopeCssClass() . '">';
		if (!$element->isGlobalScope() && $element->getControl() instanceof Customweb_Form_Control_IEditableControl) {
			$output .= $this->renderElementScopeControl($element);
		}
		$output .= '</div>';
		return $output;
	}
	
	protected function getContainerFromCheckboxJs($checkbox)
	{
		return $checkbox . '.parentNode.parentNode.parentNode.parentNode.previousSibling';
	}
	
	public function renderControl(Customweb_Form_Control_IControl $control)
	{
		if ($control instanceof Customweb_Form_Control_MultiSelect) {
			$originalControl = $control;
			$control = new Customweb_Form_Control_MultiCheckbox($originalControl->getRawControlName(), $originalControl->getOptions(), $originalControl->getDefaultValues());
		}
	
		$control->setCssClass($control->getCssClass() . ' ' . $this->getControlClasses($control));
		return $control->render($this);
	}
	
	protected function getControlClasses(Customweb_Form_Control_IControl $control)
	{
		$classes = 'payiteasycw-form-field x-form-field';
		if ($control->isRequired()) {
			$classes .= ' x-form-required-field';
		}
		if ($control instanceof Customweb_Form_Control_TextInput
			|| $control instanceof Customweb_Form_Control_TextArea
			|| $control instanceof Customweb_Form_Control_Password) {
				$classes .= ' x-form-text';
			} elseif ($control instanceof Customweb_Form_Control_SingleCheckbox
				|| $control instanceof Customweb_Form_Control_MultiCheckbox) {
				$classes .= ' x-form-checkbox';
			} elseif ($control instanceof Customweb_Form_Control_Radio) {
				$classes .= ' x-form-radio';
			}
			return $classes;
	}
	
	protected function renderButtons(array $buttons)
	{
		if (!empty($buttons)) {
			$output = '<div id="' . $this->currentForm->getId() . '-toolbar" class="payiteasycw-toolbar x-toolbar shopware-toolbar x-border-item x-toolbar-shopware-ui x-box-layout-ct">';
			foreach ($buttons as $button) {
				$output .= $this->renderButton($button);
			}
			$output .= '</div>';
		}
		return $output;
	}
	
	public function renderButton(Customweb_Form_IButton $button)
	{
		$output = '<div class="payiteasycw-btn x-btn primary x-toolbar-item x-btn-default-toolbar-small x-noicon x-btn-noicon x-btn-default-toolbar-small-noicon">';
		$output .= '<em>';
		$output .= '<button type="submit" id="' . $button->getId() . '" name="button[' . $button->getMachineName() . ']" class="x-btn-center ' . $this->getButtonClass() . '">';
		$output .= '<span class="x-btn-inner" style="">' . $button->getTitle() . '</span>';
		$output .= '<span class="x-btn-icon "></span>';
		$output .= '</button>';
		$output .= '</em>';
		$output .= '</div>';
		return $output;
	}
}