<?php
/**
  * You are allowed to use this API in your web application.
 *
 * Copyright (C) 2016 by customweb GmbH
 *
 * This program is licenced under the customweb software licence. With the
 * purchase or the installation of the software in your application you
 * accept the licence agreement. The allowed usage is outlined in the
 * customweb software licence which can be found under
 * http://www.sellxed.com/en/software-license-agreement
 *
 * Any modification or distribution is strictly forbidden. The license
 * grants you the installation in one application. For multiuse you will need
 * to purchase further licences at http://www.sellxed.com/shop.
 *
 * See the customweb software licence agreement for more details.
 *
 *
 * This class represents an address.
 *
 * @author Simon Schurter
 */
class PayItEasyCw_Components_AddressContext
{
	/**
	 * Contains the name of the country.
	 * @var string $country
	 */
	protected $country = null;
	
	/**
	 * Contains the name of the state.
	 * @var string $state
	 */
	protected $state = null;
	
	/**
	 * Contains the name of the address company
	 * @var string $company
	 */
	protected $company = null;
	
	/**
	 * Contains the customer salutation (Mr, Ms, Company)
	 * @var string $salutation
	 */
	protected $salutation = null;
	
	/**
	 * Contains the first name of the address
	 * @var string $firstName
	 */
	protected $firstName = null;
	
	/**
	 * Contains the last name of the address
	 * @var string $lastName
	 */
	protected $lastName = null;
	
	/**
	 * Contains the street name of the address
	 * @var string $street
	 */
	protected $street = null;
	
	/**
	 * Contains the zip code of the address
	 * @var string $zipCode
	 */
	protected $zipCode = null;
	
	/**
	 * Contains the city name of the address
	 * @var string $city
	 */
	protected $city = null;
	
	/**
	 * Contains the phone number of the address
	 * @var string $phone
	 */
	protected $phone = null;
	
	/**
	 * Create address context from entity.
	 * 
	 * @param object $address
	 */
	public function __construct($addresses)
	{
		$this->company = $this->getAddressValue($addresses, 'company');
		$this->salutation = $this->getAddressValue($addresses, 'salutation');
		$this->firstName = $this->getAddressValue($addresses, 'firstName');
		$this->lastName = $this->getAddressValue($addresses, 'lastName');
		$this->street = $this->getAddressValue($addresses, 'street') . ' ' . $this->getAddressValue($addresses, 'streetNumber');
		$this->zipCode = $this->getAddressValue($addresses, 'zipCode');
		$this->city = $this->getAddressValue($addresses, 'city');
		$this->phone = $this->getAddressValue($addresses, 'phone');
		$this->country = $this->getCountryFromAddress($addresses);
		$this->state = $this->getStateFromAddress($addresses);
	}
	
	/**
	 * @param array $addresses
	 * @param string $key
	 * @return mixed
	 */
	private function getAddressValue($addresses, $key)
	{
		$getter = 'get' . ucfirst($key);
		$value = null;
		foreach ($addresses as $address) {
			if (method_exists($address, $getter)) {
				$value = $address->$getter();
				break;
			}
		}
		return $value;
	}
	
	/**
	 * @param object $address
	 * @return null|string
	 */
	protected function getStateFromAddress($addresses)
	{
		$stateId = $this->getAddressValue($addresses, 'stateId');
		if (empty($stateId)) {
			return null;
		}
	
		$state = Shopware()->Models()->find('Shopware\Models\Country\State', $stateId);
		if ($state != null && $state instanceof Shopware\Models\Country\State) {
			return $state->getShortCode();
		}
	}
	
	/**
	 * @param object $address
	 * @return string
	 */
	protected function getCountryFromAddress($addresses)
	{
		$country = $this->getAddressValue($addresses, 'country');
		if ($country !== null && $country instanceof Shopware\Models\Country\Country) {
			return $country->getIso();
		}
		
		$countryId = $this->getAddressValue($addresses, 'countryId');
		if ($countryId !== null) {
			$country = Shopware()->Models()->find('Shopware\Models\Country\Country', $countryId);
			if ($country !== null && $country instanceof Shopware\Models\Country\Country) {
				return $country->getIso();
			}
		}
	}
	
	/**
	 * Getter function for the company.
	 *
	 * @return string
	 */
	public function getCompany()
	{
		return $this->company;
	}
	
	/**
	 * Getter function for the salutation.
	 *
	 * @return string
	 */
	public function getSalutation()
	{
		return $this->salutation;
	}
	
	/**
	 * Getter function for the firstName.
	 *
	 * @return string
	 */
	public function getFirstName()
	{
		return $this->firstName;
	}
	
	/**
	 * Getter function for the lastName.
	 *
	 * @return string
	 */
	public function getLastName()
	{
		return $this->lastName;
	}
	
	/**
	 * Getter function for the street.
	 *
	 * @return string
	 */
	public function getStreet()
	{
		return $this->street;
	}
	
	/**
	 * Getter function for the zipCode.
	 *
	 * @return string
	 */
	public function getZipCode()
	{
		return $this->zipCode;
	}
	
	/**
	 * Getter function for the city.
	 *
	 * @return string
	 */
	public function getCity()
	{
		return $this->city;
	}
	
	/**
	 * Getter function for the phone.
	 *
	 * @return string
	 */
	public function getPhone()
	{
		return $this->phone;
	}
	
	/**
	 * Getter function for the country.
	 *
	 * @return string
	 */
	public function getCountry()
	{
		return $this->country;
	}
	
	/**
	 * Getter function for the state.
	 * @return string
	 */
	public function getState()
	{
		return $this->state;
	}
}