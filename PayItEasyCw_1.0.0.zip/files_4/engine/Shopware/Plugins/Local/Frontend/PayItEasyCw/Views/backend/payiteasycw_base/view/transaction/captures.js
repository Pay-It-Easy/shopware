/**
 * @author Simon Schurter
 */
//{block name="backend/payiteasycw_base/view/transaction/captures"}
//{namespace name=backend/payiteasycw/main}
Ext.define('Shopware.apps.PayiteasycwBase.view.transaction.Captures', {
    extend: 'Ext.container.Container',
    
    alias:'widget.payiteasycw-base-transaction-captures',
    
	layout:		'border',
	formActions: {},
    
    initComponent: function() {
        var me = this;
 
        me.items = me.getItems();
 
        me.callParent(arguments);
    },
    
    getItems: function() {
    	var me = this;
    	
    	var containerItems = [ me.createGrid(), me.createDetail() ];
    	    	
    	var items = [
             Ext.create('Ext.container.Container', {
            	 layout: 'border',
            	 region: 'center',
            	 items: containerItems
             })
    	];
    	
    	if (me.record.get('capturePossible')) {
    		items.push(me.createForm());
    	}
    	
    	return items;
    },
    
    createGrid: function() {
    	var me = this;
    	
    	var grid = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.captures.Grid', {
    		record: me.record,
    		region: 'center'
    	});
    	
    	return grid;
    },
    
    createDetail: function() {
    	var me = this;
    	
    	var detail = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.captures.Detail', {
    		region: 'east',
    		width: '50%'
    	});
    	
    	return detail;
    },
    
    createForm: function() {
    	var me = this;
    	
    	var formHeight = '30px';
    	if (me.record.get('partialCapturePossible')) {
    		formHeight = '50%';
    	}
    	
    	var form = Ext.create('Shopware.apps.PayiteasycwBase.view.transaction.captures.Form', {
    		region: 'south',
    		height: formHeight,
    		padding: '10px',
    		record: me.record
    	});
    	
    	return form;
    }
});
//{/block}